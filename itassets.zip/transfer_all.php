<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$fromPersonId = $input['from_person_id'] ?? 0;
$toPersonId   = $input['to_person_id'] ?? 0;

if (!$fromPersonId || !$toPersonId || $fromPersonId == $toPersonId) {
    echo json_encode(['success' => false, 'message' => 'شناسه‌ها نامعتبر']);
    exit;
}

// دریافت اسامی برای لاگ
$fromName = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $fromPersonId")->fetchColumn();
$toName   = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $toPersonId")->fetchColumn();

if (!$fromName || !$toName) {
    echo json_encode(['success' => false, 'message' => 'فرد یافت نشد']);
    exit;
}

$pdo->beginTransaction();
try {
    // ۱. انتقال inventory (تجهیزات واگذارشده) در صورت وجود
    $inv = $pdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
    $inv->execute([$fromPersonId]);
    $hasInventory = $inv->fetch();

    if ($hasInventory) {
        // حذف inventory مقصد (برای جلوگیری از تداخل)
        $pdo->prepare("DELETE FROM inventory WHERE person_id = ?")->execute([$toPersonId]);
        // جابه‌جایی
        $pdo->prepare("UPDATE inventory SET person_id = ? WHERE person_id = ?")
            ->execute([$toPersonId, $fromPersonId]);
    }

    // ۲. انتقال اقلام انبار (warehouse_items)
    $pdo->prepare("UPDATE warehouse_items SET transferred_from_person_id = ?, transferred_date = NOW() WHERE transferred_from_person_id = ?")
        ->execute([$toPersonId, $fromPersonId]);

    // ۳. ثبت لاگ برای هر دو نفر
    logChange($pdo, $toPersonId, 'update', "دریافت کلیه اموال از {$fromName}", '');
    logChange($pdo, $fromPersonId, 'update', "انتقال کلیه اموال به {$toName}", '');

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}