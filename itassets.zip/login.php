<?php
require_once 'includes/master_config.php';
session_start();

$error = '';
$branches = $master_pdo->query("SELECT * FROM branches WHERE is_active = 1")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = trim($_POST['username'] ?? '');
    $password  = $_POST['password'] ?? '';
    $branchId  = $_POST['branch_id'] ?? 0;

    if ($username && $password && $branchId) {
        // بررسی کاربر در master
        $stmt = $master_pdo->prepare("SELECT * FROM admin_users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            // بررسی دسترسی به شعبه
            if ($admin['role'] !== 'super_admin' && $admin['branch_id'] != $branchId) {
                $error = 'شما اجازه ورود به این شعبه را ندارید.';
            } else {
                $stmt = $master_pdo->prepare("SELECT * FROM branches WHERE id = ?");
                $stmt->execute([$branchId]);
                $branch = $stmt->fetch();

                if ($branch) {
                    $_SESSION['admin_id']        = $admin['id'];
                    $_SESSION['admin_name']      = $admin['full_name'];
                    $_SESSION['admin_role']      = $admin['role'];
                    $_SESSION['admin_branch_id'] = $branchId;
                    $_SESSION['branch_db']       = [
                        'host'   => $branch['db_host'],
                        'dbname' => $branch['db_name'],
                        'user'   => $branch['db_user'],
                        'pass'   => $branch['db_pass']
                    ];
                    $_SESSION['branch_name']     = $branch['name'];

                    header("Location: dashboard.php");
                    exit;
                } else {
                    $error = 'شعبهٔ انتخابی معتبر نیست.';
                }
            }
        } else {
            $error = 'نام کاربری یا رمز عبور اشتباه است.';
        }
    } else {
        $error = 'لطفاً تمام فیلدها را پر کنید.';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ورود | مدیریت اموال IT</title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body {
            background: linear-gradient(135deg, #e0e7ff 0%, #f0f4ff 100%);
            font-family: 'YekanBakh', Tahoma, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        /* حلقه‌های پس‌زمینه */
        .bg-animation {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            z-index: 0; overflow: hidden;
        }
        .bg-animation .circle {
            position: absolute; border-radius: 50%;
            animation: floatCircle 18s infinite ease-in-out;
            background: radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8), rgba(78,84,200,0.3));
        }
        .bg-animation .circle:nth-child(1) {
            width: 700px; height: 700px; top: -200px; right: -150px;
            animation-delay: 0s; animation-duration: 20s;
        }
        .bg-animation .circle:nth-child(2) {
            width: 500px; height: 500px; bottom: -150px; left: -100px;
            animation-delay: -4s; animation-duration: 17s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.85), rgba(143,148,251,0.3));
        }
        .bg-animation .circle:nth-child(3) {
            width: 400px; height: 400px; top: 40%; right: 10%;
            animation-delay: -8s; animation-duration: 22s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.8), rgba(102,126,234,0.3));
        }
        .bg-animation .circle:nth-child(4) {
            width: 300px; height: 300px; bottom: 10%; right: 20%;
            animation-delay: -12s; animation-duration: 14s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.7), rgba(250,112,154,0.25));
        }
        .bg-animation .circle:nth-child(5) {
            width: 250px; height: 250px; top: 10%; left: 15%;
            animation-delay: -16s; animation-duration: 19s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.6), rgba(246,211,101,0.25));
        }
        @keyframes floatCircle {
            0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
            25%      { transform: translate(60px, -40px) scale(1.08) rotate(2deg); }
            50%      { transform: translate(-30px, 50px) scale(0.95) rotate(-2deg); }
            75%      { transform: translate(-50px, -20px) scale(1.03) rotate(1deg); }
        }

        /* splash لوگو */
        #splash {
            position: fixed;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            opacity: 0;
            transition: opacity 2s cubic-bezier(0.23, 1, 0.32, 1);
            pointer-events: none;
        }
        #splash.show { opacity: 1; }
        #splash.hide { opacity: 0; }
        #splash img {
            width: 90px; height: 90px;
            filter: drop-shadow(0 20px 40px rgba(0,0,0,0.15));
        }

        /* کارت ورود */
        .login-card {
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-radius: 28px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.08), 0 10px 20px rgba(0,0,0,0.04);
            padding: 50px 40px;
            width: 100%;
            max-width: 450px;
            position: relative;
            z-index: 10;
            opacity: 0;
            transform: translateY(30px) scale(0.98);
            transition: opacity 2s cubic-bezier(0.23, 1, 0.32, 1), transform 2s cubic-bezier(0.23, 1, 0.32, 1);
        }
        .login-card.visible {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        .login-card.fade-out {
            opacity: 0;
            transform: translateY(-20px) scale(0.97);
            transition: opacity 2s ease, transform 2s ease;
        }
        .login-card.shake {
            animation: shake 0.5s ease;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25%      { transform: translateX(-10px); }
            50%      { transform: translateX(10px); }
            75%      { transform: translateX(-5px); }
        }

        .logo-circle {
            width: 90px; height: 90px; border-radius: 24px;
            background: #f1f1f600;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 25px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0);
        }
        .logo-circle img { width: 65px; height: 65px; object-fit: contain; }

        .btn-primary {
            background: linear-gradient(135deg, #4e73df 0%, #2a5298 100%);
            border: none; padding: 14px; font-size: 1.1rem; font-weight: bold;
            border-radius: 16px; transition: all 0.3s ease;
            box-shadow: 0 8px 20px rgba(78,115,223,0.3);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #2a5298 0%, #4e73df 100%);
            transform: translateY(-2px); box-shadow: 0 15px 30px rgba(78,115,223,0.45);
        }
        .btn-primary:active { transform: translateY(0); }

        .form-control, .form-select {
            border: 1px solid #e2e8f0; border-radius: 14px;
            padding: 14px 16px; font-size: 1rem; transition: 0.3s;
        }
        .form-control:focus, .form-select:focus {
            border-color: #4e73df; box-shadow: 0 0 0 3px rgba(78,115,223,0.15);
        }
    </style>
</head>
<body>
<div class="bg-animation">
    <div class="circle"></div><div class="circle"></div><div class="circle"></div>
    <div class="circle"></div><div class="circle"></div>
</div>

<!-- Splash لوگو -->
<div id="splash">
    <img src="images/logo.png" alt="لوگو شرکت تناوب">
</div>

<!-- کارت ورود -->
<div class="login-card" id="loginCard" <?php if($error) echo 'style="opacity:1; transform:translateY(0) scale(1);"' ?>>
    <div class="logo-circle">
        <img src="images/logo.png" alt="لوگو تناوب">
    </div>
    <h3 class="text-center mb-1" style="color:#1e293b;">مدیریت اموال IT</h3>
    <p class="text-center text-muted mb-4">شرکت تناوب</p>

    <?php if ($error): ?>
        <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" id="loginForm">
        <div class="mb-3">
            <input type="text" name="username" class="form-control" placeholder="نام کاربری" required>
        </div>
        <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="رمز عبور" required>
        </div>
        <div class="mb-3">
            <select name="branch_id" class="form-select" required>
                <option value="">-- انتخاب شعبه --</option>
                <?php foreach ($branches as $b): ?>
                    <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary w-100" id="loginButton">ورود به سیستم</button>
    </form>
    <p class="text-center text-muted mt-4" style="font-size:0.85rem">© <?= date('Y') ?> شرکت تناوب</p>
</div>

<script>
    const splash = document.getElementById('splash');
    const loginCard = document.getElementById('loginCard');
    const form = document.getElementById('loginForm');
    const hasError = <?= $error ? 'true' : 'false' ?>;

    // splash → ۲ ثانیه وقفه → نشان دادن کارت
    function showSplash() {
        splash.classList.add('show');
        setTimeout(() => {
            splash.classList.add('hide');
            setTimeout(() => {
                splash.style.display = 'none';
                setTimeout(() => {
                    loginCard.classList.add('visible');
                }, 500);
            }, 1200);
        }, 3000);
    }

    window.addEventListener('load', () => {
        if (hasError) {
            loginCard.classList.add('visible');
        } else {
            splash.style.display = 'block';
            showSplash();
        }
    });

    // fadeOut & submit
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const user = form.querySelector('[name="username"]').value.trim();
        const pass = form.querySelector('[name="password"]').value.trim();
        const branch = form.querySelector('[name="branch_id"]').value;
        if (!user || !pass || !branch) {
            alert('لطفاً همه فیلدها را پر کنید.');
            return;
        }
        loginCard.classList.add('fade-out');
        setTimeout(() => form.submit(), 800);
    });
</script>
</body>
</html>