<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

$msg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'deactivated') $msg = '<div class="alert alert-warning">فرد غیرفعال و تجهیزات به انبار منتقل شد.</div>';
    if ($_GET['msg'] == 'activated')  $msg = '<div class="alert alert-success">فرد فعال‌سازی و تجهیزات بازگردانده شد.</div>';
    if ($_GET['msg'] == 'deleted')    $msg = '<div class="alert alert-danger">فرد حذف دائمی شد.</div>';
}

$results = [];
if (isset($_GET['search']) && !empty($_GET['term'])) {
    $term = '%' . $_GET['term'] . '%';
    $type = $_GET['type'] ?? 'all';
    $sql = "SELECT p.* FROM persons p";
    $params = [];

    if ($type == 'all') {
        $sql .= " LEFT JOIN inventory i ON p.id = i.person_id
                  WHERE p.first_name LIKE ? OR p.last_name LIKE ? OR p.personnel_code LIKE ?
                     OR i.case_name LIKE ? OR i.monitor_name LIKE ? OR i.laptop_name LIKE ?";
        $params = array_fill(0, 6, $term);
    } elseif ($type == 'personnel') {
        $sql .= " WHERE p.personnel_code LIKE ?";
        $params = [$term];
    } elseif ($type == 'asset') {
        $sql .= " JOIN inventory i ON p.id = i.person_id
                  WHERE i.case_code LIKE ? OR i.monitor_code LIKE ? OR i.keyboard_code LIKE ?
                     OR i.phone_code LIKE ? OR i.printer_code LIKE ? OR i.scanner_code LIKE ?
                     OR i.laptop_code LIKE ?";
        $params = array_fill(0, 7, $term);
    } else {
        $sql .= " WHERE p.last_name LIKE ?";
        $params = [$term];
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM persons ORDER BY last_name, first_name");
    $results = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت پرسنل</title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; position: relative; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%, 100% { transform: translate(0,0) scale(1); } 33% { transform: translate(40px,-40px) scale(1.05); } 66% { transform: translate(-30px,30px) scale(0.95); } }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .badge-active { background: #198754; }
        .badge-inactive { background: #ffc107; color: #000; }
        .badge-deleted { background: #dc3545; }
        .btn-action img { width: 18px; height: 18px; }

        /* جدول فشرده */
        .table-sm-custom { font-size: 0.85rem; }
        .table-sm-custom th, .table-sm-custom td { padding: 8px 10px; vertical-align: middle; white-space: nowrap; }
        .sortable { cursor: pointer; user-select: none; }
        .sortable::after { content: ' ↕'; font-size: 0.8rem; color: #aaa; }
        .sortable.asc::after { content: ' ↑'; color: #333; }
        .sortable.desc::after { content: ' ↓'; color: #333; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>

<nav class="navbar-dash">
    <div class="container d-flex justify-content-start">
        <a href="dashboard.php" class="btn btn-primary btn-sm"><img src="images/icons/home.png" width="18"> داشبورد</a>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <?= $msg ?>

    <div class="card">
        <div class="card-body">
            <form method="get" class="row g-2 align-items-end">
                <div class="col-md-3">
                    <select name="type" class="form-select">
                        <option value="all" <?= ($_GET['type'] ?? 'all') == 'all' ? 'selected' : '' ?>>همه موارد</option>
                        <option value="personnel" <?= ($_GET['type'] ?? '') == 'personnel' ? 'selected' : '' ?>>کد پرسنلی</option>
                        <option value="asset" <?= ($_GET['type'] ?? '') == 'asset' ? 'selected' : '' ?>>کد اموال</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <input type="text" name="term" class="form-control" placeholder="عبارت جستجو..." value="<?= htmlspecialchars($_GET['term'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" name="search" class="btn btn-primary w-100">جستجو</button>
                </div>
            </form>
        </div>
    </div>

    <?php if (!empty($results)): ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">نتایج (<?= count($results) ?> نفر)</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 table-sm-custom" id="personsTable">
                    <thead class="table-light">
                        <tr>
                            <th class="sortable" data-sort="string">کد پرسنلی</th>
                            <th class="sortable" data-sort="string">نام</th>
                            <th class="sortable" data-sort="string">واحد</th>
                            <th class="sortable" data-sort="string">محل</th>
                            <th class="sortable" data-sort="string">وضعیت</th>
                            <th style="width: 180px;">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $p):
                            $isActive  = (bool)$p['is_active'];
                            $isDeleted = (bool)($p['is_deleted'] ?? 0);

                            if ($isDeleted) {
                                $badge = '<span class="badge badge-deleted">حذف شده</span>';
                            } elseif (!$isActive) {
                                $badge = '<span class="badge badge-inactive">غیرفعال</span>';
                            } else {
                                $badge = '<span class="badge badge-active">فعال</span>';
                            }
                        ?>
                            <tr>
                                <td><?= htmlspecialchars($p['personnel_code'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name']) ?></td>
                                <td><?= htmlspecialchars($p['unit'] ?? '') ?></td>
                                <td><?= htmlspecialchars($p['location'] ?? '') ?></td>
                                <td><?= $badge ?></td>
                                <td style="white-space: nowrap;">
                                    <?php if (!$isDeleted): ?>
                                        <a href="edit_complete.php?person_id=<?= $p['id'] ?>" class="btn btn-sm btn-warning btn-action" title="ویرایش">
                                            <img src="images/icons/edit.png" alt="ویرایش">
                                        </a>

                                        <?php if ($isActive): ?>
                                            <a href="persons/deactivate_person.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-secondary btn-action" onclick="return confirm('غیرفعال‌سازی و انتقال تجهیزات به انبار؟')" title="غیرفعال‌سازی">
                                                <img src="images/icons/toggle-off.png" alt="غیرفعال">
                                            </a>
                                        <?php else: ?>
                                            <a href="persons/activate_person.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-success btn-action" title="فعال‌سازی">
                                                <img src="images/icons/toggle-on.png" alt="فعال">
                                            </a>
                                        <?php endif; ?>

                                        <a href="persons/delete_person.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-danger btn-action" onclick="return confirm('حذف دائمی؟')" title="حذف">
                                            <img src="images/icons/delete.png" alt="حذف">
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php elseif (isset($_GET['search'])): ?>
        <div class="alert alert-info">نتیجه‌ای یافت نشد.</div>
    <?php endif; ?>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
<script>
// ====== مرتب‌سازی جدول ======
document.querySelectorAll('#personsTable .sortable').forEach(th => {
    th.addEventListener('click', function () {
        const table = this.closest('table');
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const colIndex = Array.from(this.parentNode.children).indexOf(this);
        const sortType = this.dataset.sort || 'string';
        const isAsc = this.classList.contains('asc');

        table.querySelectorAll('th.sortable').forEach(h => h.classList.remove('asc', 'desc'));

        rows.sort((a, b) => {
            const aVal = (a.children[colIndex]?.textContent || '').trim();
            const bVal = (b.children[colIndex]?.textContent || '').trim();

            let comparison;
            if (sortType === 'number') {
                const aNum = parseFloat(aVal.replace(/[^0-9.-]/g, '')) || 0;
                const bNum = parseFloat(bVal.replace(/[^0-9.-]/g, '')) || 0;
                comparison = aNum - bNum;
            } else {
                comparison = aVal.localeCompare(bVal, 'fa');
            }

            return isAsc ? -comparison : comparison;
        });

        rows.forEach(row => tbody.appendChild(row));
        this.classList.add(isAsc ? 'desc' : 'asc');
    });
});
</script>
</body>
</html>