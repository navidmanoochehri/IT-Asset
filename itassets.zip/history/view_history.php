<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

// ---------- تب تغییرات ----------
$name = $_GET['name'] ?? '';
$asset_code = $_GET['asset_code'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$type_filter = $_GET['type_filter'] ?? '';
$showLatest = isset($_GET['latest']);

$where = [];
$params = [];

if ($showLatest) {
    $sql = "SELECT cl.*, p.first_name, p.last_name, p.personnel_code
            FROM change_log cl JOIN persons p ON cl.person_id = p.id
            ORDER BY cl.created_at DESC LIMIT 50";
    $stmt = $pdo->query($sql);
    $logs = $stmt->fetchAll();
} else {
    if (!empty($name)) {
        $where[] = "(p.first_name LIKE ? OR p.last_name LIKE ?)";
        $params[] = "%$name%"; $params[] = "%$name%";
    }
    if (!empty($asset_code)) {
        $where[] = "cl.related_asset_code LIKE ?";
        $params[] = "%$asset_code%";
    }
    if (!empty($date_from)) {
        $gFrom = jalali_to_gregorian($date_from);
        if ($gFrom) { $where[] = "DATE(cl.created_at) >= ?"; $params[] = $gFrom; }
    }
    if (!empty($date_to)) {
        $gTo = jalali_to_gregorian($date_to);
        if ($gTo) { $where[] = "DATE(cl.created_at) <= ?"; $params[] = $gTo; }
    }
    if (!empty($type_filter) && in_array($type_filter, ['create','update','delete'])) {
        $where[] = "cl.change_type = ?";
        $params[] = $type_filter;
    }
    $sql = "SELECT cl.*, p.first_name, p.last_name, p.personnel_code
            FROM change_log cl JOIN persons p ON cl.person_id = p.id";
    if (!empty($where)) $sql .= " WHERE " . implode(" AND ", $where);
    $sql .= " ORDER BY cl.created_at DESC LIMIT 200";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
}

// ---------- تب رخدادهای تجهیزات ----------
$ae_search = $_GET['ae_search'] ?? '';
$ae_type = $_GET['ae_type'] ?? '';
$ae_date_from = $_GET['ae_date_from'] ?? '';
$ae_date_to = $_GET['ae_date_to'] ?? '';
$ae_where = [];
$ae_params = [];

if (!empty($ae_search)) {
    $ae_where[] = "(p.first_name LIKE ? OR p.last_name LIKE ? OR p.personnel_code LIKE ? OR ae.field_name LIKE ?)";
    $like = "%$ae_search%";
    $ae_params = [$like,$like,$like,$like];
}
if (!empty($ae_type)) {
    $ae_where[] = "ae.event_type = ?";
    $ae_params[] = $ae_type;
}
if (!empty($ae_date_from)) {
    $g = jalali_to_gregorian($ae_date_from);
    if ($g) { $ae_where[] = "DATE(ae.created_at) >= ?"; $ae_params[] = $g; }
}
if (!empty($ae_date_to)) {
    $g = jalali_to_gregorian($ae_date_to);
    if ($g) { $ae_where[] = "DATE(ae.created_at) <= ?"; $ae_params[] = $g; }
}

$ae_sql = "SELECT ae.*, p.first_name, p.last_name, p.personnel_code, i.case_name
           FROM asset_events ae
           JOIN persons p ON ae.person_id = p.id
           JOIN inventory i ON ae.inventory_id = i.id";
if (!empty($ae_where)) $ae_sql .= " WHERE " . implode(" AND ", $ae_where);
$ae_sql .= " ORDER BY ae.created_at DESC LIMIT 200";
$ae_stmt = $pdo->prepare($ae_sql);
$ae_stmt->execute($ae_params);
$events = $ae_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8"><title>سابقه و رخدادها</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%, 100% { transform: translate(0,0) scale(1); } 33% { transform: translate(40px,-40px) scale(1.05); } 66% { transform: translate(-30px,30px) scale(0.95); } }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .log-detail { font-size: 0.85rem; }
        .badge-create { background-color: #198754; }
        .badge-update { background-color: #ffc107; color: #000; }
        .badge-delete { background-color: #dc3545; }

        .table-sm-custom { font-size: 0.85rem; }
        .table-sm-custom th, .table-sm-custom td { padding: 8px 10px; vertical-align: middle; white-space: nowrap; }
        .table-sm-custom td.log-detail { white-space: normal; }
        .sortable { cursor: pointer; user-select: none; }
        .sortable::after { content: ' ↕'; font-size: 0.8rem; color: #aaa; }
        .sortable.asc::after { content: ' ↑'; color: #333; }
        .sortable.desc::after { content: ' ↓'; color: #333; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between">
        <a href="../dashboard.php" class="btn btn-primary btn-sm"><img src="../images/icons/home.png" width="18"> داشبورد</a>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <h3 class="text-center mb-4">سوابق و رخدادها</h3>
    <ul class="nav nav-pills justify-content-center mb-4" id="historyTabs">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="pill" href="#tab-log">تغییرات کلی</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-events">رخدادهای تجهیزات</a></li>
    </ul>

    <div class="tab-content">
        <!-- تب تغییرات -->
        <div class="tab-pane fade show active" id="tab-log">
            <div class="card"><div class="card-header"><h5>جستجو در تغییرات</h5></div>
                <div class="card-body">
                    <form method="get" class="row g-2 align-items-end">
                        <div class="col-md-2"><input name="name" class="form-control" placeholder="نام/خانوادگی" value="<?=htmlspecialchars($name)?>"></div>
                        <div class="col-md-2"><input name="asset_code" class="form-control" placeholder="کد اموال" value="<?=htmlspecialchars($asset_code)?>"></div>
                        <div class="col-md-2"><input name="date_from" class="form-control" placeholder="از تاریخ (شمسی)" value="<?=htmlspecialchars($date_from)?>"></div>
                        <div class="col-md-2"><input name="date_to" class="form-control" placeholder="تا تاریخ" value="<?=htmlspecialchars($date_to)?>"></div>
                        <div class="col-md-2"><select name="type_filter" class="form-select"><option value="">همه</option><option value="create">ایجاد</option><option value="update">ویرایش</option><option value="delete">حذف</option></select></div>
                        <div class="col-md-1">
                            <div class="d-flex gap-1">
                                <button type="submit" class="btn btn-primary" title="فیلتر"><img src="../images/icons/filter.png" width="20" height="20"></button>
                                <button type="button" class="btn btn-success" onclick="exportLogToXLSX()" title="خروجی Excel"><img src="../images/icons/excel.png" width="20" height="20"></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-header d-flex justify-content-between"><span>نتایج (<?= count($logs) ?> مورد)</span></div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm-custom" id="logTable">
                            <thead><tr>
                                <th class="sortable" data-sort="date">زمان</th>
                                <th class="sortable" data-sort="string">فرد</th>
                                <th class="sortable" data-sort="string">کد</th>
                                <th class="sortable" data-sort="string">نوع</th>
                                <th>توضیحات</th>
                                <th class="sortable" data-sort="string">کد اموال</th>
                                <th class="sortable" data-sort="string">کاربر</th>
                            </tr></thead>
                            <tbody>
                                <?php foreach($logs as $log): 
                                    $badge = $log['change_type']=='create'?'<span class="badge badge-create">ایجاد</span>':($log['change_type']=='update'?'<span class="badge badge-update">ویرایش</span>':'<span class="badge badge-delete">حذف</span>');
                                ?>
                                <tr>
                                    <td><?= gregorian_to_jalali($log['created_at']) ?></td>
                                    <td><?= htmlspecialchars($log['first_name'].' '.$log['last_name']) ?></td>
                                    <td><?= htmlspecialchars($log['personnel_code'] ?? '-') ?></td>
                                    <td><?= $badge ?></td>
                                    <td class="log-detail"><?= nl2br(htmlspecialchars($log['change_description'])) ?></td>
                                    <td><?= htmlspecialchars($log['related_asset_code'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($log['changed_by']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- تب رخدادهای تجهیزات -->
        <div class="tab-pane fade" id="tab-events">
            <div class="card"><div class="card-header"><h5>جستجو در رخدادها</h5></div>
                <div class="card-body">
                    <form method="get" class="row g-2 align-items-end">
                        <div class="col-md-3"><input name="ae_search" class="form-control" placeholder="نام/کد/قطعه" value="<?=htmlspecialchars($ae_search)?>"></div>
                        <div class="col-md-2"><select name="ae_type" class="form-select">
                            <option value="">همه انواع</option>
                            <option value="failure" <?=$ae_type=='failure'?'selected':''?>>خرابی - اسقاط</option>
                            <option value="repair" <?=$ae_type=='repair'?'selected':''?>>تعمیر - ارسال به پیمانکار</option>
                            <option value="replace" <?=$ae_type=='replace'?'selected':''?>>تعویض</option>
                            <option value="upgrade" <?=$ae_type=='upgrade'?'selected':''?>>ارتقا</option>
                            <option value="transfer_warehouse" <?=$ae_type=='transfer_warehouse'?'selected':''?>>انتقال به انبار</option>
                            <option value="replace_defective" <?=$ae_type=='replace_defective'?'selected':''?>>جایگزینی با قطعه سالم</option>
                        </select></div>
                        <div class="col-md-2"><input name="ae_date_from" class="form-control" placeholder="از تاریخ (شمسی)" value="<?=htmlspecialchars($ae_date_from)?>"></div>
                        <div class="col-md-2"><input name="ae_date_to" class="form-control" placeholder="تا تاریخ" value="<?=htmlspecialchars($ae_date_to)?>"></div>
                        <div class="col-md-1">
                            <div class="d-flex gap-1">
                                <button type="submit" class="btn btn-primary" title="فیلتر"><img src="../images/icons/filter.png" width="20" height="20"></button>
                                <button type="button" class="btn btn-success" onclick="exportEventsToXLSX()" title="خروجی Excel"><img src="../images/icons/excel.png" width="20" height="20"></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><span>نتایج (<?= count($events) ?> مورد)</span></div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm-custom" id="eventsTable">
                            <thead><tr>
                                <th class="sortable" data-sort="date">زمان</th>
                                <th class="sortable" data-sort="string">فرد</th>
                                <th class="sortable" data-sort="string">کد</th>
                                <th class="sortable" data-sort="string">نوع</th>
                                <th class="sortable" data-sort="string">قطعه</th>
                                <th class="sortable" data-sort="string">مقدار قبلی</th>
                                <th class="sortable" data-sort="string">مقدار جدید</th>
                                <th>توضیحات</th>
                                <th class="sortable" data-sort="string">ثبت‌کننده</th>
                            </tr></thead>
                            <tbody>
                                <?php foreach($events as $ev): 
                                    $typeLabel = [
                                        'failure' => 'خرابی - اسقاط',
                                        'repair'  => 'تعمیر - ارسال به پیمانکار',
                                        'replace' => 'تعویض',
                                        'upgrade' => 'ارتقا',
                                        'transfer_warehouse' => 'انتقال به انبار',
                                        'replace_defective' => 'جایگزینی'
                                    ][$ev['event_type']];
                                ?>
                                <tr>
                                    <td><?= gregorian_to_jalali($ev['created_at']) ?></td>
                                    <td><?= htmlspecialchars($ev['first_name'].' '.$ev['last_name']) ?></td>
                                    <td><?= htmlspecialchars($ev['personnel_code'] ?? '-') ?></td>
                                    <td><?= $typeLabel ?></td>
                                    <td><?= htmlspecialchars($ev['field_name']) ?></td>
                                    <td><?= htmlspecialchars($ev['old_value']) ?></td>
                                    <td><?= htmlspecialchars($ev['new_value']) ?></td>
                                    <td><?= htmlspecialchars($ev['description']) ?></td>
                                    <td><?= htmlspecialchars($ev['created_by']) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/xlsx.full.min.js"></script>
<script>
function exportLogToXLSX() {
    const wb = XLSX.utils.book_new();
    const rows = [['زمان', 'فرد', 'کد پرسنلی', 'نوع', 'توضیحات', 'کد اموال', 'کاربر']];
    <?php foreach($logs as $log): ?>
        rows.push(['<?= gregorian_to_jalali($log['created_at']) ?>','<?= htmlspecialchars($log['first_name'].' '.$log['last_name']) ?>','<?= htmlspecialchars($log['personnel_code'] ?? '') ?>','<?= $log['change_type']=='create'?'ایجاد':($log['change_type']=='update'?'ویرایش':'حذف') ?>','<?= htmlspecialchars($log['change_description']) ?>','<?= htmlspecialchars($log['related_asset_code'] ?? '') ?>','<?= htmlspecialchars($log['changed_by']) ?>']);
    <?php endforeach; ?>
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'تغییرات');
    XLSX.writeFile(wb, 'تاریخچه_تغییرات.xlsx');
}
function exportEventsToXLSX() {
    const wb = XLSX.utils.book_new();
    const rows = [['زمان', 'فرد', 'کد پرسنلی', 'نوع', 'قطعه', 'مقدار قبلی', 'مقدار جدید', 'توضیحات', 'ثبت‌کننده']];
    <?php foreach($events as $ev): ?>
        rows.push(['<?= gregorian_to_jalali($ev['created_at']) ?>','<?= htmlspecialchars($ev['first_name'].' '.$ev['last_name']) ?>','<?= htmlspecialchars($ev['personnel_code'] ?? '') ?>','<?= ['failure'=>'خرابی - اسقاط','repair'=>'تعمیر - ارسال به پیمانکار','replace'=>'تعویض','upgrade'=>'ارتقا','transfer_warehouse'=>'انتقال به انبار','replace_defective'=>'جایگزینی'][$ev['event_type']] ?>','<?= htmlspecialchars($ev['field_name']) ?>','<?= htmlspecialchars($ev['old_value']) ?>','<?= htmlspecialchars($ev['new_value']) ?>','<?= htmlspecialchars($ev['description']) ?>','<?= htmlspecialchars($ev['created_by']) ?>']);
    <?php endforeach; ?>
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'رخدادها');
    XLSX.writeFile(wb, 'رخدادهای_تجهیزات.xlsx');
}
function enableSorting(tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    table.querySelectorAll('th.sortable').forEach(th => {
        th.addEventListener('click', function () {
            const tbody = table.querySelector('tbody');
            const rows = Array.from(tbody.querySelectorAll('tr'));
            const colIndex = Array.from(this.parentNode.children).indexOf(this);
            const sortType = this.dataset.sort || 'string';
            const isAsc = this.classList.contains('asc');
            table.querySelectorAll('th.sortable').forEach(h => h.classList.remove('asc', 'desc'));
            rows.sort((a, b) => {
                const aVal = (a.children[colIndex]?.textContent || '').trim();
                const bVal = (b.children[colIndex]?.textContent || '').trim();
                let comparison;
                if (sortType === 'number') comparison = (parseFloat(aVal.replace(/[^0-9.-]/g, '')) || 0) - (parseFloat(bVal.replace(/[^0-9.-]/g, '')) || 0);
                else if (sortType === 'date') comparison = aVal.replace(/\//g, '').localeCompare(bVal.replace(/\//g, ''));
                else comparison = aVal.localeCompare(bVal, 'fa');
                return isAsc ? -comparison : comparison;
            });
            rows.forEach(row => tbody.appendChild(row));
            this.classList.add(isAsc ? 'desc' : 'asc');
        });
    });
}
enableSorting('logTable');
enableSorting('eventsTable');
</script>
</body>
</html>