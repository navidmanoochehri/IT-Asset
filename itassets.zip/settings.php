<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';
require_once 'includes/master_config.php';

// فقط super_admin می‌تواند این صفحه را ببیند
if (($_SESSION['admin_role'] ?? '') !== 'super_admin') {
    die('دسترسی مجاز نیست.');
}

$msg = '';

// ========== ۱. تغییر رمز ==========
if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = $master_pdo->prepare("SELECT password FROM admin_users WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();

    if (password_verify($current, $admin['password'])) {
        if ($new === $confirm && strlen($new) >= 4) {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $master_pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?")->execute([$hash, $_SESSION['admin_id']]);
            $msg = '<div class="alert alert-success">✅ رمز عبور با موفقیت تغییر کرد.</div>';
        } else {
            $msg = '<div class="alert alert-danger">رمز جدید معتبر نیست یا با تکرارش مغایرت دارد.</div>';
        }
    } else {
        $msg = '<div class="alert alert-danger">رمز فعلی اشتباه است.</div>';
    }
}

// ========== ۲. افزودن / ویرایش کاربر ==========
if (isset($_POST['save_user'])) {
    $userId   = $_POST['user_id'] ?? 0;
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $fullname = trim($_POST['full_name'] ?? '');
    $role     = $_POST['role'] ?? 'branch_admin';
    $branchId = $_POST['branch_id'] ?? null;
    $isActive = $_POST['is_active'] ?? 1;
    $perms = [
        'can_manage_persons'   => $_POST['can_manage_persons'] ?? 0,
        'can_manage_inventory' => $_POST['can_manage_inventory'] ?? 0,
        'can_manage_warehouse' => $_POST['can_manage_warehouse'] ?? 0,
        'can_view_reports'     => $_POST['can_view_reports'] ?? 0,
        'can_export'           => $_POST['can_export'] ?? 0,
        'can_manage_branches'  => $_POST['can_manage_branches'] ?? 0,
    ];

    if ($userId) {
        $sql = "UPDATE admin_users SET username=?, full_name=?, role=?, branch_id=?, is_active=?,
                can_manage_persons=?, can_manage_inventory=?, can_manage_warehouse=?,
                can_view_reports=?, can_export=?, can_manage_branches=? WHERE id=?";
        $master_pdo->prepare($sql)->execute([
            $username, $fullname, $role, $branchId ?: null, $isActive,
            $perms['can_manage_persons'], $perms['can_manage_inventory'], $perms['can_manage_warehouse'],
            $perms['can_view_reports'], $perms['can_export'], $perms['can_manage_branches'], $userId
        ]);
        if (!empty($password)) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $master_pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?")->execute([$hash, $userId]);
        }
        $msg = '<div class="alert alert-success">✅ کاربر به‌روزرسانی شد.</div>';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO admin_users (username, password, full_name, role, branch_id, is_active,
                can_manage_persons, can_manage_inventory, can_manage_warehouse,
                can_view_reports, can_export, can_manage_branches)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        $master_pdo->prepare($sql)->execute([
            $username, $hash, $fullname, $role, $branchId ?: null, $isActive,
            $perms['can_manage_persons'], $perms['can_manage_inventory'], $perms['can_manage_warehouse'],
            $perms['can_view_reports'], $perms['can_export'], $perms['can_manage_branches']
        ]);
        $msg = '<div class="alert alert-success">✅ کاربر جدید اضافه شد.</div>';
    }
}

// ========== ۳. غیرفعال‌سازی / حذف کاربر ==========
if (isset($_GET['toggle_user'])) {
    $master_pdo->prepare("UPDATE admin_users SET is_active = NOT is_active WHERE id = ?")->execute([$_GET['toggle_user']]);
    header("Location: settings.php"); exit;
}
if (isset($_GET['delete_user'])) {
    $master_pdo->prepare("DELETE FROM admin_users WHERE id = ? AND role != 'super_admin'")->execute([$_GET['delete_user']]);
    header("Location: settings.php"); exit;
}

// ========== ۴. مدیریت شعب ==========
if (isset($_POST['save_branch'])) {
    $branchId = $_POST['branch_id'] ?? 0;
    $name   = $_POST['branch_name'] ?? '';
    $dbHost = $_POST['db_host'] ?? 'localhost';
    $dbName = $_POST['db_name'] ?? '';
    $dbUser = $_POST['db_user'] ?? '';
    $dbPass = $_POST['db_pass'] ?? '';
    $active = $_POST['is_active'] ?? 1;

    if ($branchId) {
        $master_pdo->prepare("UPDATE branches SET name=?, db_host=?, db_name=?, db_user=?, db_pass=?, is_active=? WHERE id=?")
            ->execute([$name, $dbHost, $dbName, $dbUser, $dbPass, $active, $branchId]);
        $msg = '<div class="alert alert-success">✅ شعبه به‌روزرسانی شد.</div>';
    } else {
        $master_pdo->prepare("INSERT INTO branches (name, db_host, db_name, db_user, db_pass, is_active) VALUES (?,?,?,?,?,?)")
            ->execute([$name, $dbHost, $dbName, $dbUser, $dbPass, $active]);
        $msg = '<div class="alert alert-success">✅ شعبه جدید اضافه شد.</div>';
    }
}
if (isset($_GET['toggle_branch'])) {
    $master_pdo->prepare("UPDATE branches SET is_active = NOT is_active WHERE id = ?")->execute([$_GET['toggle_branch']]);
    header("Location: settings.php"); exit;
}

// ========== ۵. بکاپ ==========
if (isset($_POST['backup_sql'])) {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $dump = "";
    foreach ($tables as $table) {
        $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch();
        $dump .= $create['Create Table'] . ";\n\n";
        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll();
        foreach ($rows as $row) {
            $vals = array_map(fn($v) => $pdo->quote($v), $row);
            $dump .= "INSERT INTO `$table` VALUES (" . implode(',', $vals) . ");\n";
        }
        $dump .= "\n\n";
    }
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="backup_' . date('Ymd_His') . '.sql"');
    echo $dump; exit;
}
if (isset($_POST['backup_excel'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="backup_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        fputcsv($out, ["-- $table --"]);
        $cols = $pdo->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_COLUMN);
        fputcsv($out, $cols);
        $rows = $pdo->query("SELECT * FROM $table")->fetchAll();
        foreach ($rows as $row) fputcsv($out, $row);
        fputcsv($out, []);
    }
    fclose($out); exit;
}

// ========== ۶. پاکسازی داده‌ها ==========
if (isset($_POST['reset_data'])) {
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) $pdo->exec("TRUNCATE TABLE `$table`");
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    $msg = '<div class="alert alert-danger">❌ تمام داده‌های این شعبه پاک شدند.</div>';
}

// دریافت داده‌ها
$admins   = $master_pdo->query("SELECT a.*, b.name as branch_name FROM admin_users a LEFT JOIN branches b ON a.branch_id = b.id ORDER BY a.id")->fetchAll();
$branches = $master_pdo->query("SELECT * FROM branches ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تنظیمات مدیر سیستم</title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%,100%{transform: translate(0,0) scale(1);} 33%{transform: translate(40px,-40px) scale(1.05);} 66%{transform: translate(-30px,30px) scale(0.95);} }
        .navbar-dash {
            background: rgba(255,255,255,0.85); backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0;
            position: sticky; top: 0; z-index: 100;
        }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .section-header { padding: 14px 20px; background: #4e73df; color: white; border-radius: 20px 20px 0 0; font-weight: bold; }
        .btn-icon { width: 36px; height: 36px; border-radius: 12px; display: flex; align-items: center; justify-content: center; padding: 0; border: none; }
        .btn-logout { background: linear-gradient(135deg, #dc3545, #b02a37); }
        .btn-logout img { filter: brightness(0) invert(1); width: 20px; }
        .table > :not(caption) > * > * { padding: 10px 14px; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="dashboard.php" class="btn btn-primary btn-sm"><img src="images/icons/home.png" width="18" style="margin-left:4px;"> داشبورد</a>
        <div class="d-flex align-items-center gap-3">
            <span style="color:#334155;"><?= htmlspecialchars($_SESSION['admin_name']) ?> (مدیرکل)</span>
            <a href="logout.php" class="btn-icon btn-logout" title="خروج"><img src="images/icons/logout.png" alt="خروج"></a>
        </div>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <h3 class="mb-4">تنظیمات مدیر سیستم</h3>
    <?= $msg ?>

    <!-- ۱. تغییر رمز -->
    <div class="card">
        <div class="section-header">تغییر رمز عبور</div>
        <div class="card-body">
            <form method="post" class="row g-3">
                <div class="col-md-4"><input type="password" name="current_password" class="form-control" placeholder="رمز فعلی" required></div>
                <div class="col-md-4"><input type="password" name="new_password" class="form-control" placeholder="رمز جدید" required></div>
                <div class="col-md-4"><input type="password" name="confirm_password" class="form-control" placeholder="تکرار رمز جدید" required></div>
                <div class="col-12"><button type="submit" name="change_password" class="btn btn-primary">تغییر رمز</button></div>
            </form>
        </div>
    </div>

    <!-- ۲. مدیریت کاربران -->
    <div class="card">
        <div class="section-header">مدیریت کاربران</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-sm">
                    <thead><tr><th>نام کاربری</th><th>نام کامل</th><th>نقش</th><th>شعبه</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                    <tbody>
                        <?php foreach ($admins as $a): ?>
                        <tr>
                            <td><?= htmlspecialchars($a['username']) ?></td>
                            <td><?= htmlspecialchars($a['full_name']) ?></td>
                            <td><?= $a['role'] === 'super_admin' ? 'مدیرکل' : 'مدیر شعبه' ?></td>
                            <td><?= htmlspecialchars($a['branch_name'] ?? '-') ?></td>
                            <td><?= $a['is_active'] ? '<span class="badge bg-success">فعال</span>' : '<span class="badge bg-danger">غیرفعال</span>' ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning" onclick="editUser(<?= htmlspecialchars(json_encode($a)) ?>)">ویرایش</button>
                                <?php if ($a['role'] !== 'super_admin'): ?>
                                    <a href="?toggle_user=<?= $a['id'] ?>" class="btn btn-sm btn-secondary"><?= $a['is_active'] ? 'غیرفعال' : 'فعال' ?></a>
                                    <a href="?delete_user=<?= $a['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('مطمئنید؟')">حذف</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <form method="post" id="userForm" class="row g-3 mt-3">
                <input type="hidden" name="user_id" id="user_id">
                <div class="col-md-3"><input type="text" name="username" id="user_username" class="form-control" placeholder="نام کاربری" required></div>
                <div class="col-md-3"><input type="password" name="password" id="user_password" class="form-control" placeholder="رمز عبور (برای ویرایش خالی بگذارید)"></div>
                <div class="col-md-3"><input type="text" name="full_name" id="user_fullname" class="form-control" placeholder="نام کامل" required></div>
                <div class="col-md-3">
                    <select name="role" id="user_role" class="form-select" required>
                        <option value="branch_admin">مدیر شعبه</option>
                        <option value="super_admin">مدیرکل</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="branch_id" id="user_branch" class="form-select">
                        <option value="">-- انتخاب شعبه --</option>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="is_active" id="user_active" class="form-select">
                        <option value="1">فعال</option>
                        <option value="0">غیرفعال</option>
                    </select>
                </div>
                <div class="col-12"><strong>دسترسی‌ها:</strong></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_persons" id="perm_persons"> مدیریت پرسنل</label></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_inventory" id="perm_inventory"> مدیریت تجهیزات</label></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_warehouse" id="perm_warehouse"> مدیریت انبار</label></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_view_reports" id="perm_reports"> مشاهده گزارش‌ها</label></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_export" id="perm_export"> خروجی</label></div>
                <div class="col-md-2"><label class="form-check"><input class="form-check-input" type="checkbox" name="can_manage_branches" id="perm_branches"> مدیریت شعب</label></div>
                <div class="col-12"><button type="submit" name="save_user" class="btn btn-success">ذخیره کاربر</button></div>
            </form>
        </div>
    </div>

    <!-- ۳. مدیریت شعب -->
    <div class="card">
        <div class="section-header">مدیریت شعب</div>
        <div class="card-body">
            <table class="table table-sm">
                <thead><tr><th>نام</th><th>هاست</th><th>دیتابیس</th><th>کاربر</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                <tbody>
                    <?php foreach ($branches as $b): ?>
                    <tr>
                        <td><?= htmlspecialchars($b['name']) ?></td>
                        <td><?= htmlspecialchars($b['db_host']) ?></td>
                        <td><?= htmlspecialchars($b['db_name']) ?></td>
                        <td><?= htmlspecialchars($b['db_user']) ?></td>
                        <td><?= $b['is_active'] ? '<span class="badge bg-success">فعال</span>' : '<span class="badge bg-danger">غیرفعال</span>' ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick="editBranch(<?= htmlspecialchars(json_encode($b)) ?>)">ویرایش</button>
                            <a href="?toggle_branch=<?= $b['id'] ?>" class="btn btn-sm btn-secondary"><?= $b['is_active'] ? 'غیرفعال' : 'فعال' ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <form method="post" id="branchForm" class="row g-3 mt-3">
                <input type="hidden" name="branch_id" id="branch_id">
                <div class="col-md-4"><input type="text" name="branch_name" id="branch_name" class="form-control" placeholder="نام شعبه" required></div>
                <div class="col-md-2"><input type="text" name="db_host" id="branch_host" class="form-control" placeholder="هاست" value="localhost"></div>
                <div class="col-md-2"><input type="text" name="db_name" id="branch_dbname" class="form-control" placeholder="نام دیتابیس" required></div>
                <div class="col-md-2"><input type="text" name="db_user" id="branch_user" class="form-control" placeholder="کاربر" value="root"></div>
                <div class="col-md-2"><input type="text" name="db_pass" id="branch_pass" class="form-control" placeholder="رمز عبور"></div>
                <div class="col-md-2"><select name="is_active" id="branch_active" class="form-select"><option value="1">فعال</option><option value="0">غیرفعال</option></select></div>
                <div class="col-12"><button type="submit" name="save_branch" class="btn btn-success">ذخیره شعبه</button></div>
            </form>
        </div>
    </div>

    <!-- ۴. بکاپ -->
    <div class="card border-primary">
        <div class="section-header bg-primary">بکاپ‌گیری</div>
        <div class="card-body">
            <form method="post" class="d-flex gap-2">
                <button type="submit" name="backup_sql" class="btn btn-outline-primary">دانلود SQL</button>
                <button type="submit" name="backup_excel" class="btn btn-outline-success">دانلود Excel (CSV)</button>
            </form>
        </div>
    </div>

    <!-- ۵. پاکسازی -->
    <div class="card border-danger">
        <div class="section-header bg-danger text-white" style="border-radius: 20px 20px 0 0;">پاکسازی کامل داده‌ها</div>
        <div class="card-body">
            <form method="post" onsubmit="return confirm('آیا مطمئن هستید؟');">
                <button type="submit" name="reset_data" class="btn btn-danger">حذف همه داده‌های این شعبه</button>
            </form>
        </div>
    </div>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
<script>
function editUser(u) {
    document.getElementById('user_id').value = u.id;
    document.getElementById('user_username').value = u.username;
    document.getElementById('user_password').value = '';
    document.getElementById('user_fullname').value = u.full_name;
    document.getElementById('user_role').value = u.role;
    document.getElementById('user_branch').value = u.branch_id ?? '';
    document.getElementById('user_active').value = u.is_active;
    document.getElementById('perm_persons').checked = u.can_manage_persons == 1;
    document.getElementById('perm_inventory').checked = u.can_manage_inventory == 1;
    document.getElementById('perm_warehouse').checked = u.can_manage_warehouse == 1;
    document.getElementById('perm_reports').checked = u.can_view_reports == 1;
    document.getElementById('perm_export').checked = u.can_export == 1;
    document.getElementById('perm_branches').checked = u.can_manage_branches == 1;
}
function editBranch(b) {
    document.getElementById('branch_id').value = b.id;
    document.getElementById('branch_name').value = b.name;
    document.getElementById('branch_host').value = b.db_host;
    document.getElementById('branch_dbname').value = b.db_name;
    document.getElementById('branch_user').value = b.db_user;
    document.getElementById('branch_pass').value = b.db_pass;
    document.getElementById('branch_active').value = b.is_active;
}
</script>
</body>
</html>