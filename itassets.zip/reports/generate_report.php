<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

// ------------------ داده‌های گزارش‌های آماده ------------------
$items = $pdo->query("SELECT 
    SUM(case_name != '' AND case_name IS NOT NULL) AS cases,
    SUM(monitor_name != '' AND monitor_name IS NOT NULL) AS monitors,
    SUM(keyboard_name != '' AND keyboard_name IS NOT NULL) AS keyboards,
    SUM(mouse_name != '' AND mouse_name IS NOT NULL) AS mice,
    SUM(phone_name != '' AND phone_name IS NOT NULL) AS phones,
    SUM(headset_name != '' AND headset_name IS NOT NULL) AS headsets,
    SUM(webcam_name != '' AND webcam_name IS NOT NULL) AS webcams,
    SUM(printer_name != '' AND printer_name IS NOT NULL) AS printers,
    SUM(scanner_name != '' AND scanner_name IS NOT NULL) AS scanners,
    SUM(laptop_name != '' AND laptop_name IS NOT NULL) AS laptops
FROM inventory")->fetch();

$status = $pdo->query("SELECT 
    SUM(is_active = 1 AND (is_deleted = 0 OR is_deleted IS NULL)) AS active,
    SUM(is_active = 0 AND (is_deleted = 0 OR is_deleted IS NULL)) AS inactive,
    SUM(is_deleted = 1) AS deleted
FROM persons")->fetch();

$warehouse = $pdo->query("SELECT category, COUNT(*) as cnt FROM warehouse_items GROUP BY category")->fetchAll();
$history = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as cnt
    FROM change_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY month ORDER BY month")->fetchAll();

$unitData = $pdo->query("SELECT p.unit, COUNT(i.id) as cnt
    FROM persons p LEFT JOIN inventory i ON p.id = i.person_id
    WHERE p.is_active = 1 AND (p.is_deleted = 0 OR p.is_deleted IS NULL)
    GROUP BY p.unit ORDER BY cnt DESC")->fetchAll();

$oldest = $pdo->query("SELECT item_name, category, transferred_date, p.first_name, p.last_name
    FROM warehouse_items w LEFT JOIN persons p ON w.transferred_from_person_id = p.id
    ORDER BY w.transferred_date ASC LIMIT 10")->fetchAll();

$inventoryList = $pdo->query("SELECT p.personnel_code, p.first_name, p.last_name, p.unit,
    i.case_name, i.case_code, i.monitor_name, i.monitor_code,
    i.keyboard_name, i.keyboard_code, i.mouse_name, i.mouse_serial,
    i.phone_name, i.phone_code, i.headset_name, i.webcam_name, i.webcam_serial,
    i.printer_name, i.printer_code, i.scanner_name, i.scanner_code,
    i.laptop_name, i.laptop_code, i.dvd_rw, i.motherboard, i.cpu, i.graphics,
    i.ram, i.ssd_nvme, i.hdd, i.os, i.other, i.description
FROM persons p
LEFT JOIN inventory i ON p.id = i.person_id
ORDER BY p.last_name")->fetchAll();

$warehouseList = $pdo->query("SELECT w.item_name, w.item_code, w.category, w.serial_number,
    w.transferred_date, p.first_name, p.last_name, p.personnel_code
FROM warehouse_items w
LEFT JOIN persons p ON w.transferred_from_person_id = p.id
ORDER BY w.created_at DESC")->fetchAll();

// داده‌های رخدادها
$aeData = $pdo->query("SELECT ae.*, p.first_name, p.last_name, p.personnel_code 
                       FROM asset_events ae
                       JOIN persons p ON ae.person_id = p.id
                       ORDER BY ae.created_at DESC LIMIT 200")->fetchAll();

// ------------------ AJAX برای گزارش سفارشی ------------------
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    $selectedFields = $_POST['fields'] ?? [];
    $searchTerm = trim($_POST['custom_search'] ?? '');
    
    $allowedFields = [
        'personnel_code' => 'p.personnel_code',
        'first_name' => 'p.first_name',
        'last_name' => 'p.last_name',
        'username' => 'p.username',
        'unit' => 'p.unit',
        'location' => 'p.location',
        'case_name' => 'i.case_name',
        'case_code' => 'i.case_code',
        'monitor_name' => 'i.monitor_name',
        'monitor_code' => 'i.monitor_code',
        'keyboard_name' => 'i.keyboard_name',
        'keyboard_code' => 'i.keyboard_code',
        'mouse_name' => 'i.mouse_name',
        'mouse_serial' => 'i.mouse_serial',
        'phone_name' => 'i.phone_name',
        'phone_code' => 'i.phone_code',
        'headset_name' => 'i.headset_name',
        'webcam_name' => 'i.webcam_name',
        'webcam_serial' => 'i.webcam_serial',
        'printer_name' => 'i.printer_name',
        'printer_code' => 'i.printer_code',
        'scanner_name' => 'i.scanner_name',
        'scanner_code' => 'i.scanner_code',
        'laptop_name' => 'i.laptop_name',
        'laptop_code' => 'i.laptop_code',
        'dvd_rw' => 'i.dvd_rw',
        'motherboard' => 'i.motherboard',
        'cpu' => 'i.cpu',
        'graphics' => 'i.graphics',
        'ram' => 'i.ram',
        'ssd_nvme' => 'i.ssd_nvme',
        'hdd' => 'i.hdd',
        'os' => 'i.os',
        'other' => 'i.other',
        'description' => 'i.description'
    ];

    $selectCols = [];
    $customColumns = [];
    foreach ($selectedFields as $field) {
        if (isset($allowedFields[$field])) {
            $selectCols[] = $allowedFields[$field] . ' AS ' . $field;
            $customColumns[] = $field;
        }
    }

    $result = ['html' => '', 'chartData' => null, 'columns' => $customColumns, 'tableData' => []];

    if (!empty($selectCols)) {
        $sql = "SELECT " . implode(', ', $selectCols) . " FROM persons p LEFT JOIN inventory i ON p.id = i.person_id";
        $where = [];
        $params = [];

        if (!empty($searchTerm)) {
            $like = "%$searchTerm%";
            $conditions = [];
            foreach ($customColumns as $col) {
                $conditions[] = $allowedFields[$col] . " LIKE ?";
                $params[] = $like;
            }
            $where[] = "(" . implode(" OR ", $conditions) . ")";
        }

        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }

        $sql .= " ORDER BY p.last_name ASC LIMIT 500";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $customResults = $stmt->fetchAll();

        $result['tableData'] = $customResults;

        // ساخت HTML جدول
        $html = '<div class="d-flex justify-content-between mb-3">';
        $html .= '<strong>' . count($customResults) . ' رکورد یافت شد</strong>';
        $html .= '<div>';
        $html .= '<button onclick="exportCustomXLSX()" class="btn btn-sm btn-success"><img src="../images/icons/export.png" width="16"> XLSX</button> ';
        $html .= '<button onclick="window.print()" class="btn btn-sm btn-secondary"><img src="../images/icons/print.png" width="16"> چاپ</button>';
        $html .= '</div></div>';
        $html .= '<div class="table-responsive"><table class="table table-hover table-sm"><thead><tr>';
        foreach ($customColumns as $col) {
            $html .= '<th>' . htmlspecialchars($allowedFields[$col] ?? $col) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($customResults as $row) {
            $html .= '<tr>';
            foreach ($customColumns as $col) {
                $html .= '<td>' . htmlspecialchars($row[$col] ?? '') . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></div>';
        $result['html'] = $html;

        // داده‌های نمودار بر اساس اولین فیلد
        if (!empty($customColumns) && isset($_GET['chart'])) {
            $firstCol = $customColumns[0];
            $chartSql = "SELECT $allowedFields[$firstCol] AS label, COUNT(*) AS cnt FROM persons p LEFT JOIN inventory i ON p.id = i.person_id";
            if (!empty($where)) {
                $chartSql .= " WHERE " . implode(" AND ", $where);
            }
            $chartSql .= " GROUP BY label ORDER BY cnt DESC LIMIT 15";
            $chartStmt = $pdo->prepare($chartSql);
            $chartStmt->execute($params);
            $chartRows = $chartStmt->fetchAll();
            $result['chartData'] = ['labels' => array_column($chartRows, 'label'), 'data' => array_column($chartRows, 'cnt')];
        }
    } else {
        $result['html'] = '<div class="alert alert-info">لطفاً حداقل یک فیلد انتخاب کنید.</div>';
    }

    header('Content-Type: application/json');
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>گزارش‌های حرفه‌ای</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%, 100% { transform: translate(0,0) scale(1); } 33% { transform: translate(40px,-40px) scale(1.05); } 66% { transform: translate(-30px,30px) scale(0.95); } }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .nav-pills .nav-link { border-radius: 20px; margin: 0 4px; }
        .nav-pills .nav-link.active { background: #4e73df; color: #fff; }
        .chart-wrapper { position: relative; width: 100%; max-width: 500px; margin: 0 auto; }
        .field-check label { font-size: 0.9rem; cursor: pointer; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between">
        <a href="../dashboard.php" class="btn btn-primary btn-sm"><img src="../images/icons/home.png" width="18"> داشبورد</a>
        <div>
            <select id="colorPalette" class="form-select form-select-sm" style="width: auto;" onchange="applyPalette(this.value)">
                <option value="blue">آبی</option><option value="green">سبز</option><option value="orange">نارنجی</option>
                <option value="purple">بنفش</option><option value="mixed">مخلوط</option>
            </select>
        </div>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <h2 class="text-center mb-4">گزارش‌های مدیریت</h2>
    <ul class="nav nav-pills justify-content-center mb-4" id="reportTabs">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="pill" href="#tab-summary">خلاصه تجهیزات</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-status">وضعیت پرسنل</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-warehouse">موجودی انبار</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-history">تاریخچه تغییرات</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-unit">بر اساس واحد</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-oldest">قدیمی‌ترین</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-full">لیست کامل اموال</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-custom">گزارش‌ساز سفارشی</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="pill" href="#tab-events">رخدادهای تجهیزات</a></li>
    </ul>

    <div class="tab-content">
        <?php
        // تابع کمکی برای تب‌های دارای نمودار
        function renderTab($id, $title, $tableHtml) {
            echo "
            <div class='tab-pane fade ". ($id === 'tab-summary' ? 'show active' : '') ."' id='$id'>
                <div class='card'>
                    <div class='card-header d-flex justify-content-between'>
                        <h5>$title</h5>
                        <div>
                            <button onclick='exportXLSX(\"$id\")' class='btn btn-sm btn-success'><img src='../images/icons/export.png' width='16'> XLSX</button>
                            <button onclick='window.print()' class='btn btn-sm btn-secondary'><img src='../images/icons/print.png' width='16'> چاپ</button>
                        </div>
                    </div>
                    <div class='card-body'>
                        <div class='row'>
                            <div class='col-md-6'>$tableHtml</div>
                            <div class='col-md-6'>
                                <div class='chart-switcher'>
                                    <button onclick='changeChart(\"$id\", \"bar\")' class='btn btn-outline-primary btn-sm'>میله‌ای</button>
                                    <button onclick='changeChart(\"$id\", \"pie\")' class='btn btn-outline-primary btn-sm'>دایره‌ای</button>
                                    <button onclick='changeChart(\"$id\", \"line\")' class='btn btn-outline-primary btn-sm'>خطی</button>
                                    <button onclick='downloadChart(\"$id\")' class='btn btn-outline-secondary btn-sm'>PNG</button>
                                </div>
                                <div class='chart-wrapper'><canvas id='chart-$id'></canvas></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>";
        }

        // تب 1 - خلاصه تجهیزات
        $table1 = "<table class='table table-hover'><thead><tr><th>نوع</th><th>تعداد</th></tr></thead><tbody>";
        $keys = ['cases','monitors','keyboards','mice','phones','headsets','webcams','printers','scanners','laptops'];
        $labels = ['کیس','مانیتور','کیبورد','ماوس','تلفن','هدست','وبکم','پرینتر','اسکنر','لپ‌تاپ'];
        foreach ($labels as $i => $name) $table1 .= "<tr><td>$name</td><td>{$items[$keys[$i]]}</td></tr>";
        $table1 .= "</tbody></table>";
        renderTab('tab-summary', 'خلاصه تجهیزات موجود', $table1);

        // تب 2 - وضعیت پرسنل
        $table2 = "<table class='table table-hover'><thead><tr><th>وضعیت</th><th>تعداد</th></tr></thead><tbody>
            <tr><td>فعال</td><td>{$status['active']}</td></tr>
            <tr><td>غیرفعال</td><td>{$status['inactive']}</td></tr>
            <tr><td>حذف شده</td><td>{$status['deleted']}</td></tr>
        </tbody></table>";
        renderTab('tab-status', 'وضعیت پرسنل', $table2);

        // تب 3 - موجودی انبار
        $table3 = "<table class='table table-hover'><thead><tr><th>دسته</th><th>تعداد</th></tr></thead><tbody>";
        foreach ($warehouse as $w) $table3 .= "<tr><td>{$w['category']}</td><td>{$w['cnt']}</td></tr>";
        $table3 .= "</tbody></table>";
        renderTab('tab-warehouse', 'موجودی انبار', $table3);

        // تب 4 - تاریخچه تغییرات
        $table4 = "<table class='table table-hover'><thead><tr><th>ماه</th><th>تعداد</th></tr></thead><tbody>";
        foreach ($history as $h) $table4 .= "<tr><td>{$h['month']}</td><td>{$h['cnt']}</td></tr>";
        $table4 .= "</tbody></table>";
        renderTab('tab-history', 'تغییرات ۶ ماه اخیر', $table4);

        // تب 5 - بر اساس واحد
        $table5 = "<table class='table table-hover'><thead><tr><th>واحد</th><th>تجهیزات</th></tr></thead><tbody>";
        foreach ($unitData as $u) $table5 .= "<tr><td>{$u['unit']}</td><td>{$u['cnt']}</td></tr>";
        $table5 .= "</tbody></table>";
        renderTab('tab-unit', 'تجهیزات بر اساس واحد', $table5);

        // تب 6 - قدیمی‌ترین تجهیزات (بدون نمودار)
        $table6 = "<table class='table table-hover'><thead><tr><th>نام</th><th>دسته</th><th>تاریخ ورود</th><th>فرد قبلی</th></tr></thead><tbody>";
        foreach ($oldest as $o) {
            $date = gregorian_to_jalali($o['transferred_date'] ?? '');
            $table6 .= "<tr><td>{$o['item_name']}</td><td>{$o['category']}</td><td>$date</td><td>{$o['first_name']} {$o['last_name']}</td></tr>";
        }
        $table6 .= "</tbody></table>";
        echo "<div class='tab-pane fade' id='tab-oldest'><div class='card'><div class='card-header'><h5>قدیمی‌ترین تجهیزات انبار</h5></div><div class='card-body'>$table6</div></div></div>";

        // تب 7 - لیست کامل اموال
        $invTable = "<h5>اموال واگذارشده به پرسنل</h5><div class='table-responsive'><table class='table table-hover table-sm'><thead><tr><th>کد</th><th>نام</th><th>کیس</th><th>مانیتور</th><th>لپ‌تاپ</th><th>پردازنده</th><th>RAM</th></tr></thead><tbody>";
        foreach ($inventoryList as $r) {
            $invTable .= "<tr><td>{$r['personnel_code']}</td><td>{$r['first_name']} {$r['last_name']}</td><td>{$r['case_name']}</td><td>{$r['monitor_name']}</td><td>{$r['laptop_name']}</td><td>{$r['cpu']}</td><td>{$r['ram']}</td></tr>";
        }
        $invTable .= "</tbody></table></div>";

        $whTable = "<h5 class='mt-4'>موجودی انبار</h5><div class='table-responsive'><table class='table table-hover table-sm'><thead><tr><th>نام کالا</th><th>کد</th><th>دسته</th><th>سریال</th><th>تاریخ ورود</th><th>فرد قبلی</th></tr></thead><tbody>";
        foreach ($warehouseList as $w) {
            $date = gregorian_to_jalali($w['transferred_date'] ?? '');
            $whTable .= "<tr><td>{$w['item_name']}</td><td>{$w['item_code']}</td><td>{$w['category']}</td><td>{$w['serial_number']}</td><td>$date</td><td>{$w['first_name']} {$w['last_name']}</td></tr>";
        }
        $whTable .= "</tbody></table></div>";

        echo "<div class='tab-pane fade' id='tab-full'>
            <div class='card'>
                <div class='card-header d-flex justify-content-between'><h5>لیست کامل اموال</h5>
                    <div>
                        <button onclick='exportFullXLSX()' class='btn btn-sm btn-success'><img src='../images/icons/export.png' width='16'> XLSX کامل</button>
                        <button onclick='window.print()' class='btn btn-sm btn-secondary'><img src='../images/icons/print.png' width='16'> چاپ</button>
                    </div>
                </div>
                <div class='card-body'>$invTable $whTable</div>
            </div>
        </div>";

        // تب 8: گزارش‌ساز سفارشی
        ?>
        <div class="tab-pane fade" id="tab-custom">
            <div class="card">
                <div class="card-header"><h5>گزارش‌ساز سفارشی</h5></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-9">
                            <label class="form-label">فیلدهای مورد نظر را انتخاب کنید:</label>
                            <div class="row field-check" id="custom-fields">
                                <?php
                                $allFields = [
                                    'personnel_code' => 'کد پرسنلی',
                                    'first_name' => 'نام',
                                    'last_name' => 'نام خانوادگی',
                                    'username' => 'نام کاربری',
                                    'unit' => 'واحد',
                                    'location' => 'محل استقرار',
                                    'case_name' => 'کیس',
                                    'case_code' => 'کد کیس',
                                    'monitor_name' => 'مانیتور',
                                    'monitor_code' => 'کد مانیتور',
                                    'keyboard_name' => 'کیبورد',
                                    'keyboard_code' => 'کد کیبورد',
                                    'mouse_name' => 'ماوس',
                                    'mouse_serial' => 'سریال ماوس',
                                    'phone_name' => 'تلفن',
                                    'phone_code' => 'کد تلفن',
                                    'headset_name' => 'هدست',
                                    'webcam_name' => 'وبکم',
                                    'webcam_serial' => 'سریال وبکم',
                                    'printer_name' => 'پرینتر',
                                    'printer_code' => 'کد پرینتر',
                                    'scanner_name' => 'اسکنر',
                                    'scanner_code' => 'کد اسکنر',
                                    'laptop_name' => 'لپ‌تاپ',
                                    'laptop_code' => 'کد لپ‌تاپ',
                                    'dvd_rw' => 'DVD RW',
                                    'motherboard' => 'مادربورد',
                                    'cpu' => 'پردازنده',
                                    'graphics' => 'گرافیک',
                                    'ram' => 'RAM',
                                    'ssd_nvme' => 'SSD/NVMe',
                                    'hdd' => 'HDD',
                                    'os' => 'سیستم‌عامل',
                                    'other' => 'سایر',
                                    'description' => 'توضیحات'
                                ];
                                foreach ($allFields as $key => $label) {
                                    echo "<div class='col-md-3'><label class='form-check'><input class='form-check-input' type='checkbox' name='fields[]' value='$key'> $label</label></div>";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">جستجو (اختیاری)</label>
                            <input type="text" id="custom-search" class="form-control" placeholder="عبارت...">
                            <button type="button" class="btn btn-primary w-100 mt-4" onclick="generateCustomReport()">نمایش گزارش</button>
                        </div>
                    </div>
                    <hr>
                    <div id="custom-result">
                        <div class="text-muted">لطفاً فیلدهای دلخواه را انتخاب کرده و "نمایش گزارش" را بزنید.</div>
                    </div>
                    <div class="chart-wrapper mt-4" style="display:none;" id="custom-chart-container">
                        <canvas id="chart-custom"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- تب 9: رخدادهای تجهیزات -->
        <?php
        $aeTable = "<div class='table-responsive'><table class='table table-hover table-sm'>
            <thead><tr><th>زمان</th><th>فرد</th><th>کد</th><th>نوع</th><th>قطعه</th><th>مقدار قبلی</th><th>مقدار جدید</th><th>توضیحات</th></tr></thead><tbody>";
        $typeLabels = ['failure'=>'خرابی','repair'=>'تعمیر','replace'=>'تعویض','upgrade'=>'ارتقا','transfer_warehouse'=>'انتقال به انبار','replace_defective'=>'جایگزینی'];
        foreach ($aeData as $ev) {
            $aeTable .= "<tr><td>" . gregorian_to_jalali($ev['created_at']) . "</td>
                <td>{$ev['first_name']} {$ev['last_name']}</td>
                <td>" . ($ev['personnel_code']??'-') . "</td>
                <td>" . ($typeLabels[$ev['event_type']] ?? $ev['event_type']) . "</td>
                <td>{$ev['field_name']}</td>
                <td>{$ev['old_value']}</td>
                <td>{$ev['new_value']}</td>
                <td>{$ev['description']}</td></tr>";
        }
        $aeTable .= "</tbody></table></div>";

        echo "
        <div class='tab-pane fade' id='tab-events'>
            <div class='card'>
                <div class='card-header d-flex justify-content-between'><h5>رخدادهای تجهیزات</h5>
                    <div>
                        <button onclick='exportEventsXLSX()' class='btn btn-sm btn-success'><img src='../images/icons/export.png' width='16'> XLSX</button>
                        <button onclick='window.print()' class='btn btn-sm btn-secondary'><img src='../images/icons/print.png' width='16'> چاپ</button>
                    </div>
                </div>
                <div class='card-body'>$aeTable</div>
            </div>
        </div>";
        ?>
    </div>
</div>

<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/chart.min.js"></script>
<script src="../js/xlsx.full.min.js"></script>

<script>
// داده‌های نمودارها
const chartData = {
    'tab-summary': {
        labels: ['کیس','مانیتور','کیبورد','ماوس','تلفن','هدست','وبکم','پرینتر','اسکنر','لپ‌تاپ'],
        data: <?= json_encode(array_values($items)) ?>
    },
    'tab-status': {
        labels: ['فعال','غیرفعال','حذف'],
        data: [<?= $status['active'] ?>, <?= $status['inactive'] ?>, <?= $status['deleted'] ?>]
    },
    'tab-warehouse': {
        labels: <?= json_encode(array_column($warehouse, 'category')) ?>,
        data: <?= json_encode(array_column($warehouse, 'cnt')) ?>
    },
    'tab-history': {
        labels: <?= json_encode(array_column($history, 'month')) ?>,
        data: <?= json_encode(array_column($history, 'cnt')) ?>
    },
    'tab-unit': {
        labels: <?= json_encode(array_column($unitData, 'unit')) ?>,
        data: <?= json_encode(array_column($unitData, 'cnt')) ?>
    }
};

const invData = <?= json_encode($inventoryList) ?>;
const whData = <?= json_encode($warehouseList) ?>;

let customTableData = [];
let customColumns = [];
let customChartData = null;

// پالت رنگی
const palettes = {
    blue:   { bg: '#4e73df', multi: ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b','#858796','#6f42c1','#fd7e14','#20c9a6','#0dcaf0'] },
    green:  { bg: '#1cc88a', multi: ['#28a745','#20c997','#198754','#146c43','#0f5132','#75b798','#a3cfbb','#d1e7dd','#479f76','#6ea8a6'] },
    orange: { bg: '#fd7e14', multi: ['#fd7e14','#fd9843','#feb272','#fecc9f','#ffe5d0','#e0610b','#c94e08','#b13c05','#992b03','#801b01'] },
    purple: { bg: '#6f42c1', multi: ['#6f42c1','#8a63d2','#b197fc','#d0bfff','#e5dbff','#845ef7','#7950f2','#6741d9','#5f3dc4','#4c2f99'] },
    mixed:  { bg: '#4e73df', multi: ['#4e73df','#1cc88a','#36b9cc','#f6c23e','#e74a3b','#858796','#6f42c1','#fd7e14','#20c9a6','#0dcaf0'] }
};
let currentPalette = 'blue';
const chartInstances = {};

function getPaletteColors() { return palettes[currentPalette]; }

function createChart(tabId, type) {
    if (typeof Chart === 'undefined') return;
    const ctx = document.getElementById('chart-' + tabId);
    if (!ctx) return;
    if (chartInstances[tabId]) chartInstances[tabId].destroy();
    const d = chartData[tabId];
    if (!d) return;
    const colors = getPaletteColors();
    let bgColors = d.data.map((_, i) => colors.multi[i % colors.multi.length]);
    if (type === 'bar' || type === 'line') bgColors = colors.bg;
    const dataset = {
        label: 'تعداد', data: d.data,
        backgroundColor: bgColors,
        borderColor: type === 'line' ? colors.bg : '#fff',
        borderWidth: 2, borderRadius: type === 'line' ? 0 : 8,
        pointBackgroundColor: type === 'line' ? colors.bg : undefined,
        pointBorderColor: type === 'line' ? '#fff' : undefined,
        pointRadius: type === 'line' ? 4 : undefined,
        fill: type === 'line' ? false : true, tension: type === 'line' ? 0.3 : undefined
    };
    chartInstances[tabId] = new Chart(ctx, {
        type: type === 'line' ? 'line' : (type === 'pie' || type === 'doughnut' ? 'doughnut' : 'bar'),
        data: { labels: d.labels, datasets: [dataset] },
        options: {
            responsive: true, maintainAspectRatio: true,
            plugins: { legend: { position: 'bottom', labels: { font: { family: 'YekanBakh', size: 12 } } } },
            scales: type !== 'pie' && type !== 'doughnut' ? { y: { beginAtZero: true } } : {}
        }
    });
}

function changeChart(tabId, type) { createChart(tabId, type); }
function downloadChart(tabId) {
    const canvas = document.getElementById('chart-' + tabId);
    if (canvas) canvas.toBlob(blob => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = tabId+'.png'; a.click(); });
}
function applyPalette(palette) {
    currentPalette = palette;
    for (const [id, inst] of Object.entries(chartInstances)) if (inst) createChart(id, inst.config.type);
}

document.querySelectorAll('#reportTabs a').forEach(tab => {
    tab.addEventListener('shown.bs.tab', function (e) {
        const targetId = e.target.getAttribute('href').replace('#', '');
        if (chartData[targetId] && !chartInstances[targetId]) {
            createChart(targetId, 'bar');
        }
    });
});

// گزارش سفارشی AJAX
async function generateCustomReport() {
    const checkboxes = document.querySelectorAll('#custom-fields input[name="fields[]"]:checked');
    const fields = Array.from(checkboxes).map(cb => cb.value);
    const search = document.getElementById('custom-search').value.trim();

    if (fields.length === 0) {
        document.getElementById('custom-result').innerHTML = '<div class="alert alert-info">حداقل یک فیلد انتخاب کنید.</div>';
        return;
    }

    const formData = new FormData();
    fields.forEach(f => formData.append('fields[]', f));
    formData.append('custom_search', search);

    try {
        const response = await fetch('generate_report.php?ajax=1&chart=1', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        document.getElementById('custom-result').innerHTML = result.html;
        customTableData = result.tableData;
        customColumns = result.columns;

        const chartContainer = document.getElementById('custom-chart-container');
        if (result.chartData) {
            customChartData = result.chartData;
            chartContainer.style.display = 'block';
            if (chartInstances['custom']) chartInstances['custom'].destroy();
            const ctx = document.getElementById('chart-custom').getContext('2d');
            chartInstances['custom'] = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: result.chartData.labels,
                            datasets: [{
                                label: 'تعداد',
                                data: result.chartData.data,
                                backgroundColor: [
                                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
                                    '#858796', '#6f42c1', '#fd7e14', '#20c9a6', '#0dcaf0'
                                ],
                                borderColor: '#fff',
                                borderWidth: 2
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: true,
                            plugins: {
                                legend: { position: 'bottom', labels: { font: { family: 'YekanBakh', size: 12 } } }
                            }
                        }
                    });
        } else {
            chartContainer.style.display = 'none';
            customChartData = null;
        }
    } catch (err) {
        console.error(err);
        document.getElementById('custom-result').innerHTML = '<div class="alert alert-danger">خطا در دریافت گزارش.</div>';
    }
}

// توابع خروجی Excel
function exportXLSX(tabId) {
    if (typeof XLSX === 'undefined') { alert('کتابخانه Excel بارگذاری نشده.'); return; }
    const wb = XLSX.utils.book_new();
    let rows = [];
    switch(tabId) {
        case 'tab-summary':
            rows.push(['نوع', 'تعداد']);
            const names = ['کیس','مانیتور','کیبورد','ماوس','تلفن','هدست','وبکم','پرینتر','اسکنر','لپ‌تاپ'];
            const vals = chartData['tab-summary'].data;
            names.forEach((n, i) => rows.push([n, vals[i]]));
            break;
        case 'tab-status':
            rows.push(['وضعیت', 'تعداد']);
            rows.push(['فعال', chartData['tab-status'].data[0]]);
            rows.push(['غیرفعال', chartData['tab-status'].data[1]]);
            rows.push(['حذف شده', chartData['tab-status'].data[2]]);
            break;
        case 'tab-warehouse':
            rows.push(['دسته', 'تعداد']);
            chartData['tab-warehouse'].labels.forEach((l, i) => rows.push([l, chartData['tab-warehouse'].data[i]]));
            break;
        case 'tab-history':
            rows.push(['ماه', 'تعداد']);
            chartData['tab-history'].labels.forEach((l, i) => rows.push([l, chartData['tab-history'].data[i]]));
            break;
        case 'tab-unit':
            rows.push(['واحد', 'تعداد']);
            chartData['tab-unit'].labels.forEach((l, i) => rows.push([l, chartData['tab-unit'].data[i]]));
            break;
        default: return;
    }
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'گزارش');
    XLSX.writeFile(wb, 'گزارش.xlsx');
}

function exportFullXLSX() {
    if (typeof XLSX === 'undefined') { alert('کتابخانه Excel بارگذاری نشده.'); return; }
    const wb = XLSX.utils.book_new();
    const invRows = [['کد پرسنلی','نام','نام خانوادگی','واحد','کیس','کد کیس','مانیتور','کد مانیتور','کیبورد','کد کیبورد','ماوس','سریال ماوس','تلفن','کد تلفن','هدست','وبکم','سریال وبکم','پرینتر','کد پرینتر','اسکنر','کد اسکنر','لپ تاپ','کد لپ تاپ','DVD RW','مادربورد','پردازنده','گرافیک','RAM','SSD/NVMe','HDD','OS','سایر','توضیحات']];
    invData.forEach(r => invRows.push([r.personnel_code, r.first_name, r.last_name, r.unit, r.case_name, r.case_code, r.monitor_name, r.monitor_code, r.keyboard_name, r.keyboard_code, r.mouse_name, r.mouse_serial, r.phone_name, r.phone_code, r.headset_name, r.webcam_name, r.webcam_serial, r.printer_name, r.printer_code, r.scanner_name, r.scanner_code, r.laptop_name, r.laptop_code, r.dvd_rw, r.motherboard, r.cpu, r.graphics, r.ram, r.ssd_nvme, r.hdd, r.os, r.other, r.description]));
    const wsInv = XLSX.utils.aoa_to_sheet(invRows);
    XLSX.utils.book_append_sheet(wb, wsInv, 'اموال پرسنل');
    const whRows = [['نام کالا','کد','دسته','سریال','تاریخ ورود','فرد قبلی','کد پرسنلی']];
    whData.forEach(r => whRows.push([r.item_name, r.item_code, r.category, r.serial_number, r.transferred_date, (r.first_name||'')+' '+(r.last_name||''), r.personnel_code]));
    const wsWh = XLSX.utils.aoa_to_sheet(whRows);
    XLSX.utils.book_append_sheet(wb, wsWh, 'موجودی انبار');
    XLSX.writeFile(wb, 'لیست_کامل_اموال.xlsx');
}

function exportCustomXLSX() {
    if (typeof XLSX === 'undefined') { alert('کتابخانه Excel بارگذاری نشده.'); return; }
    if (!customTableData.length) { alert('داده‌ای برای خروجی وجود ندارد.'); return; }
    const wb = XLSX.utils.book_new();
    const headerMap = {
        'personnel_code':'کد پرسنلی','first_name':'نام','last_name':'نام خانوادگی','username':'نام کاربری',
        'unit':'واحد','location':'محل استقرار','case_name':'کیس','case_code':'کد کیس',
        'monitor_name':'مانیتور','monitor_code':'کد مانیتور','keyboard_name':'کیبورد','keyboard_code':'کد کیبورد',
        'mouse_name':'ماوس','mouse_serial':'سریال ماوس','phone_name':'تلفن','phone_code':'کد تلفن',
        'headset_name':'هدست','webcam_name':'وبکم','webcam_serial':'سریال وبکم',
        'printer_name':'پرینتر','printer_code':'کد پرینتر','scanner_name':'اسکنر','scanner_code':'کد اسکنر',
        'laptop_name':'لپ‌تاپ','laptop_code':'کد لپ‌تاپ','dvd_rw':'DVD RW','motherboard':'مادربورد',
        'cpu':'پردازنده','graphics':'گرافیک','ram':'RAM','ssd_nvme':'SSD/NVMe','hdd':'HDD','os':'سیستم‌عامل',
        'other':'سایر','description':'توضیحات'
    };
    const rows = [customColumns.map(col => headerMap[col] || col)];
    customTableData.forEach(row => rows.push(customColumns.map(col => row[col] ?? '')));
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'داده‌ها');
    if (customChartData) {
        const chartRows = [['برچسب', 'تعداد']];
        customChartData.labels.forEach((l, i) => chartRows.push([l, customChartData.data[i]]));
        const wsChart = XLSX.utils.aoa_to_sheet(chartRows);
        XLSX.utils.book_append_sheet(wb, wsChart, 'نمودار');
    }
    XLSX.writeFile(wb, 'گزارش_سفارشی.xlsx');
}

function exportEventsXLSX() {
    if (typeof XLSX === 'undefined') { alert('کتابخانه Excel بارگذاری نشده.'); return; }
    const wb = XLSX.utils.book_new();
    const rows = [['زمان','فرد','کد پرسنلی','نوع','قطعه','مقدار قبلی','مقدار جدید','توضیحات','ثبت‌کننده']];
    <?php foreach ($aeData as $ev): ?>
        rows.push([
            '<?= gregorian_to_jalali($ev['created_at']) ?>',
            '<?= htmlspecialchars($ev['first_name'].' '.$ev['last_name']) ?>',
            '<?= htmlspecialchars($ev['personnel_code'] ?? '') ?>',
            '<?= $typeLabels[$ev['event_type']] ?? $ev['event_type'] ?>',
            '<?= htmlspecialchars($ev['field_name']) ?>',
            '<?= htmlspecialchars($ev['old_value']) ?>',
            '<?= htmlspecialchars($ev['new_value']) ?>',
            '<?= htmlspecialchars($ev['description']) ?>',
            '<?= htmlspecialchars($ev['created_by']) ?>'
        ]);
    <?php endforeach; ?>
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, 'رخدادها');
    XLSX.writeFile(wb, 'رخدادهای_تجهیزات.xlsx');
}
</script>
</body>
</html>