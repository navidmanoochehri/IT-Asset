<?php
require_once 'includes/auth.php';
require_once 'includes/master_config.php'; // برای دریافت لیست شعب

$branchName = $_SESSION['branch_name'] ?? 'شعبه نامشخص';
$adminName  = $_SESSION['admin_name'] ?? 'کاربر';
$adminRole  = $_SESSION['admin_role'] ?? 'branch_admin';
$currentBranchId = $_SESSION['admin_branch_id'] ?? 0;

// دریافت شعب فعال
$branches = $master_pdo->query("SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>داشبورد مدیریت اموال</title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body {
            background: #eef2f7;
            font-family: 'YekanBakh', sans-serif;
            position: relative;
            overflow-x: hidden;
        }

        /* حلقه‌های پس‌زمینه */
        .bg-animation {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            z-index: 0; overflow: hidden;
        }
        .bg-animation .circle {
            position: absolute; border-radius: 50%;
            animation: floatCircle 18s infinite ease-in-out;
            background: radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8), rgba(78,84,200,0.3));
        }
        .bg-animation .circle:nth-child(1) {
            width: 700px; height: 700px; top: -200px; right: -150px;
            animation-delay: 0s; animation-duration: 20s;
        }
        .bg-animation .circle:nth-child(2) {
            width: 500px; height: 500px; bottom: -150px; left: -100px;
            animation-delay: -4s; animation-duration: 17s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.85), rgba(143,148,251,0.3));
        }
        .bg-animation .circle:nth-child(3) {
            width: 400px; height: 400px; top: 40%; right: 10%;
            animation-delay: -8s; animation-duration: 22s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.8), rgba(102,126,234,0.3));
        }
        .bg-animation .circle:nth-child(4) {
            width: 300px; height: 300px; bottom: 10%; right: 20%;
            animation-delay: -12s; animation-duration: 14s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.7), rgba(250,112,154,0.25));
        }
        .bg-animation .circle:nth-child(5) {
            width: 250px; height: 250px; top: 10%; left: 15%;
            animation-delay: -16s; animation-duration: 19s;
            background: radial-gradient(circle at 40%, rgba(255,255,255,0.6), rgba(246,211,101,0.25));
        }
        @keyframes floatCircle {
            0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
            25%      { transform: translate(60px, -40px) scale(1.08) rotate(2deg); }
            50%      { transform: translate(-30px, 50px) scale(0.95) rotate(-2deg); }
            75%      { transform: translate(-50px, -20px) scale(1.03) rotate(1deg); }
        }

        /* نوار داشبورد */
        .navbar-dash {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .brand-side { display: flex; align-items: center; gap: 10px; }
        .brand-side img { width: 38px; height: 38px; border-radius: 10px; background: rgba(255,255,255,0.9); padding: 5px; }
        .user-side { display: flex; align-items: center; gap: 12px; }

        /* دکمه‌های تنظیمات و خروج */
        .btn-icon {
            width: 36px; height: 36px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            padding: 0; border: none; transition: all 0.3s ease;
        }
        .btn-settings {
            background: linear-gradient(135deg, #4e73df, #2a5298);
            box-shadow: 0 4px 10px rgba(78,115,223,0.3);
        }
        .btn-settings:hover {
            background: linear-gradient(135deg, #2a5298, #4e73df);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(78,115,223,0.45);
        }
        .btn-logout {
            background: linear-gradient(135deg, #dc3545, #b02a37);
            box-shadow: 0 4px 10px rgba(220,53,69,0.3);
        }
        .btn-logout:hover {
            background: linear-gradient(135deg, #b02a37, #dc3545);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(220,53,69,0.45);
        }
        .btn-icon img { filter: brightness(0) invert(1); width: 20px; height: 20px; }

        /* منوی کشویی شعبه */
        .dropdown-toggle {
            background: rgba(0,0,0,0.05);
            border: none;
            color: #334155;
            font-family: 'YekanBakh', sans-serif;
            padding: 8px 16px;
            border-radius: 30px;
        }
        .dropdown-menu { border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.05); }
        .dropdown-item.active { background: #4e73df; color: white; }

        /* کارت‌های داشبورد */
        .dash-card {
            background: #fff;
            border: 1px solid rgba(0,0,0,0.05);
            border-radius: 24px;
            padding: 25px 15px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.3s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 0.3s ease;
            animation: fadeInUp 0.8s cubic-bezier(0.23, 1, 0.32, 1) both;
            position: relative;
            z-index: 1;
        }
        .dash-card:nth-child(1) { animation-delay: 0.1s; }
        .dash-card:nth-child(2) { animation-delay: 0.2s; }
        .dash-card:nth-child(3) { animation-delay: 0.3s; }
        .dash-card:nth-child(4) { animation-delay: 0.4s; }
        .dash-card:nth-child(5) { animation-delay: 0.5s; }
        .dash-card:nth-child(6) { animation-delay: 0.6s; }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .dash-card:hover {
            transform: translateY(-12px) scale(1.02);
            box-shadow: 0 20px 35px rgba(0,0,0,0.12);
        }
        .icon-circle {
            width: 70px; height: 70px; border-radius: 20px;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 15px;
        }
        .icon-circle img { width: 38px; height: 38px; filter: brightness(0) invert(1); }
        h5 { color: #1e293b; }
        .text-muted { color: #64748b !important; }
    </style>
</head>
<body>
<div class="bg-animation">
    <div class="circle"></div><div class="circle"></div><div class="circle"></div>
    <div class="circle"></div><div class="circle"></div>
</div>

<nav class="navbar-dash">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="brand-side">
            <img src="images/logo.png" alt="لوگو">
            <span class="fw-bold" style="color:#1e293b;">مدیریت اموال IT</span>
        </div>
        <div class="user-side">
            <!-- منوی کشویی شعبه -->
            <div class="dropdown">
                <button class="btn btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?= htmlspecialchars($branchName) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-start">
                    <?php foreach ($branches as $b): ?>
                        <?php if ($adminRole === 'super_admin' || $b['id'] == $currentBranchId): ?>
                            <li>
                                <a class="dropdown-item <?= $b['id'] == $currentBranchId ? 'active' : '' ?>" 
                                   href="#" 
                                   onclick="switchBranch(<?= $b['id'] ?>)">
                                    <?= htmlspecialchars($b['name']) ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>

            <span style="color:#334155;"><?= htmlspecialchars($adminName) ?> (<?= $adminRole === 'super_admin' ? 'مدیرکل' : 'مدیر شعبه' ?>)</span>

            <?php if ($adminRole === 'super_admin'): ?>
                <a href="settings.php" class="btn-icon btn-settings" title="تنظیمات">
                    <img src="images/icons/setting.png" alt="تنظیمات">
                </a>
            <?php endif; ?>
            <a href="logout.php" class="btn-icon btn-logout" title="خروج">
                <img src="images/icons/logout.png" alt="خروج">
            </a>
        </div>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <div class="row g-4 justify-content-center">
        <?php
        $cards = [
            ['ثبت اولیه', 'افزودن فرد + تجهیزات', 'persons/add_complete.php', 'register.png', 'linear-gradient(135deg,#4facfe,#00f2fe)'],
            ['ویرایش پیشرفته', 'جستجو و ویرایش کامل', 'search_edit.php', 'edit-advanced.png', 'linear-gradient(135deg,#43e97b,#38f9d7)'],
            ['سابقه اموال', 'تاریخچه تغییرات', 'history/view_history.php', 'history.png', 'linear-gradient(135deg,#fa709a,#fee140)'],
            ['گزارش‌سازی', 'گزارش‌های متنوع', 'reports/generate_report.php', 'reports.png', 'linear-gradient(135deg,#a18cd1,#fbc2eb)'],
            ['جستجوی پیشرفته', 'فیلتر و خروجی', 'search/advanced_search.php', 'search.png', 'linear-gradient(135deg,#f093fb,#f5576c)'],
            ['انبار', 'تجهیزات بدون متصدی', 'warehouse/warehouse.php', 'warehouse.png', 'linear-gradient(135deg,#f6d365,#fda085)'],
        ];
        foreach ($cards as $c):
        ?>
        <div class="col-6 col-md-4 col-lg-2">
            <div class="dash-card" onclick="location.href='<?= $c[2] ?>'">
                <div class="icon-circle" style="background:<?= $c[4] ?>">
                    <img src="images/icons/<?= $c[3] ?>" alt="<?= $c[0] ?>">
                </div>
                <h5><?= $c[0] ?></h5>
                <p class="text-muted"><?= $c[1] ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
<script>
async function switchBranch(branchId) {
    const resp = await fetch('switch_branch.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'branch_id=' + branchId
    });
    const result = await resp.json();
    if (result.success) {
        location.reload();
    } else {
        alert('خطا در تغییر شعبه: ' + result.message);
    }
}
</script>
</body>
</html>