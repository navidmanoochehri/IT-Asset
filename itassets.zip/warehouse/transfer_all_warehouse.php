<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$fromPersonId = $input['from_person_id'] ?? 0;
$toPersonId   = $input['to_person_id'] ?? null;

if ($fromPersonId === '') {
    echo json_encode(['success' => false, 'message' => 'شناسه مبدأ نامعتبر']);
    exit;
}

if ($fromPersonId == 0) {
    $where = "WHERE transferred_from_person_id IS NULL";
    $fromName = 'انبار آزاد';
} else {
    $where = "WHERE transferred_from_person_id = $fromPersonId";
    $fromName = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $fromPersonId")->fetchColumn();
    if (!$fromName) {
        echo json_encode(['success' => false, 'message' => 'فرد مبدأ یافت نشد']);
        exit;
    }
}

$pdo->beginTransaction();
try {
    $items = $pdo->query("SELECT * FROM warehouse_items $where")->fetchAll();

    $firstCode = '';
    if (!empty($items)) {
        $firstCode = $items[0]['item_code'] ?? '';

        if ($toPersonId) {
            // انتقال به یک فرد
            $invId = $pdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
            $invId->execute([$toPersonId]);
            $invExists = $invId->fetch();

            $invData = [];
            foreach ($items as $item) {
                $cat = $item['category'];
                $map = [
                    'کیس' => ['name'=>'case_name','code'=>'case_code'],
                    'مانیتور' => ['name'=>'monitor_name','code'=>'monitor_code'],
                    'کیبورد' => ['name'=>'keyboard_name','code'=>'keyboard_code'],
                    'تلفن' => ['name'=>'phone_name','code'=>'phone_code'],
                    'پرینتر' => ['name'=>'printer_name','code'=>'printer_code'],
                    'اسکنر' => ['name'=>'scanner_name','code'=>'scanner_code'],
                    'لپتاپ' => ['name'=>'laptop_name','code'=>'laptop_code'],
                    'ماوس' => ['name'=>'mouse_name','serial'=>'mouse_serial'],
                    'وبکم' => ['name'=>'webcam_name','serial'=>'webcam_serial'],
                ];
                if (isset($map[$cat])) {
                    $m = $map[$cat];
                    $invData[$m['name']] = trim(($invData[$m['name']]??'')."\n".$item['item_name']);
                    if ($m['code']) $invData[$m['code']] = trim(($invData[$m['code']]??'')."\n".$item['item_code']);
                    if (isset($m['serial']) && $m['serial']) $invData[$m['serial']] = trim(($invData[$m['serial']]??'')."\n".$item['serial_number']);
                }
            }

            if ($invExists) {
                $sets = []; $params = [];
                foreach ($invData as $col => $val) {
                    $sets[] = "$col = CONCAT(COALESCE($col,''), ?, '\n')";
                    $params[] = $val;
                }
                if (!empty($sets)) {
                    $params[] = $toPersonId;
                    $pdo->prepare("UPDATE inventory SET ".implode(',',$sets)." WHERE person_id = ?")->execute($params);
                }
            } else {
                $cols = array_keys($invData); $vals = array_values($invData);
                $q = rtrim(str_repeat('?,', count($cols)), ',');
                $sql = "INSERT INTO inventory (person_id, ".implode(',',$cols).") VALUES (?, $q)";
                $pdo->prepare($sql)->execute(array_merge([$toPersonId], $vals));
            }

            // حذف اقلام از انبار
            $pdo->exec("DELETE FROM warehouse_items $where");

            $toName = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $toPersonId")->fetchColumn();
            logChange($pdo, $toPersonId, 'update', "دریافت کلیه اقلام انبار از {$fromName}", $firstCode);
            if ($fromPersonId != 0) {
                logChange($pdo, $fromPersonId, 'update', "انتقال کلیه اقلام انبار به {$toName}", $firstCode);
            }
        } else {
            // بدون فرد: تبدیل به انبار آزاد
            $pdo->prepare("UPDATE warehouse_items SET transferred_from_person_id = NULL, description = CONCAT(COALESCE(description,''), '\n[خروج از فرد]') WHERE transferred_from_person_id = ?")->execute([$fromPersonId]);
            if ($fromPersonId != 0) {
                logChange($pdo, $fromPersonId, 'update', "خروج کلیه اقلام انبار - بدون انتساب", $firstCode);
            }
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}