<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/master_config.php';   // برای دریافت لیست شعب

// ---------- دریافت داده‌ها ----------
$search = $_GET['search'] ?? '';
$where  = [];
$params = [];
if (!empty($search)) {
    $where[] = "(w.item_name LIKE ? OR w.item_code LIKE ? OR w.description LIKE ? OR CONCAT(p.first_name,' ',p.last_name) LIKE ? OR p.personnel_code LIKE ?)";
    $params  = array_fill(0, 5, "%$search%");
}

// افراد دارای اقلام در انبار
$sql = "SELECT p.id AS person_id, p.first_name, p.last_name, p.personnel_code,
               p.is_active, p.is_deleted, COUNT(w.id) AS item_count
        FROM warehouse_items w
        JOIN persons p ON w.transferred_from_person_id = p.id
        " . (!empty($where) ? "WHERE " . implode(" AND ", $where) : "") . "
        GROUP BY p.id
        ORDER BY p.last_name, p.first_name";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$persons = $stmt->fetchAll();

// اقلام بدون انتساب (انبار آزاد)
$noOwnerWhere = '';
$noOwnerParams = [];
if (!empty($search)) {
    $noOwnerWhere  = " AND (item_name LIKE ? OR item_code LIKE ? OR description LIKE ?)";
    $noOwnerParams = array_fill(0, 3, "%$search%");
}
$noOwnerStmt = $pdo->prepare("SELECT * FROM warehouse_items WHERE transferred_from_person_id IS NULL" . $noOwnerWhere . " ORDER BY created_at DESC");
$noOwnerStmt->execute($noOwnerParams);
$noOwnerItems = $noOwnerStmt->fetchAll();

// همهٔ اقلام (برای نمایش در collapse)
$allItems = $pdo->query("SELECT w.*, p.first_name, p.last_name, p.personnel_code
                         FROM warehouse_items w
                         LEFT JOIN persons p ON w.transferred_from_person_id = p.id
                         ORDER BY w.created_at DESC")->fetchAll();

// آمار دسته‌ها
$stats = $pdo->query("SELECT category, COUNT(*) AS cnt FROM warehouse_items GROUP BY category")->fetchAll();

// آیکون‌های مربوط به هر دسته
$iconMap = [
    'کیس' => 'case.png', 'مانیتور' => 'monitor.png', 'کیبورد' => 'keyboard.png',
    'ماوس' => 'mouse.png', 'تلفن' => 'phone.png', 'هدست' => 'headset.png',
    'وبکم' => 'webcam.png', 'پرینتر' => 'printer.png', 'اسکنر' => 'scanner.png',
    'لپتاپ' => 'laptop.png', 'مادربورد' => 'motherboard.png', 'پردازنده' => 'cpu.png',
    'گرافیک' => 'graphics.png', 'رم' => 'ram.png', 'SSD/NVMe' => 'ssd.png',
    'HDD' => 'hdd.png', 'سیستم‌عامل' => 'os.png', 'سایر' => 'other.png'
];

// افراد فعال همین شعبه (برای مودال‌های داخلی)
$activePersons = $pdo->query("SELECT id, first_name, last_name, personnel_code FROM persons WHERE is_active = 1 AND is_deleted = 0 ORDER BY last_name")->fetchAll();

// شعب فعال (برای انتخاب شعبه مقصد)
$branches = $master_pdo->query("SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>انبار اموال IT</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%, 100% { transform: translate(0,0) scale(1); } 33% { transform: translate(40px,-40px) scale(1.05); } 66% { transform: translate(-30px,30px) scale(0.95); } }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .stat-widget { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); transition: 0.3s; }
        .stat-widget:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.06); }
        .person-row { cursor: pointer; }
        .collapse-row td { padding: 0; border-top: none; }
        .inner-table { margin: 0; width: 100%; font-size: 0.9rem; }
        .inner-table th, .inner-table td { padding: 8px 10px; }
        .inner-table th { background: #f8f9fa; }
        .btn-action img { width: 18px; height: 18px; vertical-align: middle; }
        .table > :not(caption) > * > * { padding: 10px 14px; }
        .icon-circle { border-radius: 16px; display: flex; align-items: center; justify-content: center; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="../dashboard.php" class="btn btn-primary btn-sm" title="بازگشت به داشبورد">
            <img src="../images/icons/home.png" width="18" style="margin-left:4px;"> داشبورد
        </a>
        <!-- دکمهٔ افزودن دستی -->
        <button class="btn btn-success btn-sm" onclick="openAddModal()" title="افزودن کالای جدید">
            <img src="../images/icons/add.png" width="18" style="margin-left:4px;"> افزودن دستی
        </button>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <!-- فرم جستجو -->
    <div class="card p-3 mb-3">
        <form method="get" class="row g-2">
            <div class="col-md-8">
                <input type="text" name="search" class="form-control" placeholder="جستجوی نام، کد، توضیحات..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100" title="اعمال فیلتر">فیلتر</button>
            </div>
            <div class="col-md-2">
                <a href="?export=1" class="btn btn-success w-100" title="خروجی CSV">CSV</a>
            </div>
        </form>
    </div>

    <!-- جدول اصلی -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">موجودی انبار</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>نام / عنوان</th>
                            <th>کد پرسنلی</th>
                            <th style="width: 80px;">اقلام</th>
                            <th>وضعیت</th>
                            <th style="width: 160px;">عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- افراد دارای اقلام -->
                        <?php foreach ($persons as $person): $collapseId = "items-{$person['person_id']}"; ?>
                            <tr class="person-row" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>" aria-expanded="false">
                                <td>
                                    <?= htmlspecialchars($person['first_name'].' '.$person['last_name']) ?>
                                    <span style="font-size:1.1rem; margin-right:6px; opacity:0.6;">▼</span>
                                </td>
                                <td><?= htmlspecialchars($person['personnel_code'] ?? '-') ?></td>
                                <td><span class="badge bg-secondary"><?= $person['item_count'] ?></span></td>
                                <td>
                                    <?php if (!empty($person['is_deleted'])): ?><span class="badge bg-danger">حذف شده</span>
                                    <?php elseif (!$person['is_active']): ?><span class="badge bg-warning text-dark">غیرفعال</span>
                                    <?php else: ?><span class="badge bg-success">فعال</span><?php endif; ?>
                                </td>
                                <td style="white-space: nowrap;">
                                    <?php if (!$person['is_active'] && empty($person['is_deleted'])): ?>
                                        <a href="../persons/activate_person.php?id=<?= $person['person_id'] ?>" class="btn btn-sm btn-success me-1" onclick="event.stopPropagation()" title="فعال‌سازی مجدد"><img src="../images/icons/toggle-on.png" width="18"></a>
                                    <?php endif; ?>
                                    <button class="btn btn-sm btn-info" onclick="event.stopPropagation(); openTransferAllModal(<?= $person['person_id'] ?>,'<?= htmlspecialchars($person['first_name'].' '.$person['last_name']) ?>')" title="انتقال همه اقلام"><img src="../images/icons/transfer.png" width="18"></button>
                                </td>
                            </tr>
                            <tr class="collapse-row">
                                <td colspan="5" class="p-0">
                                    <div class="collapse" id="<?= $collapseId ?>">
                                        <div class="p-3 bg-light">
                                            <table class="table table-sm table-bordered inner-table">
                                                <thead class="table-secondary">
                                                    <tr><th>نام کالا</th><th>کد</th><th>دسته</th><th>سریال</th><th>تاریخ ورود</th><th style="width:120px;">عملیات</th></tr>
                                                </thead>
                                                <tbody>
                                                    <?php $personItems = array_filter($allItems, fn($i) => $i['transferred_from_person_id'] == $person['person_id']); ?>
                                                    <?php foreach ($personItems as $item): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars($item['item_name']) ?></td>
                                                            <td><?= htmlspecialchars($item['item_code'] ?? '-') ?></td>
                                                            <td><?= htmlspecialchars($item['category'] ?? '') ?></td>
                                                            <td><?= htmlspecialchars($item['serial_number'] ?? '-') ?></td>
                                                            <td><?= gregorian_to_jalali($item['transferred_date'] ?? $item['created_at']) ?></td>
                                                            <td style="white-space:nowrap;">
                                                                <button class="btn btn-sm btn-warning me-1" onclick="event.stopPropagation(); openEditModal(<?=$item['id']?>,'<?=htmlspecialchars($item['item_name'])?>','<?=htmlspecialchars($item['item_code']??'')?>','<?=htmlspecialchars($item['category']??'')?>','<?=htmlspecialchars($item['serial_number']??'')?>','<?=htmlspecialchars($item['description']??'')?>')" title="ویرایش"><img src="../images/icons/edit.png" width="18"></button>
                                                                <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); openReassignModal(<?=$item['id']?>,'<?=htmlspecialchars($item['item_name'])?>','<?=htmlspecialchars($person['first_name'].' '.$person['last_name'])?>')" title="انتقال"><img src="../images/icons/transfer.png" width="18"></button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                    <?php if (empty($personItems)): ?>
                                                        <tr><td colspan="6" class="text-center text-muted">هیچ کالایی موجود نیست.</td></tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <!-- اقلام بدون انتساب (انبار آزاد) -->
                        <?php if (!empty($noOwnerItems)): ?>
                            <tr class="person-row" data-bs-toggle="collapse" data-bs-target="#noOwnerCollapse" aria-expanded="false">
                                <td><strong>انبار آزاد (بدون مالک)</strong><span style="font-size:1.1rem; margin-right:6px; opacity:0.6;">▼</span></td>
                                <td>—</td>
                                <td><span class="badge bg-info"><?= count($noOwnerItems) ?></span></td>
                                <td><span class="badge bg-secondary">عمومی</span></td>
                                <td style="white-space:nowrap;">
                                    <button class="btn btn-sm btn-info" onclick="event.stopPropagation(); openTransferAllModal(0,'انبار آزاد')" title="انتقال همه اقلام آزاد"><img src="../images/icons/transfer.png" width="18"></button>
                                </td>
                            </tr>
                            <tr class="collapse-row"><td colspan="5" class="p-0"><div class="collapse" id="noOwnerCollapse"><div class="p-3 bg-light">
                                <table class="table table-sm table-bordered inner-table">
                                    <thead class="table-secondary"><tr><th>نام کالا</th><th>کد</th><th>دسته</th><th>سریال</th><th>تاریخ ورود</th><th style="width:120px;">عملیات</th></tr></thead>
                                    <tbody>
                                        <?php foreach ($noOwnerItems as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['item_name']) ?></td>
                                                <td><?= htmlspecialchars($item['item_code'] ?? '-') ?></td>
                                                <td><?= htmlspecialchars($item['category'] ?? '') ?></td>
                                                <td><?= htmlspecialchars($item['serial_number'] ?? '-') ?></td>
                                                <td><?= gregorian_to_jalali($item['transferred_date'] ?? $item['created_at']) ?></td>
                                                <td style="white-space:nowrap;">
                                                    <button class="btn btn-sm btn-warning me-1" onclick="event.stopPropagation(); openEditModal(<?=$item['id']?>,'<?=htmlspecialchars($item['item_name'])?>','<?=htmlspecialchars($item['item_code']??'')?>','<?=htmlspecialchars($item['category']??'')?>','<?=htmlspecialchars($item['serial_number']??'')?>','<?=htmlspecialchars($item['description']??'')?>')" title="ویرایش"><img src="../images/icons/edit.png" width="18"></button>
                                                    <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); openReassignModal(<?=$item['id']?>,'<?=htmlspecialchars($item['item_name'])?>','انبار آزاد')" title="انتقال"><img src="../images/icons/transfer.png" width="18"></button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div></div></td></tr>
                        <?php endif; ?>

                        <?php if (empty($persons) && empty($noOwnerItems)): ?>
                            <tr><td colspan="5" class="text-center text-muted py-5">هیچ کالایی در انبار یافت نشد.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- خلاصه آیکون‌دار -->
    <div class="card mt-4">
        <div class="card-header"><h5 class="mb-0">خلاصه موجودی بر اساس دسته</h5></div>
        <div class="card-body">
            <div class="row g-4">
                <?php foreach ($stats as $st): $cat = $st['category']; $cnt = $st['cnt']; $img = $iconMap[$cat] ?? 'other.png'; ?>
                    <div class="col-6 col-md-4 col-lg-2">
                        <div class="stat-widget text-center p-3">
                            <div class="icon-circle mx-auto mb-2" style="width:60px;height:60px;background:linear-gradient(135deg,#667eea,#764ba2);">
                                <img src="../images/icons/<?= $img ?>" style="width:28px;filter:brightness(0) invert(1);">
                            </div>
                            <strong><?= htmlspecialchars($cat) ?></strong>
                            <div class="fs-5"><?= $cnt ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- ================= مودال‌ها ================= -->
<!-- مودال ویرایش تکی -->
<div class="modal fade" id="editItemModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>ویرایش اقلام انبار</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" id="edit-item-id">
                <div class="mb-3"><label class="form-label">نام کالا</label><input id="edit-item-name" class="form-control"></div>
                <div class="mb-3"><label class="form-label">کد اموال</label><input id="edit-item-code" class="form-control"></div>
                <div class="mb-3"><label class="form-label">دسته</label><input id="edit-item-category" class="form-control"></div>
                <div class="mb-3"><label class="form-label">سریال</label><input id="edit-item-serial" class="form-control"></div>
                <div class="mb-3"><label class="form-label">توضیحات</label><textarea id="edit-item-desc" class="form-control" rows="2"></textarea></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button type="button" class="btn btn-primary" onclick="saveEditItem()" title="ذخیره تغییرات">ذخیره</button>
            </div>
        </div>
    </div>
</div>

<!-- مودال انتقال تکی (با قابلیت بین شعبی) -->
<div class="modal fade" id="reassignModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>انتقال کالا به فرد دیگر</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" id="reassign-item-id">
                <p>کالا: <strong id="reassign-item-name"></strong></p>
                <p>فرد فعلی: <strong id="reassign-current-person"></strong></p>
                <div class="mb-3">
                    <label class="form-label">شعبهٔ مقصد</label>
                    <select id="reassign-branch-select" class="form-select" onchange="loadReassignBranchPersons()">
                        <option value="">-- همین شعبه --</option>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3 form-check">
                    <input class="form-check-input" type="checkbox" id="reassign-no-person-check" onchange="toggleReassignPersonSelect()">
                    <label class="form-check-label" for="reassign-no-person-check">انتقال بدون انتساب به فرد</label>
                </div>
                <div class="mb-3" id="reassign-person-select-group">
                    <label class="form-label">فرد مقصد</label>
                    <select id="reassign-new-person" class="form-select">
                        <option value="">-- ابتدا شعبه را انتخاب کنید --</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button type="button" class="btn btn-primary" onclick="saveReassign()">انتقال</button>
            </div>
        </div>
    </div>
</div>

<!-- مودال انتقال کلی (با قابلیت بین شعبی و بدون فرد) -->
<div class="modal fade" id="transferAllModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>انتقال همه اقلام انبار</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <input type="hidden" id="transfer-from-person-id">
                <p>از: <strong id="transfer-from-name"></strong></p>
                <div class="mb-3">
                    <label class="form-label">شعبهٔ مقصد</label>
                    <select id="cross-branch-select" class="form-select" onchange="loadBranchPersons()">
                        <option value="">-- همین شعبه --</option>
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3 form-check">
                    <input class="form-check-input" type="checkbox" id="no-person-check" onchange="togglePersonSelect()">
                    <label class="form-check-label" for="no-person-check">انتقال بدون انتساب به فرد</label>
                </div>
                <div class="mb-3" id="person-select-group">
                    <label class="form-label">فرد مقصد</label>
                    <select id="transfer-to-person" class="form-select">
                        <option value="">-- ابتدا شعبه را انتخاب کنید --</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button type="button" class="btn btn-primary" onclick="executeTransferAll()">انتقال کلی</button>
            </div>
        </div>
    </div>
</div>

<!-- مودال افزودن دستی -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>افزودن کالای جدید به انبار</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-3"><label class="form-label">نام کالا</label><input id="add-item-name" class="form-control" required></div>
                <div class="mb-3"><label class="form-label">کد اموال</label><input id="add-item-code" class="form-control"></div>
                <div class="mb-3"><label class="form-label">دسته</label><input id="add-item-category" class="form-control"></div>
                <div class="mb-3"><label class="form-label">سریال</label><input id="add-item-serial" class="form-control"></div>
                <div class="mb-3"><label class="form-label">توضیحات</label><textarea id="add-item-desc" class="form-control" rows="2"></textarea></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                <button type="button" class="btn btn-primary" onclick="saveAddItem()">ذخیره</button>
            </div>
        </div>
    </div>
</div>

<script src="../js/bootstrap.bundle.min.js"></script>
<script>
// ========== ویرایش ==========
function openEditModal(id, name, code, cat, serial, desc) {
    document.getElementById('edit-item-id').value = id;
    document.getElementById('edit-item-name').value = name;
    document.getElementById('edit-item-code').value = code;
    document.getElementById('edit-item-category').value = cat;
    document.getElementById('edit-item-serial').value = serial;
    document.getElementById('edit-item-desc').value = desc;
    new bootstrap.Modal(document.getElementById('editItemModal')).show();
}
async function saveEditItem() {
    const data = {
        id: document.getElementById('edit-item-id').value,
        item_name: document.getElementById('edit-item-name').value,
        item_code: document.getElementById('edit-item-code').value,
        category: document.getElementById('edit-item-category').value,
        serial_number: document.getElementById('edit-item-serial').value,
        description: document.getElementById('edit-item-desc').value
    };
    const resp = await fetch('edit_warehouse_item.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    const result = await resp.json();
    if (result.success) { bootstrap.Modal.getInstance(document.getElementById('editItemModal')).hide(); location.reload(); }
    else alert('خطا: ' + (result.message || 'نامشخص'));
}

// ========== انتقال تکی ==========
function toggleReassignPersonSelect() {
    const checked = document.getElementById('reassign-no-person-check').checked;
    document.getElementById('reassign-person-select-group').style.display = checked ? 'none' : 'block';
    if (checked) document.getElementById('reassign-new-person').value = '';
}
function openReassignModal(itemId, itemName, currentPerson) {
    document.getElementById('reassign-item-id').value = itemId;
    document.getElementById('reassign-item-name').textContent = itemName;
    document.getElementById('reassign-current-person').textContent = currentPerson;
    document.getElementById('reassign-branch-select').value = '';
    document.getElementById('reassign-no-person-check').checked = false;
    toggleReassignPersonSelect();
    const personSelect = document.getElementById('reassign-new-person');
    personSelect.innerHTML = '<option value="">-- ابتدا شعبه را انتخاب کنید --</option>';
    new bootstrap.Modal(document.getElementById('reassignModal')).show();
}
async function loadReassignBranchPersons() {
    const branchId = document.getElementById('reassign-branch-select').value;
    const personSelect = document.getElementById('reassign-new-person');
    personSelect.innerHTML = '<option value="">-- در حال بارگذاری --</option>';
    const resp = await fetch('get_persons_by_branch.php?branch_id=' + branchId);
    const persons = await resp.json();
    personSelect.innerHTML = '<option value="">-- انتخاب کنید --</option>';
    persons.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.first_name + ' ' + p.last_name + (p.personnel_code ? ' (' + p.personnel_code + ')' : '');
        personSelect.appendChild(opt);
    });
}
async function saveReassign() {
    const itemId = document.getElementById('reassign-item-id').value;
    const newPersonId = document.getElementById('reassign-new-person').value;
    const targetBranchId = document.getElementById('reassign-branch-select').value;
    const noPerson = document.getElementById('reassign-no-person-check').checked;
    if (!noPerson && !newPersonId) { alert('لطفاً فرد مقصد را انتخاب کنید یا گزینه بدون انتساب را تیک بزنید.'); return; }

    const body = { id: itemId, new_person_id: noPerson ? null : newPersonId, to_branch_id: targetBranchId && targetBranchId !== '' ? targetBranchId : null };
    const resp = await fetch('reassign_warehouse_item.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const result = await resp.json();
    if (result.success) { bootstrap.Modal.getInstance(document.getElementById('reassignModal')).hide(); location.reload(); }
    else alert('خطا: ' + (result.message || 'نامشخص'));
}

// ========== انتقال کلی ==========
function togglePersonSelect() { const checked = document.getElementById('no-person-check').checked; document.getElementById('person-select-group').style.display = checked ? 'none' : 'block'; if (checked) document.getElementById('transfer-to-person').value = ''; }
function openTransferAllModal(personId, personName) {
    document.getElementById('transfer-from-person-id').value = personId;
    document.getElementById('transfer-from-name').textContent = personName;
    document.getElementById('cross-branch-select').value = '';
    document.getElementById('no-person-check').checked = false;
    togglePersonSelect();
    const toPersonSelect = document.getElementById('transfer-to-person');
    toPersonSelect.innerHTML = '<option value="">-- ابتدا شعبه را انتخاب کنید --</option>';
    new bootstrap.Modal(document.getElementById('transferAllModal')).show();
}
async function loadBranchPersons() {
    const branchId = document.getElementById('cross-branch-select').value;
    const toPersonSelect = document.getElementById('transfer-to-person');
    toPersonSelect.innerHTML = '<option value="">-- در حال بارگذاری --</option>';
    const resp = await fetch('get_persons_by_branch.php?branch_id=' + branchId);
    const persons = await resp.json();
    toPersonSelect.innerHTML = '<option value="">-- انتخاب کنید --</option>';
    persons.forEach(p => {
        const opt = document.createElement('option'); opt.value = p.id;
        opt.textContent = p.first_name + ' ' + p.last_name + (p.personnel_code ? ' (' + p.personnel_code + ')' : '');
        toPersonSelect.appendChild(opt);
    });
}
async function executeTransferAll() {
    const fromId = document.getElementById('transfer-from-person-id').value;
    const toId = document.getElementById('transfer-to-person').value;
    const targetBranchId = document.getElementById('cross-branch-select').value;
    const noPerson = document.getElementById('no-person-check').checked;
    if (!noPerson && !toId) { alert('لطفاً فرد مقصد را انتخاب کنید یا گزینه بدون انتساب را تیک بزنید.'); return; }
    let url, body;
    if (targetBranchId && targetBranchId !== '') {
        url = 'cross_branch_transfer.php'; body = { from_person_id: fromId, to_branch_id: targetBranchId, to_person_id: noPerson ? null : toId };
    } else {
        if (!noPerson && !toId) { alert('فرد مقصد را انتخاب کنید.'); return; }
        url = 'transfer_all_warehouse.php'; body = { from_person_id: fromId, to_person_id: noPerson ? null : toId };
    }
    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const result = await resp.json();
    if (result.success) { bootstrap.Modal.getInstance(document.getElementById('transferAllModal')).hide(); location.reload(); }
    else alert('خطا: ' + (result.message || 'نامشخص'));
}

// ========== افزودن دستی ==========
function openAddModal() {
    document.getElementById('add-item-name').value = '';
    document.getElementById('add-item-code').value = '';
    document.getElementById('add-item-category').value = '';
    document.getElementById('add-item-serial').value = '';
    document.getElementById('add-item-desc').value = '';
    new bootstrap.Modal(document.getElementById('addItemModal')).show();
}
async function saveAddItem() {
    const data = {
        item_name: document.getElementById('add-item-name').value,
        item_code: document.getElementById('add-item-code').value,
        category: document.getElementById('add-item-category').value,
        serial_number: document.getElementById('add-item-serial').value,
        description: document.getElementById('add-item-desc').value
    };
    const resp = await fetch('add_warehouse_item.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    const result = await resp.json();
    if (result.success) { bootstrap.Modal.getInstance(document.getElementById('addItemModal')).hide(); location.reload(); }
    else alert('خطا: ' + (result.message || 'نامشخص'));
}
</script>
</body>
</html>