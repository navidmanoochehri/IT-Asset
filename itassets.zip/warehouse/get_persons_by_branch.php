<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/master_config.php';

header('Content-Type: application/json; charset=utf-8');

$branchId = $_GET['branch_id'] ?? 0;
$persons = [];

try {
    if ($branchId == 0) {
        $stmt = $pdo->query("SELECT id, first_name, last_name, personnel_code FROM persons WHERE is_active = 1 AND is_deleted = 0 ORDER BY last_name");
        $persons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $master_pdo->prepare("SELECT * FROM branches WHERE id = ?");
        $stmt->execute([$branchId]);
        $branch = $stmt->fetch();
        if (!$branch) {
            http_response_code(404);
            echo json_encode([]);
            exit;
        }
        $targetPdo = new PDO("mysql:host={$branch['db_host']};dbname={$branch['db_name']};charset=utf8mb4", $branch['db_user'], $branch['db_pass']);
        $targetPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $targetPdo->query("SELECT id, first_name, last_name, personnel_code FROM persons WHERE is_active = 1 AND is_deleted = 0 ORDER BY last_name");
        $persons = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}

echo json_encode($persons);