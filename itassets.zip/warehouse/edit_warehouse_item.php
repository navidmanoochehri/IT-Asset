<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

// فعال‌سازی نمایش خطاها فقط در زمان توسعه (اختیاری)
// در حالت production خطاها نباید نمایش داده شوند.
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر']);
    exit;
}

$id       = $input['id'] ?? 0;
$itemName = $input['item_name'] ?? '';
$itemCode = $input['item_code'] ?? '';
$category = $input['category'] ?? '';
$serial   = $input['serial_number'] ?? '';
$desc     = $input['description'] ?? '';

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'شناسه کالا نامعتبر']);
    exit;
}

// دریافت مقادیر قبلی
$stmt = $pdo->prepare("SELECT * FROM warehouse_items WHERE id = ?");
$stmt->execute([$id]);
$oldItem = $stmt->fetch();
if (!$oldItem) {
    echo json_encode(['success' => false, 'message' => 'کالا یافت نشد']);
    exit;
}

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("UPDATE warehouse_items SET item_name=?, item_code=?, category=?, serial_number=?, description=?, updated_at=NOW() WHERE id=?");
    $stmt->execute([$itemName, $itemCode, $category, $serial, $desc, $id]);

    // ثبت تغییرات در لاگ (اگر تغییری بود)
    $changes = [];
    foreach (['item_name','item_code','category','serial_number','description'] as $f) {
        $old = $oldItem[$f] ?? '';
        $new = $input[$f] ?? '';
        if ($old != $new) $changes[] = "انبار.{$f}: '{$old}' → '{$new}'";
    }
    if (!empty($changes)) {
        $personId = $oldItem['transferred_from_person_id'] ?? 0;
        logChange($pdo, $personId, 'update', implode(' | ', $changes), $itemCode);
    }

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}