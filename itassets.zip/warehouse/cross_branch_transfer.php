<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/master_config.php';

ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$fromPersonId = $input['from_person_id'] ?? 0;
$toBranchId   = $input['to_branch_id'] ?? 0;
$toPersonId   = $input['to_person_id'] ?? null;

if (!$toBranchId) {
    echo json_encode(['success' => false, 'message' => 'شعبه مقصد مشخص نشده']);
    exit;
}

// دریافت اطلاعات شعبه مقصد
$stmt = $master_pdo->prepare("SELECT * FROM branches WHERE id = ?");
$stmt->execute([$toBranchId]);
$destBranch = $stmt->fetch();
if (!$destBranch) {
    echo json_encode(['success' => false, 'message' => 'شعبه مقصد نامعتبر']);
    exit;
}

// اتصال به دیتابیس مقصد
try {
    $destPdo = new PDO("mysql:host={$destBranch['db_host']};dbname={$destBranch['db_name']};charset=utf8mb4", $destBranch['db_user'], $destBranch['db_pass']);
    $destPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به شعبه مقصد']);
    exit;
}

if ($toPersonId) {
    $check = $destPdo->prepare("SELECT id FROM persons WHERE id = ?");
    $check->execute([$toPersonId]);
    if (!$check->fetch()) {
        echo json_encode(['success' => false, 'message' => 'فرد مقصد در شعبه یافت نشد']);
        exit;
    }
}

if ($fromPersonId == 0) {
    $where = "WHERE transferred_from_person_id IS NULL";
    $fromName = 'انبار آزاد';
} else {
    $where = "WHERE transferred_from_person_id = $fromPersonId";
    $fromName = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $fromPersonId")->fetchColumn();
    if (!$fromName) $fromName = 'نامشخص';
}

$pdo->beginTransaction();
$destPdo->beginTransaction();
try {
    $items = $pdo->query("SELECT * FROM warehouse_items $where")->fetchAll();

    $firstCode = '';
    if (!empty($items)) {
        $firstCode = $items[0]['item_code'] ?? '';

        if ($toPersonId) {
            $invData = [];
            foreach ($items as $item) {
                $cat = $item['category'];
                $map = [
                    'کیس' => ['name'=>'case_name','code'=>'case_code'],
                    'مانیتور' => ['name'=>'monitor_name','code'=>'monitor_code'],
                    'کیبورد' => ['name'=>'keyboard_name','code'=>'keyboard_code'],
                    'تلفن' => ['name'=>'phone_name','code'=>'phone_code'],
                    'پرینتر' => ['name'=>'printer_name','code'=>'printer_code'],
                    'اسکنر' => ['name'=>'scanner_name','code'=>'scanner_code'],
                    'لپتاپ' => ['name'=>'laptop_name','code'=>'laptop_code'],
                    'ماوس' => ['name'=>'mouse_name','serial'=>'mouse_serial'],
                    'وبکم' => ['name'=>'webcam_name','serial'=>'webcam_serial'],
                ];
                if (isset($map[$cat])) {
                    $m = $map[$cat];
                    $invData[$m['name']] = trim(($invData[$m['name']]??'')."\n".$item['item_name']);
                    if ($m['code']) $invData[$m['code']] = trim(($invData[$m['code']]??'')."\n".$item['item_code']);
                    if (isset($m['serial']) && $m['serial']) $invData[$m['serial']] = trim(($invData[$m['serial']]??'')."\n".$item['serial_number']);
                }
            }

            $inv = $destPdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
            $inv->execute([$toPersonId]);
            $invExists = $inv->fetch();

            if ($invExists) {
                $sets = []; $params = [];
                foreach ($invData as $col => $val) {
                    $sets[] = "$col = CONCAT(COALESCE($col,''), ?, '\n')";
                    $params[] = $val;
                }
                if (!empty($sets)) {
                    $params[] = $toPersonId;
                    $destPdo->prepare("UPDATE inventory SET ".implode(',',$sets)." WHERE person_id = ?")->execute($params);
                }
            } else {
                $cols = array_keys($invData); $vals = array_values($invData);
                $q = rtrim(str_repeat('?,', count($cols)), ',');
                $destPdo->prepare("INSERT INTO inventory (person_id, ".implode(',',$cols).") VALUES (?, $q)")->execute(array_merge([$toPersonId], $vals));
            }

            $destPdo->prepare("INSERT INTO change_log (person_id, change_type, changed_by, change_description, related_asset_code) VALUES (?, 'update', ?, ?, ?)")
                ->execute([$toPersonId, $_SESSION['admin_name'] ?? 'سیستم', "دریافت کلیه اقلام انبار از {$fromName} (شعبه {$destBranch['name']})", $firstCode]);
        } else {
            foreach ($items as $item) {
                $desc = ($item['description']??'')." [انتقال از {$fromName} (شعبه مبدأ)]";
                $destPdo->prepare("INSERT INTO warehouse_items (item_name, item_code, category, brand, model, serial_number, description, transferred_from_person_id, transferred_date)
                    VALUES (?,?,?,?,?,?,?,NULL,NOW())")->execute([$item['item_name'], $item['item_code'], $item['category'], $item['brand']??'', $item['model']??'', $item['serial_number'], $desc]);
            }
        }

        // حذف از انبار مبدأ
        $pdo->exec("DELETE FROM warehouse_items $where");

        if ($fromPersonId != 0) {
            logChange($pdo, $fromPersonId, 'update', "انتقال کلیه اقلام انبار به شعبه {$destBranch['name']}", $firstCode);
        }
    }

    $pdo->commit();
    $destPdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    $destPdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}