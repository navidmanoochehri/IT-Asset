<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/master_config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$itemId      = $input['id'] ?? 0;
$newPersonId = $input['new_person_id'] ?? null;   // null یعنی بدون فرد
$toBranchId  = $input['to_branch_id'] ?? null;    // null یعنی همین شعبه

if (!$itemId) {
    echo json_encode(['success' => false, 'message' => 'شناسه کالا نامعتبر']);
    exit;
}

// دریافت اطلاعات کالا (با LEFT JOIN برای پوشش انبار آزاد)
$stmt = $pdo->prepare("SELECT w.*, p.first_name, p.last_name 
                       FROM warehouse_items w 
                       LEFT JOIN persons p ON w.transferred_from_person_id = p.id 
                       WHERE w.id = ?");
$stmt->execute([$itemId]);
$item = $stmt->fetch();
if (!$item) {
    echo json_encode(['success' => false, 'message' => 'کالا یافت نشد']);
    exit;
}

// ---------- انتقال داخلی (بدون شعبه مقصد) ----------
if (!$toBranchId) {
    if ($newPersonId) {
        $stmt = $pdo->prepare("SELECT first_name, last_name FROM persons WHERE id = ?");
        $stmt->execute([$newPersonId]);
        $newPerson = $stmt->fetch();
        if (!$newPerson) {
            echo json_encode(['success' => false, 'message' => 'فرد جدید یافت نشد']);
            exit;
        }
    }

    $pdo->beginTransaction();
    try {
        if ($newPersonId) {
            // نگاشت دسته به inventory
            $mapping = [
                'کیس'       => ['name' => 'case_name',    'code' => 'case_code',    'serial' => null],
                'مانیتور'   => ['name' => 'monitor_name', 'code' => 'monitor_code', 'serial' => null],
                'کیبورد'    => ['name' => 'keyboard_name','code' => 'keyboard_code','serial' => null],
                'ماوس'      => ['name' => 'mouse_name',   'code' => null,           'serial' => 'mouse_serial'],
                'تلفن'      => ['name' => 'phone_name',   'code' => 'phone_code',   'serial' => null],
                'هدست'      => ['name' => 'headset_name', 'code' => null,           'serial' => null],
                'وبکم'      => ['name' => 'webcam_name',  'code' => null,           'serial' => 'webcam_serial'],
                'پرینتر'    => ['name' => 'printer_name', 'code' => 'printer_code', 'serial' => null],
                'اسکنر'     => ['name' => 'scanner_name', 'code' => 'scanner_code', 'serial' => null],
                'لپتاپ'     => ['name' => 'laptop_name',  'code' => 'laptop_code',  'serial' => null],
                'مادربورد'  => ['name' => 'motherboard',  'code' => null,           'serial' => null],
                'پردازنده'  => ['name' => 'cpu',          'code' => null,           'serial' => null],
                'گرافیک'    => ['name' => 'graphics',     'code' => null,           'serial' => null],
                'رم'        => ['name' => 'ram',          'code' => null,           'serial' => null],
                'SSD/NVMe'  => ['name' => 'ssd_nvme',     'code' => null,           'serial' => null],
                'HDD'       => ['name' => 'hdd',          'code' => null,           'serial' => null],
                'سیستم‌عامل'=> ['name' => 'os',           'code' => null,           'serial' => null],
                'سایر'      => ['name' => 'other',        'code' => null,           'serial' => null],
            ];

            $cat = $item['category'];
            if (isset($mapping[$cat])) {
                $map = $mapping[$cat];
                $invData = [];
                if ($map['name'])  $invData[$map['name']]   = $item['item_name'];
                if ($map['code'])  $invData[$map['code']]   = $item['item_code'];
                if ($map['serial']) $invData[$map['serial']] = $item['serial_number'];

                // بررسی وجود inventory برای مقصد
                $inv = $pdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
                $inv->execute([$newPersonId]);
                $invExists = $inv->fetch();

                if ($invExists) {
                    $sets = []; $params = [];
                    foreach ($invData as $col => $val) {
                        // استفاده از CHAR(10) برای درج واقعی خط جدید
                        $sets[] = "$col = CONCAT(COALESCE($col,''), CHAR(10), ?)";
                        $params[] = $val;
                    }
                    if (!empty($sets)) {
                        $params[] = $newPersonId;
                        $pdo->prepare("UPDATE inventory SET " . implode(',', $sets) . " WHERE person_id = ?")->execute($params);
                    }
                } else {
                    $cols = array_keys($invData);
                    $vals = array_values($invData);
                    $placeholders = rtrim(str_repeat('?,', count($cols)), ',');
                    $sql = "INSERT INTO inventory (person_id, " . implode(',', $cols) . ") VALUES (?, $placeholders)";
                    array_unshift($vals, $newPersonId);
                    $pdo->prepare($sql)->execute($vals);
                }
            }

            // حذف از انبار
            $pdo->prepare("DELETE FROM warehouse_items WHERE id = ?")->execute([$itemId]);

            // لاگ دریافت‌کننده
            $oldPerson = trim(($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? ''));
            if (empty(trim($oldPerson))) $oldPerson = 'انبار آزاد';
            $newPersonName = trim($newPerson['first_name'] . ' ' . $newPerson['last_name']);
            logChange($pdo, $newPersonId, 'update', "دریافت کالای انبار ({$item['item_name']}) از {$oldPerson}", $item['item_code'] ?? '');

            // لاگ خروج از مالک قبلی (در صورت وجود)
            if ($item['transferred_from_person_id'] && $item['transferred_from_person_id'] != $newPersonId) {
                logChange($pdo, $item['transferred_from_person_id'], 'update', "خروج کالای انبار ({$item['item_name']}) به {$newPersonName}", $item['item_code'] ?? '');
            }
        } else {
            // بدون فرد مقصد ← انبار آزاد
            $pdo->prepare("UPDATE warehouse_items SET transferred_from_person_id = NULL, description = CONCAT(COALESCE(description,''), CHAR(10), '[خروج از فرد]') WHERE id = ?")->execute([$itemId]);

            if ($item['transferred_from_person_id']) {
                logChange($pdo, $item['transferred_from_person_id'], 'update', "خروج کالای انبار ({$item['item_name']}) - بدون انتساب", $item['item_code'] ?? '');
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// ---------- انتقال بین شعبی ----------
$stmt = $master_pdo->prepare("SELECT * FROM branches WHERE id = ?");
$stmt->execute([$toBranchId]);
$destBranch = $stmt->fetch();
if (!$destBranch) {
    echo json_encode(['success' => false, 'message' => 'شعبه مقصد نامعتبر']);
    exit;
}

try {
    $destPdo = new PDO("mysql:host={$destBranch['db_host']};dbname={$destBranch['db_name']};charset=utf8mb4", $destBranch['db_user'], $destBranch['db_pass']);
    $destPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در اتصال به شعبه مقصد']);
    exit;
}

if ($newPersonId) {
    $check = $destPdo->prepare("SELECT id, first_name, last_name FROM persons WHERE id = ?");
    $check->execute([$newPersonId]);
    $newPerson = $check->fetch();
    if (!$newPerson) {
        echo json_encode(['success' => false, 'message' => 'فرد مقصد در شعبه یافت نشد']);
        exit;
    }
}

$pdo->beginTransaction();
$destPdo->beginTransaction();
try {
    if ($newPersonId) {
        $mapping = [
            'کیس'       => ['name' => 'case_name',    'code' => 'case_code',    'serial' => null],
            'مانیتور'   => ['name' => 'monitor_name', 'code' => 'monitor_code', 'serial' => null],
            'کیبورد'    => ['name' => 'keyboard_name','code' => 'keyboard_code','serial' => null],
            'ماوس'      => ['name' => 'mouse_name',   'code' => null,           'serial' => 'mouse_serial'],
            'تلفن'      => ['name' => 'phone_name',   'code' => 'phone_code',   'serial' => null],
            'هدست'      => ['name' => 'headset_name', 'code' => null,           'serial' => null],
            'وبکم'      => ['name' => 'webcam_name',  'code' => null,           'serial' => 'webcam_serial'],
            'پرینتر'    => ['name' => 'printer_name', 'code' => 'printer_code', 'serial' => null],
            'اسکنر'     => ['name' => 'scanner_name', 'code' => 'scanner_code', 'serial' => null],
            'لپتاپ'     => ['name' => 'laptop_name',  'code' => 'laptop_code',  'serial' => null],
            'مادربورد'  => ['name' => 'motherboard',  'code' => null,           'serial' => null],
            'پردازنده'  => ['name' => 'cpu',          'code' => null,           'serial' => null],
            'گرافیک'    => ['name' => 'graphics',     'code' => null,           'serial' => null],
            'رم'        => ['name' => 'ram',          'code' => null,           'serial' => null],
            'SSD/NVMe'  => ['name' => 'ssd_nvme',     'code' => null,           'serial' => null],
            'HDD'       => ['name' => 'hdd',          'code' => null,           'serial' => null],
            'سیستم‌عامل'=> ['name' => 'os',           'code' => null,           'serial' => null],
            'سایر'      => ['name' => 'other',        'code' => null,           'serial' => null],
        ];

        $cat = $item['category'];
        if (isset($mapping[$cat])) {
            $map = $mapping[$cat];
            $invData = [];
            if ($map['name'])  $invData[$map['name']]   = $item['item_name'];
            if ($map['code'])  $invData[$map['code']]   = $item['item_code'];
            if ($map['serial']) $invData[$map['serial']] = $item['serial_number'];

            $inv = $destPdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
            $inv->execute([$newPersonId]);
            $invExists = $inv->fetch();

            if ($invExists) {
                $sets = []; $params = [];
                foreach ($invData as $col => $val) {
                    $sets[] = "$col = CONCAT(COALESCE($col,''), CHAR(10), ?)";
                    $params[] = $val;
                }
                if (!empty($sets)) {
                    $params[] = $newPersonId;
                    $destPdo->prepare("UPDATE inventory SET " . implode(',', $sets) . " WHERE person_id = ?")->execute($params);
                }
            } else {
                $cols = array_keys($invData);
                $vals = array_values($invData);
                $placeholders = rtrim(str_repeat('?,', count($cols)), ',');
                $sql = "INSERT INTO inventory (person_id, " . implode(',', $cols) . ") VALUES (?, $placeholders)";
                array_unshift($vals, $newPersonId);
                $destPdo->prepare($sql)->execute($vals);
            }
        }

        // حذف از انبار مبدأ
        $pdo->prepare("DELETE FROM warehouse_items WHERE id = ?")->execute([$itemId]);

        // لاگ مقصد
        $oldPerson = trim(($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? ''));
        if (empty(trim($oldPerson))) $oldPerson = 'انبار آزاد';
        $destPdo->prepare("INSERT INTO change_log (person_id, change_type, changed_by, change_description, related_asset_code) VALUES (?, 'update', ?, ?, ?)")
            ->execute([$newPersonId, $_SESSION['admin_name'] ?? 'سیستم', "دریافت کالای انبار ({$item['item_name']}) از {$oldPerson}", $item['item_code'] ?? '']);

        // لاگ مبدأ (خروج) – فقط در صورت وجود مالک قبلی
        if ($item['transferred_from_person_id']) {
            logChange($pdo, $item['transferred_from_person_id'], 'update', "خروج کالای انبار ({$item['item_name']}) به شعبه {$destBranch['name']}", $item['item_code'] ?? '');
        }
    } else {
        // انتقال بدون انتساب به انبار مقصد
        $newDesc = ($item['description'] ?? '') . " [انتقال از " . ($item['first_name'] ?? 'انبار آزاد') . " " . ($item['last_name'] ?? '') . " - شعبه مبدأ]";
        $destPdo->prepare("INSERT INTO warehouse_items (item_name, item_code, category, brand, model, serial_number, description, transferred_from_person_id, transferred_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NOW())")
            ->execute([$item['item_name'], $item['item_code'], $item['category'], $item['brand'] ?? '', $item['model'] ?? '', $item['serial_number'], $newDesc]);

        $pdo->prepare("DELETE FROM warehouse_items WHERE id = ?")->execute([$itemId]);

        if ($item['transferred_from_person_id']) {
            logChange($pdo, $item['transferred_from_person_id'], 'update', "خروج کالای انبار ({$item['item_name']}) به شعبه {$destBranch['name']}", $item['item_code'] ?? '');
        }
    }

    $pdo->commit();
    $destPdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $pdo->rollBack();
    $destPdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}