<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

ini_set('display_errors', 0);
ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'داده‌های ورودی نامعتبر']);
    exit;
}

$itemName = trim($input['item_name'] ?? '');
$itemCode = trim($input['item_code'] ?? '');
$category = trim($input['category'] ?? '');
$serial   = trim($input['serial_number'] ?? '');
$desc     = trim($input['description'] ?? '');

if ($itemName === '') {
    echo json_encode(['success' => false, 'message' => 'نام کالا الزامی است']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO warehouse_items (item_name, item_code, category, serial_number, description, transferred_from_person_id, transferred_date) VALUES (?, ?, ?, ?, ?, NULL, NOW())");
$stmt->execute([$itemName, $itemCode, $category, $serial, $desc]);

logChange($pdo, 0, 'update', "افزودن دستی کالا به انبار: {$itemName}", $itemCode);

echo json_encode(['success' => true]);