<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$results = [];
$search_done = isset($_GET['search']);
$mode = $_GET['mode'] ?? 'persons'; // persons یا warehouse

if ($search_done && !empty($_GET['term'])) {
    $term = '%' . trim($_GET['term']) . '%';
    $field = $_GET['field'] ?? 'all';

    if ($mode === 'warehouse') {
        // جستجو در انبار
        $sql = "SELECT * FROM warehouse_items WHERE ";
        if ($field == 'all') {
            $sql .= "(item_name LIKE ? OR item_code LIKE ? OR category LIKE ? OR serial_number LIKE ? OR description LIKE ?)";
            $params = array_fill(0, 5, $term);
        } else {
            $allowed = ['item_name','item_code','category','serial_number','description'];
            if (in_array($field, $allowed)) {
                $sql .= "$field LIKE ?";
                $params = [$term];
            } else {
                $sql .= "item_name LIKE ?";
                $params = [$term];
            }
        }
        $sql .= " ORDER BY created_at DESC LIMIT 200";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
    } else {
        // جستجو در پرسنل + inventory
        if ($field == 'all') {
            $sql = "SELECT p.personnel_code, p.first_name, p.last_name, p.unit, p.location,
                           i.case_name, i.case_code, i.monitor_name, i.monitor_code,
                           i.keyboard_name, i.keyboard_code, i.laptop_name, i.laptop_code,
                           i.phone_name, i.phone_code, i.printer_name, i.printer_code,
                           i.scanner_name, i.scanner_code, i.cpu, i.ram, i.os
                    FROM persons p
                    LEFT JOIN inventory i ON p.id = i.person_id
                    WHERE p.first_name LIKE ? OR p.last_name LIKE ? OR p.personnel_code LIKE ?
                       OR i.case_code LIKE ? OR i.monitor_code LIKE ? OR i.keyboard_code LIKE ?
                       OR i.phone_code LIKE ? OR i.printer_code LIKE ? OR i.scanner_code LIKE ?
                       OR i.laptop_code LIKE ? OR i.case_name LIKE ? OR i.monitor_name LIKE ?
                       OR i.laptop_name LIKE ?
                    ORDER BY p.last_name ASC LIMIT 200";
            $params = array_fill(0, 13, $term);   // دقیقاً ۱۳ جای‌نگهدار
        } else {
            $allowedPerson = ['personnel_code','first_name','last_name'];
            $allowedInv = ['case_code','monitor_code','keyboard_code','phone_code',
                           'printer_code','scanner_code','laptop_code','case_name',
                           'monitor_name','laptop_name','cpu','ram','os'];
            if (in_array($field, $allowedPerson)) {
                $sql = "SELECT p.personnel_code, p.first_name, p.last_name, p.unit, p.location,
                               i.case_name, i.case_code, i.monitor_name, i.laptop_name, i.cpu, i.ram, i.os
                        FROM persons p LEFT JOIN inventory i ON p.id = i.person_id
                        WHERE p.$field LIKE ?
                        ORDER BY p.last_name LIMIT 200";
                $params = [$term];
            } elseif (in_array($field, $allowedInv)) {
                $sql = "SELECT p.personnel_code, p.first_name, p.last_name, p.unit, p.location,
                               i.case_name, i.case_code, i.monitor_name, i.laptop_name, i.cpu, i.ram, i.os
                        FROM persons p LEFT JOIN inventory i ON p.id = i.person_id
                        WHERE i.$field LIKE ?
                        ORDER BY p.last_name LIMIT 200";
                $params = [$term];
            } else {
                // fallback
                $sql = "SELECT p.personnel_code, p.first_name, p.last_name, p.unit, p.location,
                               i.case_name, i.case_code, i.monitor_name, i.laptop_name, i.cpu, i.ram, i.os
                        FROM persons p LEFT JOIN inventory i ON p.id = i.person_id
                        WHERE p.last_name LIKE ?
                        ORDER BY p.last_name LIMIT 200";
                $params = [$term];
            }
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
    }
}

// خروجی CSV
if (isset($_GET['export']) && $_GET['export'] == 'csv' && !empty($results)) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=search_results.csv');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    if ($mode === 'warehouse') {
        fputcsv($out, ['نام کالا','کد','دسته','سریال','توضیحات','تاریخ ایجاد']);
        foreach ($results as $r) {
            fputcsv($out, [$r['item_name'], $r['item_code'], $r['category'], $r['serial_number'], $r['description'], $r['created_at']]);
        }
    } else {
        fputcsv($out, ['کد پرسنلی', 'نام', 'نام خانوادگی', 'واحد', 'محل', 'کیس', 'کد کیس', 'مانیتور', 'لپ‌تاپ', 'پردازنده', 'RAM', 'OS']);
        foreach ($results as $r) {
            fputcsv($out, [$r['personnel_code'], $r['first_name'], $r['last_name'], $r['unit'], $r['location'],
                $r['case_name'], $r['case_code'], $r['monitor_name'], $r['laptop_name'], $r['cpu'], $r['ram'], $r['os']]);
        }
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8"><title>جستجوی پیشرفته</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%,100%{transform: translate(0,0) scale(1);} 33%{transform: translate(40px,-40px) scale(1.05);} 66%{transform: translate(-30px,30px) scale(0.95);} }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); margin-bottom: 20px; }
        .nav-pills .nav-link { border-radius: 20px; margin: 0 4px; }
        .nav-pills .nav-link.active { background: #4e73df; color: #fff; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between">
        <a href="../dashboard.php" class="btn btn-primary btn-sm"><img src="../images/icons/home.png" width="18"> داشبورد</a>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <div class="card mb-4">
        <div class="card-header">
            <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link <?= $mode=='persons' ? 'active' : '' ?>" href="?mode=persons">پرسنل و تجهیزات</a></li>
                <li class="nav-item"><a class="nav-link <?= $mode=='warehouse' ? 'active' : '' ?>" href="?mode=warehouse">انبار</a></li>
            </ul>
        </div>
        <div class="card-body">
            <form method="get" class="row g-2 align-items-end">
                <input type="hidden" name="mode" value="<?= $mode ?>">
                <?php if ($mode === 'warehouse'): ?>
                    <div class="col-md-3">
                        <select name="field" class="form-select">
                            <option value="all" <?= ($_GET['field']??'all')=='all'?'selected':'' ?>>همه فیلدها</option>
                            <option value="item_name">نام کالا</option>
                            <option value="item_code">کد کالا</option>
                            <option value="category">دسته</option>
                            <option value="serial_number">سریال</option>
                            <option value="description">توضیحات</option>
                        </select>
                    </div>
                <?php else: ?>
                    <div class="col-md-3">
                        <select name="field" class="form-select">
                            <option value="all" <?= ($_GET['field']??'all')=='all'?'selected':'' ?>>همه فیلدها</option>
                            <option value="personnel_code">کد پرسنلی</option>
                            <option value="first_name">نام</option>
                            <option value="last_name">نام خانوادگی</option>
                            <option value="case_code">کد اموال کیس</option>
                            <option value="monitor_code">کد مانیتور</option>
                            <option value="keyboard_code">کد کیبورد</option>
                            <option value="phone_code">کد تلفن</option>
                            <option value="printer_code">کد پرینتر</option>
                            <option value="scanner_code">کد اسکنر</option>
                            <option value="laptop_code">کد لپ‌تاپ</option>
                            <option value="case_name">نام کیس</option>
                            <option value="monitor_name">نام مانیتور</option>
                            <option value="laptop_name">نام لپ‌تاپ</option>
                            <option value="cpu">پردازنده</option>
                            <option value="ram">RAM</option>
                            <option value="os">سیستم‌عامل</option>
                        </select>
                    </div>
                <?php endif; ?>
                <div class="col-md-5">
                    <input type="text" name="term" class="form-control" placeholder="حداقل یک کاراکتر..." value="<?= htmlspecialchars($_GET['term'] ?? '') ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" name="search" class="btn btn-primary w-100">جستجو</button>
                </div>
                <?php if (!empty($results)): ?>
                <div class="col-md-2">
                    <a href="?<?= http_build_query(array_merge($_GET, ['export'=>'csv'])) ?>" class="btn btn-success w-100"><img src="../images/icons/export.png" width="16"> CSV</a>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <?php if ($search_done): ?>
        <?php if (!empty($results)): ?>
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span>نتایج (<?= count($results) ?> مورد)</span>
                <button onclick="window.print()" class="btn btn-sm btn-secondary"><img src="../images/icons/print.png" width="16"> چاپ</button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <?php if ($mode === 'warehouse'): ?>
                                <tr>
                                    <th>نام کالا</th>
                                    <th>کد</th>
                                    <th>دسته</th>
                                    <th>سریال</th>
                                    <th>توضیحات</th>
                                    <th>تاریخ ایجاد</th>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <th>کد پرسنلی</th>
                                    <th>نام</th>
                                    <th>واحد</th>
                                    <th>کیس</th>
                                    <th>کد کیس</th>
                                    <th>مانیتور</th>
                                    <th>لپ‌تاپ</th>
                                    <th>پردازنده</th>
                                    <th>RAM</th>
                                </tr>
                            <?php endif; ?>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $row): ?>
                                <tr>
                                    <?php if ($mode === 'warehouse'): ?>
                                        <td><?= htmlspecialchars($row['item_name']) ?></td>
                                        <td><?= htmlspecialchars($row['item_code'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['category'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['serial_number'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['description'] ?? '') ?></td>
                                        <td><?= gregorian_to_jalali($row['created_at']) ?></td>
                                    <?php else: ?>
                                        <td><?= htmlspecialchars($row['personnel_code'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?></td>
                                        <td><?= htmlspecialchars($row['unit'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['case_name'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['case_code'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars(mb_substr($row['monitor_name'] ?? '', 0, 30)) ?></td>
                                        <td><?= htmlspecialchars($row['laptop_name'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['cpu'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($row['ram'] ?? '-') ?></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php else: ?>
            <div class="alert alert-info">نتیجه‌ای یافت نشد.</div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>