<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$personId    = $input['person_id'] ?? 0;
$inventoryId = $input['inventory_id'] ?? 0;
$fieldName   = $input['field_name'] ?? '';
$oldValue    = $input['old_value'] ?? '';

if (!$personId || !$inventoryId || !$fieldName || trim($oldValue) === '') {
    echo json_encode(['success' => false, 'message' => 'اطلاعات ناقص']);
    exit;
}

$category = 'سایر';
if (strpos($fieldName, 'case') !== false) $category = 'کیس';
elseif (strpos($fieldName, 'monitor') !== false) $category = 'مانیتور';
elseif (strpos($fieldName, 'keyboard') !== false) $category = 'کیبورد';
elseif (strpos($fieldName, 'mouse') !== false) $category = 'ماوس';
elseif (strpos($fieldName, 'phone') !== false) $category = 'تلفن';
elseif (strpos($fieldName, 'headset') !== false) $category = 'هدست';
elseif (strpos($fieldName, 'webcam') !== false) $category = 'وبکم';
elseif (strpos($fieldName, 'printer') !== false) $category = 'پرینتر';
elseif (strpos($fieldName, 'scanner') !== false) $category = 'اسکنر';
elseif (strpos($fieldName, 'laptop') !== false) $category = 'لپتاپ';

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ? AND person_id = ?");
    $stmt->execute([$inventoryId, $personId]);
    $inventory = $stmt->fetch();

    $codeField = str_replace('_name', '_code', $fieldName);
    $codeField = str_replace('_serial', '', $codeField);
    $itemCode = '';
    if ($codeField && $inventory && isset($inventory[$codeField])) {
        $lines = explode("\n", $inventory[$codeField] ?? '');
        $names = explode("\n", $inventory[$fieldName] ?? '');
        $idx = array_search($oldValue, $names);
        if ($idx !== false && isset($lines[$idx])) $itemCode = trim($lines[$idx]);
    }

    $insert = $pdo->prepare("INSERT INTO warehouse_items (item_name, item_code, category, description, transferred_from_person_id, transferred_date)
        VALUES (?, ?, ?, ?, NULL, NOW())");
    $desc = "انتقال مستقیم از inventory – فیلد: $fieldName";
    $insert->execute([$oldValue, $itemCode, $category, $desc]);

    $current = $inventory[$fieldName] ?? '';
    $lines = explode("\n", $current);
    $lines = array_filter($lines, fn($line) => trim($line) !== trim($oldValue));
    $newValue = implode("\n", $lines);
    $pdo->prepare("UPDATE inventory SET `$fieldName` = ? WHERE id = ? AND person_id = ?")->execute([$newValue, $inventoryId, $personId]);

    logChange($pdo, $personId, 'update', "انتقال قطعهٔ {$fieldName} ({$oldValue}) به انبار آزاد", $itemCode);

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) { $pdo->rollBack(); echo json_encode(['success' => false, 'message' => $e->getMessage()]); }