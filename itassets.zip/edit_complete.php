<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

$person_id = $_GET['person_id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM persons WHERE id = ?");
$stmt->execute([$person_id]);
$person = $stmt->fetch();
if (!$person) die('فرد یافت نشد.');

$stmt = $pdo->prepare("SELECT * FROM inventory WHERE person_id = ?");
$stmt->execute([$person_id]);
$inventory = $stmt->fetch();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("UPDATE persons SET personnel_code=?, first_name=?, last_name=?, username=?, unit=?, location=? WHERE id=?");
        $stmt->execute([
            $_POST['personnel_code'] ?? '',
            $_POST['first_name'],
            $_POST['last_name'],
            $_POST['username'] ?? '',
            $_POST['unit'] ?? '',
            $_POST['location'] ?? '',
            $person_id
        ]);

        $listFields = [
            'case_name', 'case_code', 'monitor_name', 'monitor_code', 'keyboard_name', 'keyboard_code',
            'mouse_name', 'mouse_serial', 'phone_name', 'phone_code', 'headset_name', 'webcam_name', 'webcam_serial',
            'printer_name', 'printer_code', 'scanner_name', 'scanner_code', 'laptop_name', 'laptop_code',
            'motherboard', 'cpu', 'graphics', 'ram', 'ssd_nvme', 'hdd', 'dvd_rw', 'os', 'other', 'description'
        ];

        foreach ($listFields as $f) {
            if (isset($_POST[$f]) && is_array($_POST[$f])) {
                $_POST[$f] = implode("\n", array_map('trim', $_POST[$f]));
            }
        }

        $params = [];
        foreach ($listFields as $f) $params[] = $_POST[$f] ?? '';

        if ($inventory) {
            $set = implode('=?, ', $listFields) . '=?';
            $stmt = $pdo->prepare("UPDATE inventory SET $set WHERE person_id=?");
            $params[] = $person_id;
            $stmt->execute($params);
        } else {
            $cols = implode(',', $listFields);
            $q = rtrim(str_repeat('?,', count($listFields)), ',');
            $stmt = $pdo->prepare("INSERT INTO inventory (person_id, $cols) VALUES (?, $q)");
            array_unshift($params, $person_id);
            $stmt->execute($params);
        }

        $pdo->commit();

        // ثبت لاگ
        $changes = [];
        foreach (['personnel_code','first_name','last_name','username','unit','location'] as $f) {
            $old = $person[$f] ?? ''; $new = $_POST[$f] ?? '';
            if ($old != $new) $changes[] = "پرسنل.{$f}: «{$old}» → «{$new}»";
        }
        foreach ($listFields as $f) {
            $old = $inventory[$f] ?? ''; $new = $_POST[$f] ?? '';
            if ($old != $new) $changes[] = "{$f}: «{$old}» → «{$new}»";
        }
        $firstCode = getFirstAssetCode($_POST);
        if (!empty($changes)) {
            logChange($pdo, $person_id, 'update', implode(' | ', $changes), $firstCode);
        } else {
            logChange($pdo, $person_id, 'update', 'ویرایش بدون تغییر محسوس', $firstCode);
        }

        $msg = '<div class="alert alert-success text-center">✅ ویرایش شد</div>';
    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = '<div class="alert alert-danger">❌ خطا: ' . $e->getMessage() . '</div>';
    }
}

// تابع تفکیک خطوط بهبودیافته (پشتیبانی از انواع خط جدید)
function splitLines($value) {
    $lines = preg_split('/\R/', $value ?? '');
    return array_map('trim', $lines);
}
function esc($val) { return htmlspecialchars($val ?? ''); }

$sections = [
    ['case','کیس',['case_name'=>'نام/مدل','case_code'=>'کد اموال']],
    ['monitor','مانیتور',['monitor_name'=>'مدل','monitor_code'=>'کد اموال']],
    ['keyboard','کیبورد',['keyboard_name'=>'مدل','keyboard_code'=>'کد اموال']],
    ['mouse','ماوس',['mouse_name'=>'مدل','mouse_serial'=>'سریال']],
    ['phone','تلفن',['phone_name'=>'مدل','phone_code'=>'کد اموال']],
    ['headset','هدست',['headset_name'=>'مدل']],
    ['webcam','وبکم',['webcam_name'=>'مدل','webcam_serial'=>'سریال']],
    ['printer','پرینتر',['printer_name'=>'مدل','printer_code'=>'کد اموال']],
    ['scanner','اسکنر',['scanner_name'=>'مدل','scanner_code'=>'کد اموال']],
    ['laptop','لپ‌تاپ',['laptop_name'=>'مدل','laptop_code'=>'کد اموال']],
    ['tech','مشخصات فنی',['motherboard'=>'مادربورد','cpu'=>'پردازنده','graphics'=>'گرافیک','ram'=>'RAM','ssd_nvme'=>'SSD/NVMe','hdd'=>'HDD','dvd_rw'=>'DVD RW','os'=>'سیستم‌عامل']],
];

// آماده‌سازی داده برای جاوااسکریپت
$jsData = [
    'personId' => $person_id,
    'inventoryId' => $inventory['id'] ?? 0,
    'sections' => []
];
foreach ($sections as $sec) {
    $key = $sec[0];
    $fields = $sec[2];
    $firstField = array_key_first($fields);
    $firstLines = splitLines($inventory[$firstField] ?? '');
    $items = [];
    foreach ($firstLines as $idx => $line) {
        $item = [];
        foreach ($fields as $field => $label) {
            $lines = splitLines($inventory[$field] ?? '');
            $item[$field] = $lines[$idx] ?? '';
        }
        $items[] = $item;
    }
    $jsData['sections'][] = [
        'key' => $key,
        'title' => $sec[1],
        'fields' => array_keys($fields),
        'items' => $items
    ];
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8"><title>ویرایش <?= esc($person['first_name'].' '.$person['last_name']) ?></title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%,100%{transform: translate(0,0) scale(1);} 33%{transform: translate(40px,-40px) scale(1.05);} 66%{transform: translate(-30px,30px) scale(0.95);} }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .section-card { background: #fff; border: 1px solid rgba(0,0,0,0.05); border-radius: 20px; margin-bottom: 20px; overflow: hidden; }
        .section-header { padding: 14px 20px; background: linear-gradient(135deg, #f6c23e, #e0a800); color: #000; font-weight: bold; display: flex; align-items: center; }
        .section-body { padding: 20px; }
        .btn-submit { background: linear-gradient(135deg, #f6c23e, #e0a800); border: none; color: #000; padding: 12px 40px; border-radius: 50px; }
        .list-item { display: flex; align-items: center; gap: 8px; background: #f8f9fa; border-radius: 10px; padding: 8px 12px; margin-bottom: 6px; flex-wrap: wrap; }
        .list-item input { flex: 1 1 150px; min-width: 100px; }
        .list-item .btn { white-space: nowrap; }
        .btn-warning img, .btn-info img, .btn-danger img { filter: brightness(0) invert(1); }
        .required-star { color: red; font-weight: bold; margin-left: 2px; }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between">
        <a href="search_edit.php" class="btn btn-primary btn-sm"><img src="images/icons/back.png" width="18" style="margin-left:5px;"> بازگشت</a>
    </div>
</nav>
<div class="container py-4" style="position: relative; z-index: 1;">
    <?= $msg ?>
    <h2 class="text-center mb-4">ویرایش: <?= esc($person['first_name'].' '.$person['last_name']) ?></h2>
    <form method="post" id="editForm">
        <div class="section-card">
            <div class="section-header"><img src="images/icons/person.png" width="24" style="margin-left:8px;"> اطلاعات پرسنلی</div>
            <div class="section-body">
                <div class="row g-3">
                    <div class="col-md-4"><label>کد پرسنلی</label><input name="personnel_code" class="form-control" value="<?=esc($person['personnel_code'])?>"></div>
                    <div class="col-md-4"><label>نام <span class="required-star">*</span></label><input name="first_name" class="form-control" required value="<?=esc($person['first_name'])?>"></div>
                    <div class="col-md-4"><label>نام خانوادگی <span class="required-star">*</span></label><input name="last_name" class="form-control" required value="<?=esc($person['last_name'])?>"></div>
                    <div class="col-md-4"><label>نام کاربری</label><input name="username" class="form-control" value="<?=esc($person['username'])?>"></div>
                    <div class="col-md-4"><label>واحد</label><input name="unit" class="form-control" value="<?=esc($person['unit'])?>"></div>
                    <div class="col-md-4"><label>محل استقرار</label><input name="location" class="form-control" value="<?=esc($person['location'])?>"></div>
                </div>
            </div>
        </div>

        <?php foreach ($sections as $sec):
            $key = $sec[0]; $title = $sec[1]; $fields = $sec[2];
            $firstField = array_key_first($fields);
            $firstLines = splitLines($inventory[$firstField] ?? '');
        ?>
        <div class="section-card">
            <div class="section-header"><img src="images/icons/<?=$key?>.png" width="24" style="margin-left:8px;"> <?=$title?></div>
            <div class="section-body">
                <div class="dynamic-list" data-fields="<?= implode(',', array_keys($fields)) ?>" data-primary="<?=$firstField?>">
                    <?php foreach ($firstLines as $idx => $line): ?>
                        <div class="list-item">
                            <?php foreach ($fields as $field => $label):
                                $lines = splitLines($inventory[$field] ?? '');
                                $value = $lines[$idx] ?? '';
                            ?>
                                <input type="text" class="form-control form-control-sm" name="<?=$field?>[]" placeholder="<?=$label?>" value="<?=esc($value)?>">
                            <?php endforeach; ?>
                            <button type="button" class="btn btn-sm btn-warning" onclick="openEventModal('<?=$firstField?>','<?=esc($line)?>')"><img src="images/icons/settings.png" width="14"></button>
                            <button type="button" class="btn btn-sm btn-info" onclick="transferToWarehouse('<?=$firstField?>','<?=esc($line)?>')"><img src="images/icons/transfer.png" width="14"></button>
                            <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.list-item').remove()"><img src="images/icons/delete.png" width="14"></button>
                        </div>
                    <?php endforeach; ?>
                    <button type="button" class="btn btn-sm btn-outline-primary mt-2 add-list-item">+ افزودن</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <div class="section-card">
            <div class="section-header"><img src="images/icons/other.png" width="24"> سایر و توضیحات</div>
            <div class="section-body">
                <div class="row g-3">
                    <div class="col-12"><label>سایر</label><textarea name="other" class="form-control" rows="2"><?=esc($inventory['other']??'')?></textarea></div>
                    <div class="col-12"><label>توضیحات</label><textarea name="description" class="form-control" rows="2"><?=esc($inventory['description']??'')?></textarea></div>
                </div>
            </div>
        </div>

        <div class="text-center mt-4"><button type="submit" class="btn btn-submit btn-lg shadow">ذخیره تغییرات</button></div>
    </form>
</div>

<!-- مودال رخداد -->
<div class="modal fade" id="eventModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"><h5>ثبت رخداد برای <span id="event-field-label"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="eventForm">
                    <input type="hidden" name="person_id" id="event-person-id">
                    <input type="hidden" name="inventory_id" id="event-inventory-id">
                    <input type="hidden" name="field_name" id="event-field-name">
                    <input type="hidden" name="old_value" id="event-old-value">
                    <div class="mb-3"><label>نوع رویداد</label><select name="event_type" id="event-type" class="form-select"><option value="failure">خرابی - اسقاط</option><option value="repair">تعمیر - ارسال به پیمانکار</option><option value="replace">تعویض</option><option value="upgrade">ارتقا</option><option value="transfer_warehouse">انتقال به انبار</option><option value="replace_defective">جایگزینی با قطعه سالم</option></select></div>
                    <div class="mb-3"><label>مقدار فعلی</label><input class="form-control" id="event-old-display" readonly></div>
                    <div class="mb-3" id="new-value-group" style="display:none;"><label>مقدار جدید</label><input name="new_value" class="form-control" id="event-new-value"></div>
                    <div class="mb-3"><label>توضیحات</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </form>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button><button type="button" class="btn btn-primary" onclick="saveEvent()">ذخیره</button></div>
        </div>
    </div>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
<script>
const PERSON_ID = '<?=$person_id?>';
const INVENTORY_ID = '<?=$inventory['id'] ?? 0?>';

document.querySelectorAll('.add-list-item').forEach(btn => {
    btn.addEventListener('click', function() {
        const container = this.parentElement;
        const fields = container.dataset.fields.split(',');
        const primary = container.dataset.primary;
        const div = document.createElement('div');
        div.className = 'list-item';
        fields.forEach(f => div.innerHTML += `<input type="text" class="form-control form-control-sm" name="${f}[]" placeholder="">`);
        div.innerHTML += `
            <button type="button" class="btn btn-sm btn-warning" onclick="openEventModal('${primary}','')"><img src="images/icons/settings.png" width="14"></button>
            <button type="button" class="btn btn-sm btn-info" onclick="transferToWarehouse('${primary}','')"><img src="images/icons/transfer.png" width="14"></button>
            <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.list-item').remove()"><img src="images/icons/delete.png" width="14"></button>
        `;
        container.insertBefore(div, this);
    });
});

function openEventModal(fieldName, oldValue) {
    document.getElementById('event-person-id').value = PERSON_ID;
    document.getElementById('event-inventory-id').value = INVENTORY_ID;
    document.getElementById('event-field-name').value = fieldName;
    document.getElementById('event-old-value').value = oldValue;
    document.getElementById('event-old-display').value = oldValue;
    document.getElementById('event-field-label').textContent = fieldName;
    document.getElementById('event-new-value').value = '';
    document.getElementById('new-value-group').style.display = 'none';
    new bootstrap.Modal(document.getElementById('eventModal')).show();
}

document.getElementById('event-type').addEventListener('change', function() {
    const showNew = ['replace','upgrade','replace_defective'].includes(this.value);
    document.getElementById('new-value-group').style.display = showNew ? 'block' : 'none';
});

async function saveEvent() {
    const form = document.getElementById('eventForm');
    const formData = new FormData(form);
    const resp = await fetch('save_event.php', { method: 'POST', body: formData });
    const result = await resp.json();
    if (result.success) { alert('✅ رویداد ثبت شد.'); bootstrap.Modal.getInstance(document.getElementById('eventModal')).hide(); }
    else alert('❌ خطا: ' + result.message);
}

async function transferToWarehouse(fieldName, oldValue) {
    if (!oldValue || !confirm('آیا از انتقال این قطعه به انبار آزاد اطمینان دارید؟')) return;
    const resp = await fetch('transfer_field_to_warehouse.php', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ person_id: PERSON_ID, inventory_id: INVENTORY_ID, field_name: fieldName, old_value: oldValue })
    });
    const result = await resp.json();
    if (result.success) { alert('✅ قطعه به انبار آزاد منتقل شد.'); location.reload(); }
    else alert('❌ خطا: ' + (result.message || 'نامشخص'));
}
</script>
</body>
</html>