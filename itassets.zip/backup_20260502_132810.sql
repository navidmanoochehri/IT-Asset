CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `admins` VALUES ('1','admin','$2y$10$.aDAWz6qx0UAlTqbcLcLWuIvtWeQv/3rOmCvVFpvX53PotxfDCUkm','مدیر سیستم','2026-05-02 11:31:04');


CREATE TABLE `asset_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `event_type` enum('failure','repair','replace','upgrade','transfer_warehouse','replace_defective') NOT NULL,
  `field_name` varchar(50) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `asset_events_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_events_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;



CREATE TABLE `change_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `change_type` enum('create','update','delete') NOT NULL,
  `changed_by` varchar(100) DEFAULT NULL,
  `change_description` text NOT NULL,
  `related_asset_code` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `change_log_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `change_log` VALUES ('1','1','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA+','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('2','2','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA+','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('3','3','create','مدیر سیستم','واردات از فایل XLSX','Green PARS EVO','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('4','4','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('5','5','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('6','6','create','مدیر سیستم','واردات از فایل XLSX','Green MD121','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('7','7','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('8','8','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('9','9','create','مدیر سیستم','واردات از فایل XLSX','Green pars','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('10','10','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('11','11','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('12','12','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('13','13','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');
INSERT INTO `change_log` VALUES ('14','14','create','مدیر سیستم','واردات از فایل XLSX','Green HIWA','2026-05-02 14:33:57');


CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `case_name` varchar(100) DEFAULT NULL,
  `case_code` varchar(30) DEFAULT NULL,
  `monitor_name` text DEFAULT NULL,
  `monitor_code` text DEFAULT NULL,
  `keyboard_name` varchar(100) DEFAULT NULL,
  `keyboard_code` varchar(30) DEFAULT NULL,
  `mouse_name` varchar(100) DEFAULT NULL,
  `mouse_serial` varchar(100) DEFAULT NULL,
  `phone_name` varchar(100) DEFAULT NULL,
  `phone_code` varchar(30) DEFAULT NULL,
  `headset_name` varchar(100) DEFAULT NULL,
  `webcam_name` varchar(100) DEFAULT NULL,
  `webcam_serial` varchar(100) DEFAULT NULL,
  `printer_name` varchar(100) DEFAULT NULL,
  `printer_code` varchar(30) DEFAULT NULL,
  `scanner_name` varchar(100) DEFAULT NULL,
  `scanner_code` varchar(30) DEFAULT NULL,
  `laptop_name` varchar(100) DEFAULT NULL,
  `laptop_code` varchar(30) DEFAULT NULL,
  `dvd_rw` varchar(100) DEFAULT NULL,
  `motherboard` varchar(100) DEFAULT NULL,
  `cpu` varchar(100) DEFAULT NULL,
  `graphics` varchar(100) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `ssd_nvme` varchar(100) DEFAULT NULL,
  `hdd` varchar(100) DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `other` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `current_status` varchar(50) DEFAULT 'سالم',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `inventory` VALUES ('1','1','Green HIWA+','28881','SAMSUNG -S22R350FHM','28447','logitech','28602','logitech -M90','2045HS044CS8','KX-DT346','27428','A4TECH','no name','28680','','','','','','','','PRIME H610M-K D4','i3-14100','','16 + 4 GB DDR4','480 GB, NVMe','6 T',' Windows 11 Enterprise (x64) Build 26200.7840 (25H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('2','2','Green HIWA+','28876','SAMSUNG -ls22f355hn\nSAMSUNG -ls22f355hn','28009\n28252','logitech K270','28638','logitech -M185','1632LZX3LJE8','KX-DT346','27929','A4TECH','','','','','','','','','','','','','16 + 4 GB DDR4','480 GB, SSD\n250 GB, SSD','4 T','Windows 11 Enterprise (x64) Build 26200.7922 (25H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('3','3','Green PARS EVO','28002','ASUS - VZ24E','28802','logitech k120\nLOGI K295','28607\n28850','logi - m190\nlogi - M220','no sn\n810-007561','KX-DT346','27925','A4TECH','logi','28450','','','','','','','','Z690-PLUS WIFI','i7-12700K','','16 +16 FGB DDR5','480 GB, NVMe','6 T','Windows 11 Enterprise (x64) Build 26200.7840 (25H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('4','4','Green HIWA','28692','SUMSUNG -B2055 PLUS','27852','logitech k120','28667','logitech -N400','N160702937','KX-T636','27241','','','','CANON - F151400','27057','KODAK - I2620','28320','','','ASUS','PRIME H310M-C/PS R2.0','Pentium Gold G5420','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19044.1499 (21H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('5','5','Green HIWA','28513','LG - 22MK400H','28650','logitech k120','28600','A4TECH - N300','no sn','KX-T7665','28405','A4TECH','no name','28491','','','AVISION - AD120','28672','','','','PRIME H310M-C/PS R2.0','Pentium Gold G5420','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19043.2251 (21H1','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('6','6','Green MD121','27259','SUMSUNG -1943 SN PLUS','27415','logitech k120','28556','logitech -M90','810-002147','KX-T7665','28324','','','','','','','','','','','H81M-C','Core i3-4130','','4 + 2 DDR3','250GB Samsung SSD 870 EVO ','','Windows 11 Enterprise (x64) Build 26100.2314 (24H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('7','7','Green HIWA','28510','LG - E2040S','27258','logitech k120','28603','logitech -U0026','810-002182','KX-T7665','27280','','','','HP- M402DNE','28078','','','','','','PRIME H310M-C/PS R2.0','Pentium Gold G5420','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19042.2251 (20H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('8','8','Green HIWA','28797','LG - 19E233','27824','logitech k120','28571','A4TECH - N302','N151200232','KX-T7665','27291','','','','','','','','','','','ASUS Z170-K','Core i7-7700','','16 GB DDR4','250GB Samsung SSD 870 EVO ','','Windows 11 Enterprise (x64) Build 26100.7171 (24H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('9','9','Green pars','27183','SUMSUNG -b2255n plus','27917','a4tech kl7mu','28596','logitech -b100','810-003656','KX-T7665','28411','xmax','no name','28493','','','','','','','','H61M-PRO','Core i3-2100','','4 + 2 DDR3','240 GB ,SSD ADATA SU630','','Windows 10 Enterprise (x64) Build 19043.2251 (21H1)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('10','10','Green HIWA','28673','LG - 20MP38HB','20856','a4tech KR83','28594','Genius','x6e927880020','KX-T7665','27313','','','','HP -P3015','27316','','','','','','PRIME H310M-C/PS R2.0','Pentium Gold G5420','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19043.2251 (21H1)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('11','11','Green HIWA','28412','LG 20MP38HB','28052','a4tech KR83','28591','logitech -G102','2346LZXKNJ98','KX-T7665','28406','','','','','','','','','','','H110M-K','Pentium G4400','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 11 Enterprise (x64) Build 26100.6899 (24H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('12','12','Green HIWA','28166','SUMSUNG -sn1943','27380','logitech k120','28652','logitech -M90','810-002147','KX-T7665','28541','','','','','','hp scanjet 5590','27381','','','','H81M-K','Pentium G3250','','4 +4 DDR3','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19044.1889 (21H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('13','13','Green HIWA','28021','LG - 22MK400H -B','28131','BEYOND BMK9596RF','28590','BEYOND BMK 9596 RF','3972B932216847','KX-T7665','27397','','','','HP P1102','28039','','','','','PIONEER DVD-RW','H110M-C/PS','Pentium G4400','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Professional (x64) Build 19045.2846 (22H2)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');
INSERT INTO `inventory` VALUES ('14','14','Green HIWA','28669','LG - 20MP38HB','28118','a4tech KR86','28592','logitech -M90','810-002147','KX-T7665','28517','','','','HP P2055DN','28051','','','','','','PRIME H310M-C/PS R2.0','Pentium Gold G5420','','8 GB DDR4','240 GB ,SSD ADATA SU650','','Windows 10 Enterprise (x64) Build 19043.2251 (21H1)','','','','2026-05-02 14:33:57','2026-05-02 14:33:57');


CREATE TABLE `persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personnel_code` varchar(20) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `unit` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `persons` VALUES ('1','1419','سامان','گرانمایه','s.geranmayeh','انفورماتیک','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('2','1317','نوید','منوچهری','n.manoochehri','انفورماتیک','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('3','1407','علیرضا','رنجی','ar.ranji','انفورماتیک','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('4','1454','رویا','مرشدی','r.morshedi','ارتباطات','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('5','1375','معصومه','خزائی','m.khazaei','منابع انسانی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('6','','','آزمون منابع انسانی','','منابع انسانی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('7','','','کارشناس حقوق دستمزد','','منابع انسانی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('8','','','سرپرست پشتیبانی','','منابع انسانی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('9','','حمیده','رسولی','h.rasooli','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('10','1018','مرتضی','میری','m.miri','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('11','1254','ناصر','ابراهیم زاده','n.ebrahimzadeh','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('12','1008','مجید','قدرتی','m.ghodrati','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('13','1213','نوید','هنرفر','n.honarfar','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');
INSERT INTO `persons` VALUES ('14','1348','مهدی','خسروی','m.khosravi','مالی','طبقه سوم','1','0','2026-05-02 14:33:57');


CREATE TABLE `warehouse_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `item_code` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `transferred_from_person_id` int(11) DEFAULT NULL,
  `transferred_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transferred_from_person_id` (`transferred_from_person_id`),
  CONSTRAINT `warehouse_items_ibfk_1` FOREIGN KEY (`transferred_from_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;



