<?php
require_once 'includes/auth.php';
require_once 'includes/master_config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$branchId = $_POST['branch_id'] ?? 0;

// فقط مدیرکل می‌تواند هر شعبه‌ای را انتخاب کند
if (($_SESSION['admin_role'] ?? '') !== 'super_admin') {
    if ($branchId != $_SESSION['admin_branch_id']) {
        echo json_encode(['success' => false, 'message' => 'شما مجاز به تغییر شعبه نیستید']);
        exit;
    }
}

$stmt = $master_pdo->prepare("SELECT * FROM branches WHERE id = ? AND is_active = 1");
$stmt->execute([$branchId]);
$branch = $stmt->fetch();

if (!$branch) {
    echo json_encode(['success' => false, 'message' => 'شعبه معتبر نیست']);
    exit;
}

// جایگزینی اطلاعات شعبه در نشست
$_SESSION['admin_branch_id'] = $branch['id'];
$_SESSION['branch_db'] = [
    'host'   => $branch['db_host'],
    'dbname' => $branch['db_name'],
    'user'   => $branch['db_user'],
    'pass'   => $branch['db_pass']
];
$_SESSION['branch_name'] = $branch['name'];

echo json_encode(['success' => true]);