<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// اگر اطلاعات شعبه در session باشد، به آن وصل می‌شویم
if (isset($_SESSION['branch_db'])) {
    $branch = $_SESSION['branch_db'];
    define('DB_HOST', $branch['host']);
    define('DB_NAME', $branch['dbname']);
    define('DB_USER', $branch['user']);
    define('DB_PASS', $branch['pass']);
} else {
    // اتصال پیش‌فرض (برای جلوگیری از خطاهای احتمالی)
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'asset_management');
    define('DB_USER', 'root');
    define('DB_PASS', '123456');         // ← رمز جدید
}

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
} catch (PDOException $e) {
    die("خطا در اتصال به پایگاه داده: " . $e->getMessage());
}

// ========== توابع کمکی ==========

/**
 * ثبت لاگ تغییرات در دیتابیس فعلی (شعبه)
 */
function logChange($pdo, $person_id, $type, $description, $asset_code = null) {
    $stmt = $pdo->prepare("INSERT INTO change_log (person_id, change_type, changed_by, change_description, related_asset_code) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        $person_id,
        $type,
        $_SESSION['admin_name'] ?? 'سیستم',
        $description,
        $asset_code
    ]);
}

/**
 * تبدیل تاریخ میلادی به شمسی (Jalali)
 */
function gregorian_to_jalali($gregorian_date) {
    $timestamp = strtotime($gregorian_date);
    if (!$timestamp) return $gregorian_date;

    $gYear  = (int)date('Y', $timestamp);
    $gMonth = (int)date('n', $timestamp);
    $gDay   = (int)date('j', $timestamp);
    $gTime  = date('H:i', $timestamp);

    $gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $days = $gDaysInMonth[$gMonth - 1] + $gDay;

    if ($gMonth > 2 && (($gYear % 4 == 0 && $gYear % 100 != 0) || $gYear % 400 == 0)) {
        $days++;
    }

    if ($days > 79) {
        $days -= 79;
        $jYear = $gYear - 621;
    } else {
        $jYear = $gYear - 622;
        $days += 286;
    }

    $jDaysInMonth = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    if ((($jYear + 1) % 4 == 0 && ($jYear + 1) % 100 != 0) || ($jYear + 1) % 400 == 0) {
        $jDaysInMonth[11] = 30;
    }

    $jMonth = 0;
    $jDay = $days;
    while ($jDay > $jDaysInMonth[$jMonth]) {
        $jDay -= $jDaysInMonth[$jMonth];
        $jMonth++;
    }
    $jMonth++;

    return $jYear . '/' . str_pad($jMonth, 2, '0', STR_PAD_LEFT) . '/' . str_pad($jDay, 2, '0', STR_PAD_LEFT) . ' ' . $gTime;
}

/**
 * تبدیل تاریخ شمسی به میلادی
 */
function jalali_to_gregorian($jalali_date) {
    $parts = explode('/', $jalali_date);
    if (count($parts) !== 3) return false;
    $jYear  = (int)$parts[0];
    $jMonth = (int)$parts[1];
    $jDay   = (int)$parts[2];
    if ($jMonth < 1 || $jMonth > 12 || $jDay < 1) return false;

    $jDaysInMonth = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    if ((($jYear + 1) % 4 == 0 && ($jYear + 1) % 100 != 0) || ($jYear + 1) % 400 == 0) {
        $jDaysInMonth[11] = 30;
    }
    if ($jDay > $jDaysInMonth[$jMonth - 1]) return false;

    $days = 0;
    for ($i = 0; $i < $jMonth - 1; $i++) {
        $days += $jDaysInMonth[$i];
    }
    $days += $jDay;

    $gYear = $jYear + 621;
    $gregorianDays = $days + 79;
    if (($gYear % 4 == 0 && $gYear % 100 != 0) || $gYear % 400 == 0) {
        if ($gregorianDays > 366) {
            $gregorianDays -= 366;
            $gYear++;
        }
    } else {
        if ($gregorianDays > 365) {
            $gregorianDays -= 365;
            $gYear++;
        }
    }

    $gMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (($gYear % 4 == 0 && $gYear % 100 != 0) || $gYear % 400 == 0) {
        $gMonths[1] = 29;
    }
    $gMonth = 0;
    while ($gregorianDays > $gMonths[$gMonth]) {
        $gregorianDays -= $gMonths[$gMonth];
        $gMonth++;
    }
    $gMonth++;
    $gDay = $gregorianDays;
    return $gYear . '-' . str_pad($gMonth, 2, '0', STR_PAD_LEFT) . '-' . str_pad($gDay, 2, '0', STR_PAD_LEFT);
}
require_once __DIR__ . '/helpers.php';
?>