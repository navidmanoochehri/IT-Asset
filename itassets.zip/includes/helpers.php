<?php
function getFirstAssetCode($data) {
    $codeFields = ['case_code','monitor_code','keyboard_code','mouse_serial','phone_code','printer_code','scanner_code','laptop_code'];
    foreach ($codeFields as $f) {
        if (!empty($data[$f]) && trim($data[$f]) !== '') return trim($data[$f]);
    }
    return '';
}