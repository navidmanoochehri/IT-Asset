<?php
// توابع کمکی - برای اکسل نیاز به کتابخانه دارید
function exportToExcel($data,$headers,$filename){ die("کتابخانه PhpSpreadsheet نصب نیست."); }
