<?php
define('MASTER_DB_HOST', 'localhost');
define('MASTER_DB_NAME', 'asset_master');
define('MASTER_DB_USER', 'root');
define('MASTER_DB_PASS', '123456');   // ← رمز صحیح

try {
    $master_pdo = new PDO("mysql:host=".MASTER_DB_HOST.";dbname=".MASTER_DB_NAME.";charset=utf8mb4", MASTER_DB_USER, MASTER_DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("اتصال به دیتابیس مرکزی برقرار نشد. " . $e->getMessage());
}
?>