<?php
require_once 'includes/master_config.php';

$newPassword = '123456';
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

$stmt = $master_pdo->prepare("UPDATE admin_users SET password = ? WHERE username = 'admin'");
$stmt->execute([$hashedPassword]);

echo "✅ رمز عبور کاربر admin با موفقیت به <b>123456</b> بازنشانی شد. حالا می‌توانید وارد شوید.";
echo "<br><b>اکنون این فایل را حذف کنید.</b>";
?>