<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // اعتبارسنجی نام و نام خانوادگی
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');

    if ($first_name === '' || $last_name === '') {
        $msg = '<div class="alert alert-danger text-center">❌ نام و نام خانوادگی الزامی هستند.</div>';
    } else {
        try {
            $pdo->beginTransaction();

            // درج فرد
            $stmt = $pdo->prepare("INSERT INTO persons (personnel_code, first_name, last_name, username, unit, location) VALUES (?,?,?,?,?,?)");
            $stmt->execute([
                $_POST['personnel_code'] ?? null,
                $first_name,
                $last_name,
                $_POST['username'] ?? null,
                $_POST['unit'] ?? null,
                $_POST['location'] ?? null
            ]);
            $person_id = $pdo->lastInsertId();

            // درج تجهیزات
            $invSql = "INSERT INTO inventory (person_id, case_name, case_code, monitor_name, monitor_code, keyboard_name, keyboard_code,
                    mouse_name, mouse_serial, phone_name, phone_code, headset_name, webcam_name, webcam_serial,
                    printer_name, printer_code, scanner_name, scanner_code, laptop_name, laptop_code,
                    dvd_rw, motherboard, cpu, graphics, ram, ssd_nvme, hdd, os, other, description)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $invStmt = $pdo->prepare($invSql);
            $invStmt->execute([
                $person_id,
                $_POST['case_name'] ?? '', $_POST['case_code'] ?? '',
                $_POST['monitor_name'] ?? '', $_POST['monitor_code'] ?? '',
                $_POST['keyboard_name'] ?? '', $_POST['keyboard_code'] ?? '',
                $_POST['mouse_name'] ?? '', $_POST['mouse_serial'] ?? '',
                $_POST['phone_name'] ?? '', $_POST['phone_code'] ?? '',
                $_POST['headset_name'] ?? '',
                $_POST['webcam_name'] ?? '', $_POST['webcam_serial'] ?? '',
                $_POST['printer_name'] ?? '', $_POST['printer_code'] ?? '',
                $_POST['scanner_name'] ?? '', $_POST['scanner_code'] ?? '',
                $_POST['laptop_name'] ?? '', $_POST['laptop_code'] ?? '',
                $_POST['dvd_rw'] ?? '', $_POST['motherboard'] ?? '', $_POST['cpu'] ?? '',
                $_POST['graphics'] ?? '', $_POST['ram'] ?? '', $_POST['ssd_nvme'] ?? '',
                $_POST['hdd'] ?? '', $_POST['os'] ?? '', $_POST['other'] ?? '', $_POST['description'] ?? ''
            ]);

            $pdo->commit();

            // لاگ با کد صحیح
            $firstCode = getFirstAssetCode($_POST);
            logChange($pdo, $person_id, 'create', 'ایجاد اولیه فرد و کلیه تجهیزات', $firstCode);

            $msg = '<div class="alert alert-success text-center">✅ فرد و تجهیزات با موفقیت ثبت شدند.</div>';

            // پاک‌سازی فرم (اختیاری؛ در صورت نیاز می‌توان ریدایرکت کرد)
            // $_POST = [];
        } catch (Exception $e) {
            $pdo->rollBack();
            $msg = '<div class="alert alert-danger">❌ خطا در ثبت اطلاعات: ' . $e->getMessage() . '</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت اولیه</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', Tahoma, sans-serif; position: relative; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%, 100% { transform: translate(0,0) scale(1); } 33% { transform: translate(40px,-40px) scale(1.05); } 66% { transform: translate(-30px,30px) scale(0.95); } }

        .navbar-dash {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .section-card {
            background: #fff;
            border: 1px solid rgba(0,0,0,0.05);
            border-radius: 20px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .section-header {
            padding: 14px 20px;
            background: linear-gradient(135deg, #4e73df, #2a5298);
            color: white;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        .section-body { padding: 20px; }
        .btn-submit {
            background: linear-gradient(135deg, #4e73df, #2a5298);
            border: none;
            color: white;
            padding: 12px 40px;
            border-radius: 50px;
            font-size: 1.1rem;
        }
        .btn-submit:hover { background: linear-gradient(135deg, #2a5298, #4e73df); }
        .required-star {
            color: red;
            font-weight: bold;
            margin-left: 2px;
        }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>

<nav class="navbar-dash">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="../dashboard.php" class="btn btn-primary btn-sm">
            <img src="../images/icons/home.png" width="18" height="18" style="margin-left:5px;"> داشبورد
        </a>
        <a href="../import.php" class="btn btn-success btn-sm">
            <img src="../images/icons/upload.png" width="18" height="18" style="margin-left:5px;"> واردات از اکسل
        </a>
    </div>
</nav>

<div class="container py-4" style="position: relative; z-index: 1;">
    <?= $msg ?>
    <h2 class="text-center mb-4">ثبت اولیه فرد و تجهیزات</h2>
    <form method="post">
        <!-- اطلاعات پرسنلی -->
        <div class="section-card">
            <div class="section-header"><img src="../images/icons/person.png" width="24" style="margin-left:8px;"> اطلاعات پرسنلی</div>
            <div class="section-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">کد پرسنلی</label>
                        <input name="personnel_code" class="form-control" placeholder="اختیاری">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">نام <span class="required-star">*</span></label>
                        <input name="first_name" class="form-control" required placeholder="الزامی">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">نام خانوادگی <span class="required-star">*</span></label>
                        <input name="last_name" class="form-control" required placeholder="الزامی">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">نام کاربری</label>
                        <input name="username" class="form-control" placeholder="اختیاری">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">واحد سازمانی</label>
                        <input name="unit" class="form-control" placeholder="مثلاً انفورماتیک">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">محل استقرار</label>
                        <input name="location" class="form-control" placeholder="مثلاً طبقه سوم">
                    </div>
                </div>
            </div>
        </div>

        <?php
        $sections = [
            ['case', 'کیس', ['case_name'=>'نام/مدل', 'case_code'=>'کد اموال']],
            ['monitor', 'مانیتور', ['monitor_name'=>'مدل', 'monitor_code'=>'کد اموال']],
            ['keyboard', 'کیبورد', ['keyboard_name'=>'مدل', 'keyboard_code'=>'کد اموال']],
            ['mouse', 'ماوس', ['mouse_name'=>'مدل', 'mouse_serial'=>'سریال']],
            ['phone', 'تلفن', ['phone_name'=>'مدل', 'phone_code'=>'کد اموال']],
            ['headset', 'هدست', ['headset_name'=>'مدل']],
            ['webcam', 'وبکم', ['webcam_name'=>'مدل', 'webcam_serial'=>'سریال']],
            ['printer', 'پرینتر', ['printer_name'=>'مدل', 'printer_code'=>'کد اموال']],
            ['scanner', 'اسکنر', ['scanner_name'=>'مدل', 'scanner_code'=>'کد اموال']],
            ['laptop', 'لپ‌تاپ', ['laptop_name'=>'مدل', 'laptop_code'=>'کد اموال']],
            ['tech', 'مشخصات فنی', ['motherboard'=>'مادربورد','cpu'=>'پردازنده','graphics'=>'گرافیک','ram'=>'RAM','ssd_nvme'=>'SSD/NVMe','hdd'=>'HDD','dvd_rw'=>'DVD RW','os'=>'سیستم‌عامل']],
        ];
        foreach ($sections as $sec):
            $key = $sec[0]; $title = $sec[1]; $fields = $sec[2];
        ?>
        <div class="section-card">
            <div class="section-header"><img src="../images/icons/<?=$key?>.png" width="24" style="margin-left:8px;"> <?=$title?></div>
            <div class="section-body">
                <div class="row g-3">
                    <?php foreach ($fields as $field => $label): ?>
                        <div class="<?= count($fields)>2 ? 'col-md-4' : 'col-md-6' ?>">
                            <label class="form-label"><?=$label?></label>
                            <?php if (in_array($field, ['monitor_name','monitor_code'])): ?>
                                <textarea name="<?=$field?>" class="form-control" rows="2" placeholder=""></textarea>
                            <?php else: ?>
                                <input name="<?=$field?>" class="form-control" placeholder="">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <!-- سایر و توضیحات -->
        <div class="section-card">
            <div class="section-header"><img src="../images/icons/other.png" width="24" style="margin-left:8px;"> سایر و توضیحات</div>
            <div class="section-body">
                <div class="row g-3">
                    <div class="col-12"><label class="form-label">سایر</label><textarea name="other" class="form-control" rows="2" placeholder="تجهیزات جانبی دیگر"></textarea></div>
                    <div class="col-12"><label class="form-label">توضیحات</label><textarea name="description" class="form-control" rows="2" placeholder="یادداشت‌های اضافی"></textarea></div>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <button type="submit" class="btn btn-submit btn-lg shadow">ثبت نهایی</button>
        </div>
    </form>
</div>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>