<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$person_id = $_GET['id'] ?? 0;
if (!$person_id) die('شناسه فرد نامشخص است.');

$stmt = $pdo->prepare("SELECT * FROM persons WHERE id = ?");
$stmt->execute([$person_id]);
$person = $stmt->fetch();
if (!$person) die('فرد یافت نشد.');

$stmt = $pdo->prepare("SELECT * FROM inventory WHERE person_id = ?");
$stmt->execute([$person_id]);
$inventory = $stmt->fetch();

function inventoryToWarehouseItems($inventory, $personId, $pdo, $descPrefix = 'غیرفعال‌سازی') {
    $items = [];
    $fieldMappings = [
        ['name' => 'case_name',    'code' => 'case_code',    'serial' => null,          'category' => 'کیس'],
        ['name' => 'monitor_name', 'code' => 'monitor_code', 'serial' => null,          'category' => 'مانیتور'],
        ['name' => 'keyboard_name','code' => 'keyboard_code','serial' => null,          'category' => 'کیبورد'],
        ['name' => 'mouse_name',   'code' => null,           'serial' => 'mouse_serial','category' => 'ماوس'],
        ['name' => 'phone_name',   'code' => 'phone_code',   'serial' => null,          'category' => 'تلفن'],
        ['name' => 'headset_name', 'code' => null,           'serial' => null,          'category' => 'هدست'],
        ['name' => 'webcam_name',  'code' => null,           'serial' => 'webcam_serial','category' => 'وبکم'],
        ['name' => 'printer_name', 'code' => 'printer_code', 'serial' => null,          'category' => 'پرینتر'],
        ['name' => 'scanner_name', 'code' => 'scanner_code', 'serial' => null,          'category' => 'اسکنر'],
        ['name' => 'laptop_name',  'code' => 'laptop_code',  'serial' => null,          'category' => 'لپتاپ'],
        ['name' => 'dvd_rw',       'code' => null,           'serial' => null,          'category' => 'DVD RW'],
        ['name' => 'motherboard',  'code' => null,           'serial' => null,          'category' => 'مادربورد'],
        ['name' => 'cpu',          'code' => null,           'serial' => null,          'category' => 'پردازنده'],
        ['name' => 'graphics',     'code' => null,           'serial' => null,          'category' => 'گرافیک'],
        ['name' => 'ram',          'code' => null,           'serial' => null,          'category' => 'رم'],
        ['name' => 'ssd_nvme',     'code' => null,           'serial' => null,          'category' => 'SSD/NVMe'],
        ['name' => 'hdd',          'code' => null,           'serial' => null,          'category' => 'HDD'],
        ['name' => 'os',           'code' => null,           'serial' => null,          'category' => 'سیستم‌عامل'],
        ['name' => 'other',        'code' => null,           'serial' => null,          'category' => 'سایر'],
    ];

    foreach ($fieldMappings as $map) {
        $nameField   = $map['name'];
        $codeField   = $map['code'];
        $serialField = $map['serial'];
        $category    = $map['category'];

        $rawName = $inventory[$nameField] ?? '';
        if (trim($rawName) === '') continue;

        $names = explode("\n", $rawName);
        $codes = [];
        if ($codeField && !empty($inventory[$codeField])) $codes = explode("\n", $inventory[$codeField]);
        $serials = [];
        if ($serialField && !empty($inventory[$serialField])) $serials = explode("\n", $inventory[$serialField]);

        $max = count($names);
        for ($i = 0; $i < $max; $i++) {
            $itemName = trim($names[$i] ?? '');
            if ($itemName === '') continue;
            $itemCode = trim($codes[$i] ?? '');
            $itemSerial = trim($serials[$i] ?? '');
            $desc = "{$descPrefix} – از {$personId}";
            if ($personId) {
                $personName = $pdo->query("SELECT CONCAT(first_name,' ',last_name) FROM persons WHERE id = $personId")->fetchColumn();
                $desc = "{$descPrefix} – از {$personName} (کد: {$personId})";
            }
            $items[] = ['item_name' => $itemName, 'item_code' => $itemCode, 'category' => $category, 'serial_number' => $itemSerial, 'description' => $desc];
        }
    }
    return $items;
}

$pdo->beginTransaction();
try {
    $firstCode = getFirstAssetCode($inventory ?? []);
    if ($inventory) {
        $wareItems = inventoryToWarehouseItems($inventory, $person_id, $pdo, 'غیرفعال‌سازی');
        $insert = $pdo->prepare("INSERT INTO warehouse_items (item_name, item_code, category, serial_number, description, transferred_from_person_id, transferred_date)
            VALUES (?, ?, ?, ?, ?, ?, NOW())");
        foreach ($wareItems as $wi) $insert->execute([$wi['item_name'], $wi['item_code'], $wi['category'], $wi['serial_number'], $wi['description'], $person_id]);
        $pdo->prepare("DELETE FROM inventory WHERE person_id = ?")->execute([$person_id]);
    }
    $pdo->prepare("UPDATE persons SET is_active = 0 WHERE id = ?")->execute([$person_id]);
    $logMsg = "غیرفعال‌سازی کاربر {$person['first_name']} {$person['last_name']} (کد: {$person['personnel_code']}) – تجهیزات به انبار منتقل شدند";
    logChange($pdo, $person_id, 'update', $logMsg, $firstCode);
    $pdo->commit();
    header('Location: ../search_edit.php?msg=deactivated');
    exit;
} catch (Exception $e) { $pdo->rollBack(); die('خطا: ' . $e->getMessage()); }