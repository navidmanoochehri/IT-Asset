<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$person_id = $_GET['id'] ?? 0;
if (!$person_id) die('شناسه فرد نامشخص است.');

$stmt = $pdo->prepare("SELECT * FROM persons WHERE id = ? AND is_active = 0 AND is_deleted = 0");
$stmt->execute([$person_id]);
$person = $stmt->fetch();
if (!$person) die('فرد یافت نشد یا امکان فعال‌سازی ندارد.');

$pdo->beginTransaction();
try {
    $wareItems = $pdo->prepare("SELECT * FROM warehouse_items WHERE transferred_from_person_id = ?");
    $wareItems->execute([$person_id]);
    $items = $wareItems->fetchAll();

    $firstCode = '';
    if ($items) {
        $categoryMapping = [
            'کیس'        => ['name' => 'case_name',    'code' => 'case_code',    'serial' => null],
            'مانیتور'     => ['name' => 'monitor_name', 'code' => 'monitor_code', 'serial' => null],
            'کیبورد'      => ['name' => 'keyboard_name','code' => 'keyboard_code','serial' => null],
            'ماوس'       => ['name' => 'mouse_name',   'code' => null,           'serial' => 'mouse_serial'],
            'تلفن'       => ['name' => 'phone_name',   'code' => 'phone_code',   'serial' => null],
            'هدست'       => ['name' => 'headset_name', 'code' => null,           'serial' => null],
            'وبکم'       => ['name' => 'webcam_name',  'code' => null,           'serial' => 'webcam_serial'],
            'پرینتر'     => ['name' => 'printer_name', 'code' => 'printer_code', 'serial' => null],
            'اسکنر'      => ['name' => 'scanner_name', 'code' => 'scanner_code', 'serial' => null],
            'لپتاپ'      => ['name' => 'laptop_name',  'code' => 'laptop_code',  'serial' => null],
            'DVD RW'     => ['name' => 'dvd_rw',       'code' => null,           'serial' => null],
            'مادربورد'    => ['name' => 'motherboard',  'code' => null,           'serial' => null],
            'پردازنده'    => ['name' => 'cpu',          'code' => null,           'serial' => null],
            'گرافیک'     => ['name' => 'graphics',     'code' => null,           'serial' => null],
            'رم'         => ['name' => 'ram',          'code' => null,           'serial' => null],
            'SSD/NVMe'   => ['name' => 'ssd_nvme',     'code' => null,           'serial' => null],
            'HDD'        => ['name' => 'hdd',          'code' => null,           'serial' => null],
            'سیستم‌عامل'  => ['name' => 'os',           'code' => null,           'serial' => null],
            'سایر'       => ['name' => 'other',        'code' => null,           'serial' => null],
        ];

        $invData = [];
        foreach ($items as $item) {
            $cat = $item['category'];
            if (!isset($categoryMapping[$cat])) continue;
            $map = $categoryMapping[$cat];
            if ($map['name'])   $invData[$map['name']]   = trim(($invData[$map['name']]   ?? '') . "\n" . $item['item_name']);
            if ($map['code'])   $invData[$map['code']]   = trim(($invData[$map['code']]   ?? '') . "\n" . $item['item_code']);
            if ($map['serial']) $invData[$map['serial']] = trim(($invData[$map['serial']] ?? '') . "\n" . $item['serial_number']);
        }

        $inv = $pdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
        $inv->execute([$person_id]);
        $invExists = $inv->fetch();

        if ($invExists) {
            $sets = []; $params = [];
            foreach ($invData as $col => $val) { $sets[] = "$col = CONCAT(COALESCE($col,''), ?, '\n')"; $params[] = $val; }
            if (!empty($sets)) { $params[] = $person_id; $pdo->prepare("UPDATE inventory SET " . implode(',', $sets) . " WHERE person_id = ?")->execute($params); }
        } else {
            $cols = array_keys($invData);
            $vals = array_values($invData);
            $placeholders = rtrim(str_repeat('?,', count($cols)), ',');
            $sql = "INSERT INTO inventory (person_id, " . implode(',', $cols) . ") VALUES (?, $placeholders)";
            array_unshift($vals, $person_id);
            $pdo->prepare($sql)->execute($vals);
        }

        $pdo->prepare("DELETE FROM warehouse_items WHERE transferred_from_person_id = ?")->execute([$person_id]);
        $firstCode = $items[0]['item_code'] ?? '';
    }

    $pdo->prepare("UPDATE persons SET is_active = 1 WHERE id = ?")->execute([$person_id]);

    $logMsg = "فعال‌سازی مجدد کاربر {$person['first_name']} {$person['last_name']} (کد: {$person['personnel_code']}) – تجهیزات از انبار بازگردانده شدند";
    logChange($pdo, $person_id, 'update', $logMsg, $firstCode);

    $pdo->commit();
    header('Location: ../search_edit.php?msg=activated');
    exit;
} catch (Exception $e) { $pdo->rollBack(); die('خطا: ' . $e->getMessage()); }