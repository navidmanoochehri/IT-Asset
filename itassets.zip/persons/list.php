<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$msg = '';
if (isset($_GET['msg']) && $_GET['msg'] == 'deactivated') {
    $msg = '<div class="alert alert-success">فرد غیرفعال و تجهیزات به انبار منتقل شد.</div>';
}

// دریافت افراد فعال
$stmt = $pdo->query("SELECT * FROM persons WHERE is_active = 1 ORDER BY last_name ASC");
$persons = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لیست پرسنل فعال</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/bootstrap-icons.css">
    <style>
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .card-header { background: #0d6efd; color: white; border-radius: 15px 15px 0 0!important; }
    </style>
</head>
<body class="bg-light p-3">
<div class="container">
    <a href="../dashboard.php" class="btn btn-secondary mb-3"><i class="bi bi-house"></i> داشبورد</a>
    <?= $msg ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h4 class="mb-0">پرسنل فعال</h4>
            <a href="add_person.php" class="btn btn-light btn-sm"><i class="bi bi-person-plus"></i> افزودن فرد</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>کد</th>
                            <th>نام</th>
                            <th>واحد</th>
                            <th>محل</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($persons as $p): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['personnel_code'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name']) ?></td>
                                <td><?= htmlspecialchars($p['unit'] ?? '') ?></td>
                                <td><?= htmlspecialchars($p['location'] ?? '') ?></td>
                                <td>
                                    <a href="edit_person.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></a>
                                    <a href="deactivate_person.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('آیا از غیرفعال‌سازی این فرد و انتقال تجهیزات به انبار مطمئن هستید؟')"><i class="bi bi-box-arrow-in-down"></i> انتقال به انبار</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($persons)): ?>
                            <tr><td colspan="5" class="text-center text-muted">هیچ فرد فعالی یافت نشد.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>