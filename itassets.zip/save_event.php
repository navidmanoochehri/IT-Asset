<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$personId    = $_POST['person_id'] ?? 0;
$inventoryId = $_POST['inventory_id'] ?? 0;
$fieldName   = $_POST['field_name'] ?? '';
$eventType   = $_POST['event_type'] ?? '';
$oldValue    = $_POST['old_value'] ?? '';
$newValue    = $_POST['new_value'] ?? '';
$description = $_POST['description'] ?? '';

if (!$personId || !$inventoryId || !$fieldName || !$eventType) {
    echo json_encode(['success' => false, 'message' => 'اطلاعات ناقص']);
    exit;
}

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare("INSERT INTO asset_events (person_id, inventory_id, event_type, field_name, old_value, new_value, description, created_by) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->execute([$personId, $inventoryId, $eventType, $fieldName, $oldValue, $newValue, $description, $_SESSION['admin_name'] ?? 'سیستم']);

    if (in_array($eventType, ['replace','upgrade','replace_defective']) && !empty($newValue)) {
        $pdo->prepare("UPDATE inventory SET `$fieldName` = ? WHERE id = ? AND person_id = ?")->execute([$newValue, $inventoryId, $personId]);
    }

    $stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ?");
    $stmt->execute([$inventoryId]);
    $inv = $stmt->fetch();
    $assetCode = getFirstAssetCode($inv ?? []);

    logChange($pdo, $personId, 'update', "رخداد: {$eventType} برای {$fieldName}", $assetCode);

    $pdo->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) { $pdo->rollBack(); echo json_encode(['success' => false, 'message' => $e->getMessage()]); }