<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$person_id = $_GET['person_id'] ?? 0;
if (!$person_id) {
    header('Location: inventory.php');
    exit;
}

// دریافت اطلاعات فرد
$stmt = $pdo->prepare("SELECT * FROM persons WHERE id = ?");
$stmt->execute([$person_id]);
$person = $stmt->fetch();
if (!$person) die('فرد یافت نشد.');

// دریافت یا ایجاد رکورد inventory
$stmt = $pdo->prepare("SELECT * FROM inventory WHERE person_id = ?");
$stmt->execute([$person_id]);
$inv = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($inv) {
        // بروزرسانی
        $sql = "UPDATE inventory SET 
            case_name=?, case_code=?, monitor_name=?, monitor_code=?, keyboard_name=?, keyboard_code=?,
            mouse_name=?, mouse_serial=?, phone_name=?, phone_code=?, headset_name=?, webcam_name=?, webcam_serial=?,
            printer_name=?, printer_code=?, scanner_name=?, scanner_code=?, laptop_name=?, laptop_code=?,
            dvd_rw=?, motherboard=?, cpu=?, graphics=?, ram=?, ssd_nvme=?, hdd=?, os=?, other=?, description=?
            WHERE person_id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $_POST['case_name'], $_POST['case_code'], $_POST['monitor_name'], $_POST['monitor_code'],
            $_POST['keyboard_name'], $_POST['keyboard_code'], $_POST['mouse_name'], $_POST['mouse_serial'],
            $_POST['phone_name'], $_POST['phone_code'], $_POST['headset_name'], $_POST['webcam_name'], $_POST['webcam_serial'],
            $_POST['printer_name'], $_POST['printer_code'], $_POST['scanner_name'], $_POST['scanner_code'],
            $_POST['laptop_name'], $_POST['laptop_code'],
            $_POST['dvd_rw'], $_POST['motherboard'], $_POST['cpu'], $_POST['graphics'], $_POST['ram'],
            $_POST['ssd_nvme'], $_POST['hdd'], $_POST['os'], $_POST['other'], $_POST['description'],
            $person_id
        ]);
    } else {
        // ایجاد
        $sql = "INSERT INTO inventory (person_id, case_name, case_code, monitor_name, monitor_code, keyboard_name, keyboard_code,
            mouse_name, mouse_serial, phone_name, phone_code, headset_name, webcam_name, webcam_serial,
            printer_name, printer_code, scanner_name, scanner_code, laptop_name, laptop_code,
            dvd_rw, motherboard, cpu, graphics, ram, ssd_nvme, hdd, os, other, description)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $person_id, $_POST['case_name'], $_POST['case_code'], $_POST['monitor_name'], $_POST['monitor_code'],
            $_POST['keyboard_name'], $_POST['keyboard_code'], $_POST['mouse_name'], $_POST['mouse_serial'],
            $_POST['phone_name'], $_POST['phone_code'], $_POST['headset_name'], $_POST['webcam_name'], $_POST['webcam_serial'],
            $_POST['printer_name'], $_POST['printer_code'], $_POST['scanner_name'], $_POST['scanner_code'],
            $_POST['laptop_name'], $_POST['laptop_code'],
            $_POST['dvd_rw'], $_POST['motherboard'], $_POST['cpu'], $_POST['graphics'], $_POST['ram'],
            $_POST['ssd_nvme'], $_POST['hdd'], $_POST['os'], $_POST['other'], $_POST['description']
        ]);
    }
    header('Location: inventory.php?msg=success');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ویرایش تجهیزات</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/bootstrap-icons.css">
    <style>
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-top: 20px; }
        .card-header { background: #ffc107; border-radius: 15px 15px 0 0!important; }
    </style>
</head>
<body class="bg-light">
<div class="container py-4">
    <a href="inventory.php" class="btn btn-secondary mb-3">بازگشت</a>
    <div class="card">
        <div class="card-header">
            <h4>ویرایش تجهیزات: <?= htmlspecialchars($person['first_name'] . ' ' . $person['last_name']) ?></h4>
        </div>
        <div class="card-body">
            <form method="post">
                <!-- بخش کیس -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">کیس</legend>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">نام کیس</label><input name="case_name" class="form-control" value="<?= htmlspecialchars($inv['case_name'] ?? '') ?>"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">کد اموال</label><input name="case_code" class="form-control" value="<?= htmlspecialchars($inv['case_code'] ?? '') ?>"></div>
                    </div>
                </fieldset>

                <!-- بخش مانیتور -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">مانیتور</legend>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">مدل مانیتور</label><textarea name="monitor_name" class="form-control" rows="2"><?= htmlspecialchars($inv['monitor_name'] ?? '') ?></textarea></div>
                        <div class="col-md-6 mb-3"><label class="form-label">کد اموال</label><textarea name="monitor_code" class="form-control" rows="2"><?= htmlspecialchars($inv['monitor_code'] ?? '') ?></textarea></div>
                    </div>
                </fieldset>

                <!-- کیبورد و ماوس -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">کیبورد (مدل)</label><input name="keyboard_name" class="form-control" value="<?= htmlspecialchars($inv['keyboard_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال کیبورد</label><input name="keyboard_code" class="form-control" value="<?= htmlspecialchars($inv['keyboard_code'] ?? '') ?>"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">ماوس (مدل)</label><input name="mouse_name" class="form-control" value="<?= htmlspecialchars($inv['mouse_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">سریال ماوس</label><input name="mouse_serial" class="form-control" value="<?= htmlspecialchars($inv['mouse_serial'] ?? '') ?>"></div>
                </div>

                <!-- تلفن و هدست -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">تلفن (مدل)</label><input name="phone_name" class="form-control" value="<?= htmlspecialchars($inv['phone_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال تلفن</label><input name="phone_code" class="form-control" value="<?= htmlspecialchars($inv['phone_code'] ?? '') ?>"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">هدست</label><input name="headset_name" class="form-control" value="<?= htmlspecialchars($inv['headset_name'] ?? '') ?>"></div>
                </div>

                <!-- وبکم -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">وبکم (مدل)</label><input name="webcam_name" class="form-control" value="<?= htmlspecialchars($inv['webcam_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">سریال وبکم</label><input name="webcam_serial" class="form-control" value="<?= htmlspecialchars($inv['webcam_serial'] ?? '') ?>"></div>
                </div>

                <!-- پرینتر و اسکنر -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">پرینتر</label><input name="printer_name" class="form-control" value="<?= htmlspecialchars($inv['printer_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال پرینتر</label><input name="printer_code" class="form-control" value="<?= htmlspecialchars($inv['printer_code'] ?? '') ?>"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">اسکنر</label><input name="scanner_name" class="form-control" value="<?= htmlspecialchars($inv['scanner_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال اسکنر</label><input name="scanner_code" class="form-control" value="<?= htmlspecialchars($inv['scanner_code'] ?? '') ?>"></div>
                </div>

                <!-- لپ‌تاپ -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">لپ‌تاپ</label><input name="laptop_name" class="form-control" value="<?= htmlspecialchars($inv['laptop_name'] ?? '') ?>"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال لپ‌تاپ</label><input name="laptop_code" class="form-control" value="<?= htmlspecialchars($inv['laptop_code'] ?? '') ?>"></div>
                </div>

                <!-- مشخصات فنی کامپیوتر -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">مشخصات فنی</legend>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">مادربورد</label><input name="motherboard" class="form-control" value="<?= htmlspecialchars($inv['motherboard'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">پردازنده</label><input name="cpu" class="form-control" value="<?= htmlspecialchars($inv['cpu'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">گرافیک</label><input name="graphics" class="form-control" value="<?= htmlspecialchars($inv['graphics'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">RAM</label><input name="ram" class="form-control" value="<?= htmlspecialchars($inv['ram'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">SSD / NVMe</label><input name="ssd_nvme" class="form-control" value="<?= htmlspecialchars($inv['ssd_nvme'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">HDD</label><input name="hdd" class="form-control" value="<?= htmlspecialchars($inv['hdd'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">DVD RW</label><input name="dvd_rw" class="form-control" value="<?= htmlspecialchars($inv['dvd_rw'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">سیستم عامل</label><input name="os" class="form-control" value="<?= htmlspecialchars($inv['os'] ?? '') ?>"></div>
                    </div>
                </fieldset>

                <!-- سایر و توضیحات -->
                <div class="row">
                    <div class="col-md-12 mb-3"><label class="form-label">سایر</label><textarea name="other" class="form-control" rows="2"><?= htmlspecialchars($inv['other'] ?? '') ?></textarea></div>
                    <div class="col-md-12 mb-3"><label class="form-label">توضیحات</label><textarea name="description" class="form-control" rows="2"><?= htmlspecialchars($inv['description'] ?? '') ?></textarea></div>
                </div>

                <button type="submit" class="btn btn-warning btn-lg">ذخیره تغییرات</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>