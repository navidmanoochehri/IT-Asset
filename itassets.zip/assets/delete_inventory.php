<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$person_id = $_GET['person_id'] ?? 0;

if ($person_id) {
    // دریافت یک کد اموال برای لاگ
    $stmt = $pdo->prepare("SELECT case_code, monitor_code FROM inventory WHERE person_id = ?");
    $stmt->execute([$person_id]);
    $inv = $stmt->fetch();
    $code = $inv['case_code'] ?? $inv['monitor_code'] ?? '';

    // ثبت لاگ حذف
    logChange($pdo, $person_id, 'delete', 'حذف کلیه تجهیزات فرد', $code);

    // حذف تجهیزات
    $pdo->prepare("DELETE FROM inventory WHERE person_id = ?")->execute([$person_id]);
}

header('Location: inventory.php?msg=deleted');
exit;