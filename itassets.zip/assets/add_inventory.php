<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

$persons = $pdo->query("SELECT id, personnel_code, first_name, last_name FROM persons ORDER BY last_name")->fetchAll();
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $person_id = $_POST['person_id'] ?? 0;
    if ($person_id) {
        // بررسی اینکه قبلاً رکوردی دارد یا نه
        $check = $pdo->prepare("SELECT id FROM inventory WHERE person_id = ?");
        $check->execute([$person_id]);
        if ($check->fetch()) {
            $msg = '<div class="alert alert-warning">این فرد قبلاً تجهیزات دارد. برای ویرایش به لیست بروید.</div>';
        } else {
            $sql = "INSERT INTO inventory (person_id, case_name, case_code, monitor_name, monitor_code, keyboard_name, keyboard_code,
                mouse_name, mouse_serial, phone_name, phone_code, headset_name, webcam_name, webcam_serial,
                printer_name, printer_code, scanner_name, scanner_code, laptop_name, laptop_code,
                dvd_rw, motherboard, cpu, graphics, ram, ssd_nvme, hdd, os, other, description)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $person_id, $_POST['case_name'], $_POST['case_code'], $_POST['monitor_name'], $_POST['monitor_code'],
                $_POST['keyboard_name'], $_POST['keyboard_code'], $_POST['mouse_name'], $_POST['mouse_serial'],
                $_POST['phone_name'], $_POST['phone_code'], $_POST['headset_name'], $_POST['webcam_name'], $_POST['webcam_serial'],
                $_POST['printer_name'], $_POST['printer_code'], $_POST['scanner_name'], $_POST['scanner_code'],
                $_POST['laptop_name'], $_POST['laptop_code'],
                $_POST['dvd_rw'], $_POST['motherboard'], $_POST['cpu'], $_POST['graphics'], $_POST['ram'],
                $_POST['ssd_nvme'], $_POST['hdd'], $_POST['os'], $_POST['other'], $_POST['description']
            ]);
            header('Location: inventory.php?msg=created');
            exit;
        }
    } else {
        $msg = '<div class="alert alert-danger">لطفاً یک فرد را انتخاب کنید.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>افزودن تجهیزات</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/bootstrap-icons.css">
    <style>
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-top: 20px; }
        .card-header { background: #198754; color: white; border-radius: 15px 15px 0 0!important; }
        legend { font-weight: bold; }
    </style>
</head>
<body class="bg-light">
<div class="container py-4">
    <a href="inventory.php" class="btn btn-secondary mb-3"><i class="bi bi-arrow-right"></i> بازگشت</a>
    <?= $msg ?>
    <div class="card">
        <div class="card-header"><h4>افزودن تجهیزات جدید برای یک فرد</h4></div>
        <div class="card-body">
            <form method="post">
                <!-- انتخاب فرد -->
                <div class="mb-3">
                    <label class="form-label">فرد</label>
                    <select name="person_id" class="form-select" required>
                        <option value="">-- انتخاب کنید --</option>
                        <?php foreach ($persons as $p): ?>
                            <option value="<?= $p['id'] ?>">
                                <?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name'] . ' ( ' . $p['personnel_code'] . ')') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- کیس -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">کیس</legend>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">نام کیس</label><input name="case_name" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">کد اموال</label><input name="case_code" class="form-control"></div>
                    </div>
                </fieldset>

                <!-- مانیتور -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">مانیتور</legend>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">مدل</label><textarea name="monitor_name" class="form-control" rows="2"></textarea></div>
                        <div class="col-md-6 mb-3"><label class="form-label">کد اموال</label><textarea name="monitor_code" class="form-control" rows="2"></textarea></div>
                    </div>
                </fieldset>

                <!-- کیبورد و ماوس -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">کیبورد</label><input name="keyboard_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال کیبورد</label><input name="keyboard_code" class="form-control"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">ماوس</label><input name="mouse_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">سریال ماوس</label><input name="mouse_serial" class="form-control"></div>
                </div>

                <!-- تلفن و هدست -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">تلفن</label><input name="phone_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال تلفن</label><input name="phone_code" class="form-control"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">هدست</label><input name="headset_name" class="form-control"></div>
                </div>

                <!-- وبکم -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">وبکم</label><input name="webcam_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">سریال وبکم</label><input name="webcam_serial" class="form-control"></div>
                </div>

                <!-- پرینتر و اسکنر -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">پرینتر</label><input name="printer_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال پرینتر</label><input name="printer_code" class="form-control"></div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">اسکنر</label><input name="scanner_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال اسکنر</label><input name="scanner_code" class="form-control"></div>
                </div>

                <!-- لپ‌تاپ -->
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label">لپ‌تاپ</label><input name="laptop_name" class="form-control"></div>
                    <div class="col-md-6 mb-3"><label class="form-label">کد اموال لپ‌تاپ</label><input name="laptop_code" class="form-control"></div>
                </div>

                <!-- مشخصات فنی -->
                <fieldset class="border p-3 mb-3 rounded">
                    <legend class="w-auto px-2">مشخصات فنی</legend>
                    <div class="row">
                        <div class="col-md-4 mb-3"><label class="form-label">مادربورد</label><input name="motherboard" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">پردازنده</label><input name="cpu" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">گرافیک</label><input name="graphics" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">RAM</label><input name="ram" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">SSD/NVMe</label><input name="ssd_nvme" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">HDD</label><input name="hdd" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">DVD RW</label><input name="dvd_rw" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label class="form-label">سیستم‌عامل</label><input name="os" class="form-control"></div>
                    </div>
                </fieldset>

                <!-- سایر و توضیحات -->
                <div class="row">
                    <div class="col-md-12 mb-3"><label class="form-label">سایر</label><textarea name="other" class="form-control" rows="2"></textarea></div>
                    <div class="col-md-12 mb-3"><label class="form-label">توضیحات</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>

                <button type="submit" class="btn btn-success btn-lg">ثبت تجهیزات</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>