<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';

// دریافت همه افراد به همراه اطلاعات تجهیزات (همه فیلدهای اصلی)
$stmt = $pdo->query("
    SELECT p.id AS person_id, p.personnel_code, p.first_name, p.last_name, p.unit, p.location,
           i.case_name, i.case_code,
           i.monitor_name, i.monitor_code,
           i.keyboard_name, i.keyboard_code,
           i.mouse_name, i.mouse_serial,
           i.phone_name, i.phone_code,
           i.headset_name,
           i.webcam_name, i.webcam_serial,
           i.printer_name, i.printer_code,
           i.scanner_name, i.scanner_code,
           i.laptop_name, i.laptop_code,
           i.motherboard, i.cpu, i.ram, i.graphics,
           i.ssd_nvme, i.hdd, i.os,
           i.other, i.description,
           i.updated_at
    FROM persons p
    LEFT JOIN inventory i ON p.id = i.person_id
    ORDER BY p.last_name ASC
");
$persons = $stmt->fetchAll();

// پیغام‌ها (در صورت ارسال از طریق URL)
$msg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'deleted') $msg = '<div class="alert alert-warning">تجهیزات فرد مورد نظر حذف شد.</div>';
    if ($_GET['msg'] === 'created') $msg = '<div class="alert alert-success">تجهیزات جدید با موفقیت ثبت شد.</div>';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>مدیریت تجهیزات پرسنل</title>
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../css/yekanbakh.css">
    <link rel="stylesheet" href="../css/bootstrap-icons.css">
    <style>
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .card-header { background: #198754; color: white; border-radius: 15px 15px 0 0!important; }
        .table td { vertical-align: middle; }
    </style>
</head>
<body class="bg-light p-3">
<div class="container-fluid">
    <a href="../dashboard.php" class="btn btn-secondary mb-3"><i class="bi bi-house"></i> داشبورد</a>
    <a href="../persons/add_person.php" class="btn btn-primary mb-3"><i class="bi bi-person-plus"></i> افزودن فرد جدید</a>
    <a href="add_inventory.php" class="btn btn-success mb-3"><i class="bi bi-plus-lg"></i> افزودن تجهیزات جدید</a>

    <?= $msg ?>

    <div class="card">
        <div class="card-header"><h4 class="mb-0">تجهیزات پرسنل</h4></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>کد پرسنلی</th>
                            <th>نام</th>
                            <th>واحد</th>
                            <th>کیس</th>
                            <th>مانیتور</th>
                            <th>کیبورد</th>
                            <th>ماوس</th>
                            <th>تلفن</th>
                            <th>هدست</th>
                            <th>وبکم</th>
                            <th>پرینتر</th>
                            <th>اسکنر</th>
                            <th>لپ‌تاپ</th>
                            <th>پردازنده</th>
                            <th>RAM</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($persons as $p): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['personnel_code'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['first_name'] . ' ' . $p['last_name']) ?></td>
                                <td><?= htmlspecialchars($p['unit'] ?? '') ?></td>
                                <td><?= htmlspecialchars($p['case_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars(mb_substr($p['monitor_name'] ?? '', 0, 30)) ?></td>
                                <td><?= htmlspecialchars($p['keyboard_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['mouse_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['phone_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['headset_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['webcam_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['printer_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['scanner_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['laptop_name'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['cpu'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['ram'] ?? '-') ?></td>
                                <td style="white-space: nowrap;">
                                    <a href="edit_inventory.php?person_id=<?= $p['person_id'] ?>" class="btn btn-sm btn-warning mb-1" title="ویرایش">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="delete_inventory.php?person_id=<?= $p['person_id'] ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('آیا از حذف تمام تجهیزات این فرد مطمئن هستید؟')"
                                       title="حذف تجهیزات">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($persons)): ?>
                            <tr><td colspan="16" class="text-center text-muted">هیچ رکوردی یافت نشد.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>