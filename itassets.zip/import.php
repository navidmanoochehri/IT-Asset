<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

$msg = '';

/**
 * خواندن فایل XLSX بدون کتابخانهٔ خارجی
 */
function readXLSX($filePath) {
    if (!class_exists('ZipArchive')) return false;
    $zip = new ZipArchive();
    if ($zip->open($filePath) !== true) return false;

    $sharedStrings = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml) {
        $xml = simplexml_load_string($ssXml);
        if ($xml) {
            foreach ($xml->si as $si) {
                $text = '';
                foreach ($si->t as $t) $text .= (string)$t;
                $sharedStrings[] = $text;
            }
        }
    }

    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if (!$sheetXml) { $zip->close(); return false; }

    $xml = simplexml_load_string($sheetXml);
    if (!$xml) { $zip->close(); return false; }

    $rows = [];
    $colToIndex = function($col) {
        $col = preg_replace('/[^A-Z]/', '', strtoupper($col));
        $index = 0;
        for ($i = 0; $i < strlen($col); $i++) {
            $index = $index * 26 + (ord($col[$i]) - 64);
        }
        return $index - 1;
    };

    foreach ($xml->sheetData->row as $row) {
        $cols = []; $maxCol = 0;
        foreach ($row->c as $cell) {
            $ref = (string)$cell['r'];
            $colIndex = $colToIndex($ref);
            $value = (string)$cell->v;
            $type = (string)$cell['t'];
            if ($type === 's' && isset($sharedStrings[(int)$value])) {
                $value = $sharedStrings[(int)$value];
            }
            $cols[$colIndex] = $value;
            if ($colIndex > $maxCol) $maxCol = $colIndex;
        }
        $fullRow = [];
        for ($i = 0; $i <= max($maxCol, 35); $i++) {
            $fullRow[] = $cols[$i] ?? '';
        }
        $rows[] = $fullRow;
    }
    $zip->close();
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file']['tmp_name'];
    $ext  = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    $rows = [];

    if ($ext === 'xlsx') {
        if (!class_exists('ZipArchive')) {
            $msg = '<div class="alert alert-danger">افزونه Zip در PHP فعال نیست.</div>';
        } else {
            $rows = readXLSX($file);
            if ($rows === false) {
                $msg = '<div class="alert alert-danger">فایل XLSX معتبر نیست.</div>';
            } else {
                array_shift($rows); // حذف هدر
            }
        }
    } else {
        $separator = $_POST['separator'] ?? ',';
        if ($separator === '\t' || $separator === 'tab') $separator = "\t";
        if ($separator === 'esc') $separator = chr(27);
        if (($handle = fopen($file, 'r')) !== false) {
            fgetcsv($handle, 0, $separator);
            while (($row = fgetcsv($handle, 0, $separator)) !== false) {
                $filtered = array_filter($row, fn($v) => trim((string)$v) !== '');
                if (!empty($filtered)) $rows[] = $row;
            }
            fclose($handle);
        }
    }

    if (!empty($rows)) {
        $imported = 0;
        $pdo->beginTransaction();
        try {
            foreach ($rows as $row) {
                if (count($row) < 36) continue;
                $first_name     = trim($row[1] ?? '');
                $last_name      = trim($row[2] ?? '');
                $personnel_code = trim($row[3] ?? '');
                $username       = trim($row[4] ?? '');
                $unit           = trim($row[5] ?? '');
                $location       = trim($row[6] ?? '');

                if (empty($first_name) && empty($last_name)) continue;

                if (!empty($personnel_code)) {
                    $check = $pdo->prepare("SELECT id FROM persons WHERE personnel_code = ?");
                    $check->execute([$personnel_code]);
                    if ($check->fetch()) continue;
                }

                $pCode = $personnel_code !== '' ? $personnel_code : null;
                $stmt = $pdo->prepare("INSERT INTO persons (personnel_code, first_name, last_name, username, unit, location) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$pCode, $first_name, $last_name, $username, $unit, $location]);
                $person_id = $pdo->lastInsertId();

                $invSql = "INSERT INTO inventory (person_id, case_name, case_code, monitor_name, monitor_code, keyboard_name, keyboard_code,
                    mouse_name, mouse_serial, phone_name, phone_code, headset_name, webcam_name, webcam_serial,
                    printer_name, printer_code, scanner_name, scanner_code, laptop_name, laptop_code,
                    dvd_rw, motherboard, cpu, graphics, ram, ssd_nvme, hdd, os, other, description)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $invStmt = $pdo->prepare($invSql);
                $invStmt->execute([
                    $person_id,
                    $row[7] ?? '', $row[8] ?? '', $row[9] ?? '', $row[10] ?? '',
                    $row[11] ?? '', $row[12] ?? '', $row[13] ?? '', $row[14] ?? '',
                    $row[15] ?? '', $row[16] ?? '', $row[17] ?? '',
                    $row[18] ?? '', $row[19] ?? '', $row[20] ?? '', $row[21] ?? '',
                    $row[22] ?? '', $row[23] ?? '', $row[24] ?? '', $row[25] ?? '',
                    $row[26] ?? '', $row[27] ?? '', $row[28] ?? '', $row[29] ?? '',
                    $row[30] ?? '', $row[31] ?? '', $row[32] ?? '', $row[33] ?? '',
                    $row[34] ?? '', $row[35] ?? ''
                ]);

                $firstCode = getFirstAssetCode($row);
                logChange($pdo, $person_id, 'create', 'واردات از فایل ' . strtoupper($ext), $firstCode);
                $imported++;
            }
            $pdo->commit();
            $msg = "<div class='alert alert-success'>✅ <b>$imported</b> رکورد با موفقیت وارد شد.</div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $msg = "<div class='alert alert-danger'>❌ خطا: " . $e->getMessage() . "</div>";
        }
    } elseif (empty($msg)) {
        $msg = '<div class="alert alert-warning">هیچ رکوردی در فایل یافت نشد.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>واردات اطلاعات</title>
    <link rel="stylesheet" href="css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="css/yekanbakh.css">
    <link rel="stylesheet" href="css/theme.css">
    <style>
        body { background: #eef2f7; font-family: 'YekanBakh', sans-serif; }
        .bg-animation { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; overflow: hidden; }
        .bg-animation .circle { position: absolute; border-radius: 50%; opacity: 0.04; animation: floatCircle 15s infinite ease-in-out; }
        .bg-animation .circle:nth-child(1) { width: 500px; height: 500px; background: #4e54c8; top: -150px; right: -100px; }
        .bg-animation .circle:nth-child(2) { width: 350px; height: 350px; background: #8f94fb; bottom: -100px; left: -80px; animation-delay: -5s; }
        .bg-animation .circle:nth-child(3) { width: 250px; height: 250px; background: #667eea; top: 50%; left: 10%; animation-delay: -10s; }
        @keyframes floatCircle { 0%,100%{transform: translate(0,0) scale(1);} 33%{transform: translate(40px,-40px) scale(1.05);} 66%{transform: translate(-30px,30px) scale(0.95);} }
        .navbar-dash { background: rgba(255,255,255,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 10px 0; position: sticky; top: 0; z-index: 100; }
        .card { background: #fff; border-radius: 20px; border: 1px solid rgba(0,0,0,0.05); }
    </style>
</head>
<body>
<div class="bg-animation"><div class="circle"></div><div class="circle"></div><div class="circle"></div></div>
<nav class="navbar-dash">
    <div class="container d-flex justify-content-between">
        <a href="dashboard.php" class="btn btn-primary btn-sm"><img src="images/icons/home.png" width="18"> داشبورد</a>
    </div>
</nav>
<div class="container py-4" style="position: relative; z-index: 1;">
    <div class="card p-4">
        <h3>واردات اطلاعات پرسنل و تجهیزات</h3>
        <?= $msg ?>
        <p>فایل Excel با پسوند <b>.xlsx</b> یا CSV را انتخاب کنید.</p>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <input type="file" name="file" class="form-control" accept=".xlsx,.csv" required>
            </div>
            <div class="mb-3">
                <label>جداکننده (فقط برای CSV)</label>
                <select name="separator" class="form-select">
                    <option value=",">کاما (,)</option>
                    <option value=";">نقطه ویرگول (;)</option>
                    <option value="tab">تب (Tab)</option>
                    <option value="esc">کاراکتر Esc</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success"><img src="images/icons/upload.png" width="18" style="margin-left:5px;"> شروع واردات</button>
        </form>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>